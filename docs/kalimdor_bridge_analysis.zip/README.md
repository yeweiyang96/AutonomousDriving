# Kalimdor bridge diagnosis checkpoint

These are diagnostic measurements, source checkpoints and tests, not an installation package.
The map1 bridge is not yet repaired. Candidate road-corridor-v2 rejects the known excessive fallback but does not create missing bridge geometry.

All file names preserve the analysis workspace layout. The native probe and replay scripts additionally require the captured Detour/native source, the original input ZIP assets, and the matching Linux analysis library. Tests for the source collector use the previously captured map0 original inputs and products. Those historical inputs are not duplicated here. Read the diagnosis report for evidence sources and test limits.

Active Windows navigation files have not been changed by these checkpoints. Use only collect_bridge_source.py as directed to collect the missing original source geometry.
