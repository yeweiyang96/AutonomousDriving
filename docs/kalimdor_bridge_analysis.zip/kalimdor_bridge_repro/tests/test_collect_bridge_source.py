"""Targeted collector checks; no Windows/WSL generation is claimed here."""
from contextlib import redirect_stdout
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import zipfile

ROOT=Path(__file__).resolve().parents[2]
COLLECTOR=ROOT/'kalimdor_bridge_repro/deliverables/collect_bridge_source.py'
spec=importlib.util.spec_from_file_location('bridge_source_collector',COLLECTOR)
c=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=c
spec.loader.exec_module(c)
CAPTURE=ROOT/'generation_repro/navmesh-tile-debug-20261029T005354Z-5a105709'
MAP0=c.TileTarget(0,50,34,
    '616d2cf2905a2868ee83f3a12aa60540d04b73b2186d895033084dfc3e95fd79',
    '11f29fcf6940331baab4221832dd3c60cafd7b8946d3f7503bbfaffc66695226')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='bridge-source-test-')
        self.root=Path(self.temp.name)/'project'
        self.work=self.root/'runtime/nav-build-70658'
        shutil.copytree(CAPTURE/'inputs',self.work)
        shutil.copy2(CAPTURE/'original-work/provenance.json',self.work/'provenance.json')
        (self.work/'mmaps').mkdir()
        for name in (MAP0.mmap_name,MAP0.tile_name):
            shutil.copy2(CAPTURE/'mmaps'/name,self.work/'mmaps'/name)
        self.nav=self.root/'data/navigation'
        self.nav.mkdir(parents=True)
        manifest=json.loads((CAPTURE/'published/manifest.json').read_text())
        (self.nav/'manifest.json').write_text(json.dumps(manifest))
        self.manifest_before=(self.nav/'manifest.json').read_bytes()
        for entry in manifest['maps']+manifest['tiles']:
            if (entry.get('c')==0 and 'row' not in entry or
                (entry.get('c'),entry.get('row'),entry.get('col'))==MAP0.coordinates):
                dst=self.nav/entry['path'];dst.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(self.work/'mmaps'/Path(entry['path']).name,dst)
        prov=self.nav/manifest['provenance'];prov.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(self.work/'provenance.json',prov)
        latest=self.root/'runtime/route-quality/last-plan.json';latest.parent.mkdir()
        latest.write_text(json.dumps({'schema':1,'start':{'c':1,'x':0,'y':0},'goal':{'c':1},
                                      'started_at_utc':'test-different-route'}))

    def tearDown(self):
        self.temp.cleanup()

    def fake_generation(self,payload,distribution):
        self.assertEqual(payload['target'],MAP0.payload())
        self.assertEqual(payload['products'],list(MAP0.products))
        self.assertEqual(Path(payload['input']),self.work)
        out=Path(payload['output'])
        self.assertFalse(out.is_relative_to(self.work))
        self.assertEqual(payload['tool_sha256'],c.DEBUG_TOOL_SHA)
        self.assertEqual(payload['timeout'],600)
        products=[]
        for name in MAP0.products:
            dst=out/name;dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(CAPTURE/name,dst)
            products.append({'path':name,'bytes':dst.stat().st_size,'sha256':digest(dst),
                             'nonempty':True,'exists':True})
        report={'generator_started':True,'verified_baseline':True,'warnings':[],
                'returncode':0,'products':products,'test_double':True}
        (out/'generator.log').write_text('Test transport: captured outputs, generator was not executed.\n')
        for name in ('runner-result.json','runner-status.json'):
            (out/name).write_text(json.dumps(report))
        return report

    def collect(self,runner=None,**kwargs):
        with patch.object(c,'wsl_path',side_effect=lambda p,d:str(p)), \
             patch.object(c,'run_tile_debug_worker',side_effect=runner or self.fake_generation) as run, \
             redirect_stdout(io.StringIO()):
            result=c.collect_tile_debug(self.root,target=MAP0,**kwargs)
        with zipfile.ZipFile(result['path']) as z:
            case=json.loads(z.read('case.json'))
            listing=json.loads(z.read('inventory.json'))
            for item in listing['members']:
                data=z.read(item['path'])
                self.assertEqual(len(data),item['bytes'])
                self.assertEqual(hashlib.sha256(data).hexdigest(),item['sha256'])
        self.assertEqual((self.nav/'manifest.json').read_bytes(),self.manifest_before)
        return result,case,run

    def test_default_target_and_worker_command_use_map1(self):
        t=c.DEFAULT_TARGET
        self.assertEqual(t.coordinates,(1,37,38))
        self.assertEqual(t.tile_name,'0001_37_38.mmtile')
        self.assertEqual(t.mmap_name,'0001.mmap')
        self.assertEqual(len(t.products),6)
        tree=ast.parse(c.TILE_DEBUG_WORKER)
        node=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign)
                  and any(isinstance(x,ast.Name) and x.id=='command' for x in n.targets))
        code=compile(ast.Expression(node.value),'worker-command','eval')
        command=eval(code,{'str':str,'tool':Path('/fixed/tool'),'T':t.payload(),
                           'original':Path('/fixed/input'),'out':Path('/fixed/new-output')})
        self.assertEqual(command[:4],['/fixed/tool','1','--tile','37,38'])
        self.assertNotIn('--partition',command)
        self.assertNotIn('--skipLiquid',command)
        self.assertEqual(command[command.index('--walkableClimb')+1],'2')
        help_result=subprocess.run([sys.executable,str(COLLECTOR),'--help'],capture_output=True,text=True,check=True)
        self.assertIn('--project-root',help_result.stdout)
        self.assertTrue(help_result.stdout.startswith('BRIDGE SOURCE 0001_37_38'))

    def test_complete_capture_with_real_map0_inputs(self):
        result,case,run=self.collect()
        self.assertEqual(run.call_count,1)
        self.assertTrue(result['collection_complete'])
        self.assertTrue(result['verified_baseline'])
        self.assertTrue(result['source_evidence_complete'])
        self.assertTrue(result['packaged_required_outputs_complete'])
        self.assertEqual(case['target'],MAP0.payload())
        self.assertFalse(case['latest_plan_snapshot']['same_continent_as_target'])
        self.assertEqual(case['input_evidence']['target'],[0,50,34])
        self.assertEqual(case['input_evidence']['model_count'],76)
        self.assertFalse(case['production_activated'])
        self.assertTrue(case['published_snapshots_unchanged'])
        self.assertTrue(case['input_stability']['unchanged'])

    def test_unknown_active_tile_is_refused_before_generation(self):
        manifest=json.loads(self.manifest_before)
        entry=next(e for e in manifest['tiles'] if (e['c'],e['row'],e['col'])==MAP0.coordinates)
        (self.nav/entry['path']).write_bytes(b'changed active tile')
        result,case,run=self.collect()
        self.assertEqual(run.call_count,0)
        self.assertFalse(result['generator_started'])
        self.assertFalse(result['collection_complete'])
        self.assertIn('bytes/hash do not match',case['error'])

    def test_missing_declared_vmo_prevents_generation(self):
        path=next((self.work/'vmaps').glob('*.vmo'))
        path.unlink()
        result,case,run=self.collect()
        self.assertEqual(run.call_count,0)
        self.assertFalse(result['source_evidence_complete'])
        self.assertFalse(result['collection_complete'])
        self.assertIn('Required source evidence is incomplete',case['error'])

    def test_source_change_invalidates_baseline(self):
        raw=self.work/'maps/0000_50_34.map'
        before=raw.read_bytes()
        def runner(payload,distribution):
            result=self.fake_generation(payload,distribution)
            raw.write_bytes(before+b'changed')
            return result
        result,case,_=self.collect(runner)
        self.assertFalse(result['verified_baseline'])
        self.assertFalse(result['collection_complete'])
        self.assertFalse(case['input_stability']['unchanged'])
        with zipfile.ZipFile(result['path']) as z:
            self.assertEqual(z.read('inputs/maps/0000_50_34.map'),before)

    def test_changed_required_output_is_not_complete(self):
        def runner(payload,distribution):
            result=self.fake_generation(payload,distribution)
            mesh=Path(payload['output'])/'meshes/map0000_50_34.mesh'
            mesh.write_bytes(mesh.read_bytes()+b'changed after verification')
            return result
        result,case,_=self.collect(runner)
        self.assertTrue(result['verified_baseline'])
        self.assertTrue(result['source_evidence_complete'])
        self.assertFalse(result['packaged_required_outputs_complete'])
        self.assertFalse(result['collection_complete'])
        row=next(r for r in case['packaged_products'] if r['path'].endswith('.mesh'))
        self.assertFalse(row['included'])
        self.assertIn('changed or lacks its verified snapshot',row['error'])

    def test_packaging_budget_cannot_report_complete(self):
        original=c.DEBUG_MAX_TOTAL
        def runner(payload,distribution):
            result=self.fake_generation(payload,distribution)
            c.DEBUG_MAX_TOTAL=4*1024*1024
            return result
        try:
            result,case,_=self.collect(runner)
        finally:
            c.DEBUG_MAX_TOTAL=original
        self.assertTrue(result['verified_baseline'])
        self.assertFalse(result['source_evidence_complete'])
        self.assertFalse(result['packaged_required_outputs_complete'])
        self.assertFalse(result['collection_complete'])
        self.assertTrue(any('Archive byte limit' in w for w in case['warnings']))

    def test_heartbeat_is_separate_from_worker_json(self):
        output=io.StringIO()
        def transport(*args,**kwargs):
            self.assertEqual(args[0][:4],['wsl.exe','-d','Ubuntu','--exec'])
            self.assertEqual(kwargs['timeout'],720)
            self.assertIn(b'PAYLOAD = ',kwargs['input'])
            time.sleep(.045)
            return subprocess.CompletedProcess(args[0],0,b'{"worker_result":true}',b'')
        with patch.object(c.subprocess,'run',side_effect=transport),redirect_stdout(output):
            result=c.run_tile_debug_worker({'target':c.DEFAULT_TARGET.payload()},'Ubuntu',heartbeat_seconds=.01)
        self.assertEqual(result,{'worker_result':True})
        self.assertIn('仍在运行',output.getvalue())

    def test_real_worker_refuses_unpinned_binary(self):
        base=Path(self.temp.name)
        output=base/'isolated';output.mkdir()
        tool=base/'fake-elf';tool.write_bytes(b'\x7fELFnot an executable generator')
        payload={'target':c.DEFAULT_TARGET.payload(),'output':str(output),'input':str(self.work),
                 'tool':str(tool),'tool_sha256':c.DEBUG_TOOL_SHA,'file_limit':c.DEBUG_MAX_FILE,
                 'timeout':600,'products':list(c.DEFAULT_TARGET.products),
                 'target_sha256':c.DEFAULT_TARGET.tile_sha256,
                 'input_provenance_sha256':digest(self.work/'provenance.json'),
                 'mmap_sha256':c.DEFAULT_TARGET.mmap_sha256,'mmap_header_hex':''}
        program='PAYLOAD = '+repr(payload)+'\n'+c.TILE_DEBUG_WORKER
        result=subprocess.run([sys.executable,'-B','-'],input=program.encode(),capture_output=True,check=True)
        record=json.loads(result.stdout)
        self.assertFalse(record['generator_started'])
        self.assertFalse(record['verified_baseline'])
        self.assertFalse(record['tool']['matches_expected'])
        self.assertIn('SHA256 changed; execution refused',record['error'])


if __name__=='__main__':
    unittest.main(verbosity=2)
