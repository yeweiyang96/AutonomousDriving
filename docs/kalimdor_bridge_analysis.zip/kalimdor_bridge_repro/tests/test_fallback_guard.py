"""Behavioral regressions for road-aware fallback, with controlled native paths.

The production road helper and planner run unchanged apart from the candidate
fix. The fixtures provide genuine ordered paths, not pre-thrown helper errors.
No DLL is loaded and no captured source or asset is modified.
"""
from pathlib import Path
import importlib.util
import json
import math
import sys
import tempfile
import threading
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# Reuse the existing independent wall/layer/budget/diagnostic fixture and all
# six production integration tests, rebinding only the candidate implementation.
previous = load('existing_production_integration',
                ROOT/'route_quality_repro/prototype/test_production_integration.py')
helper = load('adrive.road_corridor',
              ROOT/'kalimdor_bridge_repro/candidate/adrive/road_corridor.py')
candidate = load('adrive.fallback_guard_navmesh',
                 ROOT/'kalimdor_bridge_repro/candidate/adrive/navmesh.py')
previous.candidate = candidate
Pack = previous.FixturePack
for name in ('plan', '_plan_geometry', '_save_route_diagnostics'):
    setattr(Pack, name, getattr(candidate.NavMeshPack, name))
Pack.around = staticmethod(candidate.NavMeshPack.around)
Point, Route, Segment, PlanningError = (previous.Point, previous.Route,
                                       previous.Segment, previous.PlanningError)
reviewed = previous.reviewed


class BridgeGapFixture(previous.NativeSurfaceFixture):
    """Two shores separated by missing preferred surface and a long native way around.

    The long connection is a complete rectangular detour; no fixture path
    crosses the unsupported gap directly except after an explicitly simulated
    successful radius-2 reload. All guide-interior elevations are unknown.
    """
    def __init__(self, *, goal_x=50.62557172314976, detour_y=199.527791089179,
                 fallback_failures=0, shortcut_after_reload=False,
                 fallback_error=None, cancel_after_fallback=False):
        super().__init__(fallback_failures=fallback_failures)
        self.goal_x, self.detour_y = goal_x, detour_y
        self.shortcut_after_reload = shortcut_after_reload
        self.fallback_error = fallback_error
        self.cancel_after_fallback = cancel_after_fallback

    def heights(self, point):
        if .5 < point.x < self.goal_x-.5 and abs(point.y) < .1:
            return []
        return [10.0] if point.z is None or abs(point.z-10.0) < .1 else []

    def path(self, start, goal, budget):
        fallback = self.debug_context.get('stage') == 'fallback_path'
        self.failure = self.fallback_error if fallback else None
        parts, count = super().path(start, goal, budget)
        crosses = min(start.x, goal.x) <= .5 and max(start.x, goal.x) >= self.goal_x-.5
        shortcut = (fallback and self.shortcut_after_reload
                    and self.debug_context.get('radius', 1) >= 2)
        if crosses and not shortcut:
            points = [start, Point(start.c, start.x, self.detour_y, start.z),
                      Point(goal.c, goal.x, self.detour_y, goal.z), goal]
            parts = [Segment((a, b), 'native_gap_fixture', 'navmesh',
                             f'gap:{len(self.calls)}:{i}')
                     for i, (a, b) in enumerate(zip(points, points[1:]))]
            self.issued.extend(parts)
        if fallback and self.cancel_after_fallback:
            self.cancel_event.set()
        return parts, count


def endpoints(surface, prefix=0):
    a = Point(0, -prefix, 0, 10)
    b = Point(0, surface.goal_x, 0, 10)
    guide = reviewed([Point(a.c, a.x, a.y), Point(b.c, b.x, b.y)])
    return a, b, guide


def fallback_calls(surface):
    return [c for c in surface.calls if c['context']['stage'] == 'fallback_path']


def quality_decisions(pack):
    return [r for r in pack.last_route_diagnostics['road_trace']
            if r['mode'] == 'remaining_native_fallback_quality']


class FallbackGuardTests(unittest.TestCase):
    def test_short_bridge_cannot_reaccept_the_rejected_detour(self):
        with tempfile.TemporaryDirectory() as project:
            surface = BridgeGapFixture()
            pack = Pack(project, surface, record=True)
            a, b, guide = endpoints(surface)
            with self.assertRaises(PlanningError) as raised:
                pack.plan(a, b, guide, max_expansions=2000)
            self.assertEqual(raised.exception.code, 'road_connection_unverified')
            trace = pack.last_route_diagnostics['road_trace']
            self.assertTrue(any(r.get('status') == 'excessive_detour'
                                and r['mode'] == 'road' for r in trace))
            decision, = quality_decisions(pack)
            self.assertFalse(decision['accepted'])
            self.assertAlmostEqual(decision['route_length_xy'], 449.6811539015077)
            self.assertAlmostEqual(decision['reference_length_xy'], 50.62557172314976)
            self.assertAlmostEqual(decision['length_limit_xy'], 146.5639293078744)
            self.assertFalse(decision['candidate_geometry_omitted'])
            self.assertEqual(decision['candidate_points'][0], [a.x, a.y, a.z])
            self.assertEqual(decision['candidate_points'][-1], [b.x, b.y, b.z])
            # A quality rejection must not alter the original no_route-only
            # radius policy or generate further native attempts.
            calls = fallback_calls(surface)
            self.assertEqual([c['context']['radius'] for c in calls], [1])
            self.assertEqual(len(surface.loads), 1)
            spent = sum(c['expanded'] for c in surface.calls)
            self.assertEqual(raised.exception.expanded, spent)
            self.assertEqual(decision['expanded_total'], spent)
            self.assertEqual(pack.last_route_diagnostics['result']['expanded'], spent)
            saved = json.loads((Path(project)/'runtime/route-quality/last-plan.json').read_text())
            self.assertEqual(saved['planner_version'], 'road-corridor-v2')
            self.assertEqual(saved['result']['code'], 'road_connection_unverified')
            self.assertTrue(saved['complete'])

    def test_long_verified_prefix_cannot_hide_a_bad_short_tail(self):
        with tempfile.TemporaryDirectory() as project:
            surface = BridgeGapFixture()
            pack = Pack(project, surface)
            a, b, guide = endpoints(surface, prefix=1000)
            exclusions = frozenset({'nav:integration-fixture:0:1,2,3:1,2,4'})
            with self.assertRaises(PlanningError) as raised:
                pack.plan(a, b, guide, exclusions, max_expansions=2000)
            self.assertEqual(raised.exception.code, 'road_connection_unverified')
            trace = pack.last_route_diagnostics['road_trace']
            resumed, = [r for r in trace if r['mode'] == 'remaining_native_fallback']
            self.assertGreater(resumed['retained_prefix_segments'], 0)
            decision, = quality_decisions(pack)
            self.assertGreater(decision['route_length_xy'], decision['length_limit_xy'])
            # The same bad tail would pass if the whole 1000-yard prefix were
            # mistakenly included in the reference length allowance.
            self.assertLess(decision['route_length_xy'], 2.5*guide.distance+20)
            self.assertLess(decision['reference_length_xy'], 200)
            call, = fallback_calls(surface)
            self.assertNotEqual(call['start'], a)
            self.assertEqual(decision['candidate_points'][0],
                             [call['start'].x, call['start'].y, call['start'].z])
            self.assertTrue(all(c['blocked'] == exclusions for c in surface.calls))
            self.assertTrue(all(c['start'].z == c['goal'].z == 10 for c in surface.calls))
            self.assertEqual(raised.exception.expanded, sum(c['expanded'] for c in surface.calls))

    def test_no_road_guide_keeps_native_geometric_routing(self):
        with tempfile.TemporaryDirectory() as project:
            surface = BridgeGapFixture()
            pack = Pack(project, surface)
            a, b, _ = endpoints(surface)
            route = pack.plan(a, b, guide=None)
            self.assertAlmostEqual(route.distance, 449.6811539015077)
            self.assertEqual(route.points[0], a)
            self.assertEqual(route.points[-1], b)
            self.assertEqual(quality_decisions(pack), [])
            self.assertEqual(len(surface.calls), 1)

    def test_no_route_retry_can_find_an_acceptable_connection(self):
        with tempfile.TemporaryDirectory() as project:
            surface = BridgeGapFixture(fallback_failures=1, shortcut_after_reload=True)
            pack = Pack(project, surface)
            a, b, guide = endpoints(surface)
            exclusions = frozenset({'nav:integration-fixture:0:1,2,3:1,2,4'})
            route = pack.plan(a, b, guide, exclusions, max_expansions=2000)
            calls = fallback_calls(surface)
            self.assertEqual([c['context']['radius'] for c in calls], [1, 2])
            self.assertEqual(calls[0]['result'], 'no_route')
            self.assertEqual(calls[1]['result'], 'success')
            self.assertEqual(calls[1]['budget'], calls[0]['budget']-calls[0]['expanded'])
            self.assertEqual(route.points[0], a)
            self.assertEqual(route.points[-1], b)
            self.assertAlmostEqual(route.distance, a.distance(b))
            self.assertEqual(route.expanded, sum(c['expanded'] for c in surface.calls))
            self.assertTrue(all(c['blocked'] == exclusions for c in surface.calls))
            self.assertEqual(len(surface.blocks), len(surface.loads))
            decision, = quality_decisions(pack)
            self.assertTrue(decision['accepted'])

    def test_fallback_cancellation_propagates_before_quality_classification(self):
        for after_success in (False, True):
            with self.subTest(after_success=after_success), tempfile.TemporaryDirectory() as project:
                surface = BridgeGapFixture(fallback_error=None if after_success else 'cancelled',
                                           cancel_after_fallback=after_success)
                pack = Pack(project, surface)
                a, b, guide = endpoints(surface)
                event = threading.Event()
                with self.assertRaises(PlanningError) as raised:
                    pack.plan(a, b, guide, cancel=event, max_expansions=2000)
                self.assertEqual(raised.exception.code, 'cancelled')
                self.assertEqual(quality_decisions(pack), [])
                self.assertEqual(len(fallback_calls(surface)), 1)
                self.assertEqual(raised.exception.expanded, sum(c['expanded'] for c in surface.calls))

    def test_fallback_native_budget_failure_is_not_a_quality_error(self):
        with tempfile.TemporaryDirectory() as project:
            surface = BridgeGapFixture(fallback_error='budget')
            pack = Pack(project, surface)
            a, b, guide = endpoints(surface)
            with self.assertRaises(PlanningError) as raised:
                pack.plan(a, b, guide, max_expansions=30)
            self.assertEqual(raised.exception.code, 'budget')
            self.assertEqual(quality_decisions(pack), [])
            self.assertEqual(len(fallback_calls(surface)), 1)
            self.assertEqual(raised.exception.expanded, 30)
            self.assertEqual(sum(c['expanded'] for c in surface.calls), 30)

    def test_no_route_exhausts_only_the_original_bounded_radii(self):
        with tempfile.TemporaryDirectory() as project:
            surface = BridgeGapFixture(fallback_failures=3)
            pack = Pack(project, surface)
            a, b, guide = endpoints(surface)
            with self.assertRaises(PlanningError) as raised:
                pack.plan(a, b, guide, max_expansions=2000)
            self.assertEqual(raised.exception.code, 'no_route')
            self.assertEqual([c['context']['radius'] for c in fallback_calls(surface)], [1, 2, 4])
            self.assertEqual(quality_decisions(pack), [])
            self.assertEqual(raised.exception.expanded, sum(c['expanded'] for c in surface.calls))


if __name__ == '__main__':
    loader = unittest.defaultTestLoader
    suite = unittest.TestSuite([
        loader.loadTestsFromTestCase(previous.ProductionIntegrationTests),
        loader.loadTestsFromTestCase(FallbackGuardTests),
    ])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(not result.wasSuccessful())
