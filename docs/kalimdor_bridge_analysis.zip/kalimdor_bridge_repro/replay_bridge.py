"""Replay the exact saved Kalimdor plan against nine hash-verified native tiles."""
from contextlib import contextmanager
from pathlib import Path
import argparse
import hashlib
import json
import math
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
CASE = ROOT / 'kalimdor_bridge_repro/case_d10b202e'
LIBRARY = ROOT / 'navigation_repro/replay/libadrive_navmesh.so'
ORIGINAL_DIAG = ROOT / 'upload/last-plan.json'
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, default=ROOT/'route_quality_repro/working')
parser.add_argument('--out', type=Path, default=ROOT/'kalimdor_bridge_repro/replay')
options = parser.parse_args()
sys.dont_write_bytecode = True
sys.path.insert(0, str(options.source))
from adrive.navmesh import Native, NavMeshPack, Mesh
from adrive.models import Point, Route, Segment, PlanningError

def xyz(p):
    return [p.x, p.y, p.z]

class TracedMesh(Mesh):
    def load(self, keys):
        self.pack.requested.update((self.c,*k) for k in keys)
        return super().load(keys)
    def heights(self, point):
        result = super().heights(point)
        self.pack.surfaces.append({'point':xyz(point), 'heights':result})
        return result
    def path(self, start, goal, budget):
        row={'start':xyz(start), 'goal':xyz(goal), 'budget':budget, 'context':dict(self.debug_context)}
        self.pack.calls.append(row)
        try:
            parts, expanded=super().path(start,goal,budget)
            r=Route(start,goal,tuple(parts),expanded)
            row.update(status='success',expanded=expanded,length_xy=r.distance,
                       points=[xyz(p) for p in r.points])
            return parts,expanded
        except PlanningError as exc:
            row.update(status=exc.code,expanded=getattr(exc,'expanded',0),message=str(exc))
            raise

class ReplayPack(NavMeshPack):
    def __init__(self):
        self.raw=json.loads((CASE/'manifest.json').read_text(encoding='utf-8-sig'))
        self.identity=self.raw['identity'];self.build=self.raw['client']['version']
        self.maps={m['c']:m for m in self.raw['maps']}
        self.all_tiles={(t['c'],t['row'],t['col']):t for t in self.raw['tiles']}
        self.tiles={k:t for k,t in self.all_tiles.items() if (CASE/Path(t['path']).name).is_file()}
        self.native=Native(LIBRARY);self.root=CASE
        self.max_bytes=384*1024*1024;self.record_diagnostics=False
        self.calls=[];self.surfaces=[];self.reads={};self.requested=set()
    def read(self, entry):
        path=CASE/Path(entry['path']).name
        data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()
        if len(data)!=entry['bytes'] or digest!=entry['sha256']:
            raise ValueError('Asset hash mismatch: '+str(path))
        self.reads[entry['path']]={'bytes':len(data),'sha256':digest}
        return data
    @contextmanager
    def mesh(self,c,cancel=None):
        mesh=TracedMesh(self,c,cancel)
        try: yield mesh
        finally: mesh.close()

diag=json.loads(ORIGINAL_DIAG.read_text())
assert diag['start']['c']==1
start,goal=Point(**diag['start']),Point(**diag['goal'])
guide=Route(start,goal,tuple(Segment(tuple(Point(**p) for p in s['points']),
                                   s['source'],s['reliability'],s['edge_id'])
                             for s in diag['guide']['segments']))
options.out.mkdir(parents=True,exist_ok=True)
for name,a,b,g in [('guided',start,goal,guide),('native_direct',start,goal,None)]:
    pack=ReplayPack();began=time.monotonic()
    report={'case':name,'source':str(options.source),'source_diagnostic':str(ORIGINAL_DIAG),
            'pack_identity':pack.identity,'native_library_sha256':hashlib.sha256(LIBRARY.read_bytes()).hexdigest(),
            'loaded_tile_fixture':9,'start':xyz(a),'goal':xyz(b)}
    try:
        r=pack.plan(a,b,guide=g,blocked_edges=frozenset(diag['blocked_edges']))
        report.update(status='success',length_xy=r.distance,
                      length_3d=sum(math.dist(xyz(p),xyz(q)) for p,q in zip(r.points,r.points[1:])),
                      expanded=r.expanded,points=[xyz(p) for p in r.points],
                      edges=[s.edge_id for s in r.segments])
    except PlanningError as exc:
        report.update(status=exc.code,message=str(exc),expanded=getattr(exc,'expanded',None))
    report.update(elapsed_seconds=time.monotonic()-began,calls=pack.calls,surfaces=pack.surfaces,
                  assets=pack.reads,diagnostic=pack.last_route_diagnostics,
                  omitted_requested_tiles=sorted(k for k in pack.requested if k in pack.all_tiles and k not in pack.tiles))
    out=options.out/(name+'.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('points','edges','calls','surfaces','assets','diagnostic')},ensure_ascii=False))
    print('native_query_count',len(pack.calls),'surface_query_count',len(pack.surfaces),'output',out)
