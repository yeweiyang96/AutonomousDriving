from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/kalimdor-mesh-matplotlib')
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.lines import Line2D
p=Path(__file__).resolve().parent
mesh=json.loads((p/'local-mesh.json').read_text())['polygons']
island=json.loads((p/'bridge-island.json').read_text());refs=set(island['refs'])
profile=json.loads((p/'profile.json').read_text())['samples']
diagnostic=json.loads((p.parents[1]/'upload/last-plan.json').read_text())
A=np.array([-2820.714451053201,-3396.102114364935]);B=np.array([-2834.214451053201,-3348.352114364935]);axis=(B-A)/np.linalg.norm(B-A);normal=np.array([-axis[1],axis[0]])
def transform(vertices):
 v=np.array(vertices);d=v[:,:2]-A;return np.column_stack((d@axis,d@normal))
colors={'main':'#249976','island':'#8753bd','water':'#8cc5e5','other':'#d7dee5'}
def cat(item):
 po=item['polygon']
 if po['flags']==4:return 'water'
 if po['ref'] in refs:return 'island'
 if item['reachable_from_start']:return 'main'
 return 'other'
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':'#1b3047','font.size':10})
fig,(ax,pr)=plt.subplots(2,1,figsize=(12,7.5),gridspec_kw={'height_ratios':[2.4,1]},layout='constrained')
for item in sorted(mesh,key=lambda x:({'water':0,'other':1,'main':2,'island':3}[cat(x)])):
 po=item['polygon'];v=transform(po['vertices_world']);vs=np.array(po['vertices_world'])
 if v[:,0].max()<-5 or v[:,0].min()>55 or v[:,1].max()<-9 or v[:,1].min()>9:continue
 if vs[:,2].min()>36 or vs[:,2].max()<28:continue
 kind=cat(item);ax.add_patch(Polygon(v,closed=True,facecolor=colors[kind],edgecolor='white',linewidth=.9,alpha=.9))
 if po['ref'] in refs:
  avg=v.mean(axis=0);ax.text(*avg,str(po['poly']),ha='center',va='center',fontsize=8,color='white',weight='bold')
road=[diagnostic['start']]
for seg in diagnostic['guide']['segments']:
 if seg['reliability'] in ('reviewed','candidate'):road.extend(seg['points'])
road.append(diagnostic['goal']);rr=transform([[x['x'],x['y']] for x in road]);ax.plot(rr[:,0],rr[:,1],ls='--',lw=1.5,c='#253c50',label='Reviewed reference')
ab=transform([A,B]);ax.plot(ab[:,0],ab[:,1],ls=':',lw=1,c='#253c50')
for label,pt in zip(['A','B'],ab):
 ax.scatter(*pt,s=75,c='#203448',edgecolors='white',zorder=8);ax.annotate(label,pt,xytext=(0,10),textcoords='offset points',ha='center',weight='bold')
for a in json.loads((p/'anchors.json').read_text()):
 pt=transform([a['world_xy']])[0];ax.scatter(*pt,marker='x',c='#bd2f39',s=60,linewidths=2,zorder=9)
ax.annotate('1.33 yd gap in generated coverage',xy=(9,-1),xytext=(7,6.8),ha='center',color='#a32636',arrowprops={'arrowstyle':'->','color':'#a32636'})
ax.annotate('4 isolated walking polygons',xy=(20,-1.5),xytext=(23,-7.6),ha='center',color='#7340a5',arrowprops={'arrowstyle':'->','color':'#7340a5'})
ax.annotate('Water classification at bridge-height surfaces',xy=(40,-1),xytext=(39,6.8),ha='center',color='#357ba3',arrowprops={'arrowstyle':'->','color':'#357ba3'})
ax.set(xlim=(-4,54),ylim=(-9,9),xlabel='Distance along A–B axis (yd)',ylabel='Sideways distance (yd)')
ax.set_aspect('equal');ax.grid(alpha=.15);ax.set_axisbelow(True)
handles=[Line2D([],[],color=colors[k],lw=6,label=label) for k,label in [('main','Main walking component'),('island','Isolated walking component'),('water','NAV_WATER (flags 4 / area 9)')]]
ax.legend(handles=handles,ncol=3,loc='lower center',bbox_to_anchor=(.5,1.01),frameon=False,fontsize=9)
distance=np.linalg.norm(B-A)
for kind in colors:
 ds=[];zs=[]
 for q in profile:
  for s in q['surfaces']:
   kk='water' if s['flags']==4 else 'island' if s['ref'] in refs else 'main' if s['fromA'] else 'other'
   if kk==kind:ds.append(q['t']*distance);zs.append(s['height'])
 if ds:pr.scatter(ds,zs,s=9,c=colors[kind])
for run in island['profile_runs']:
 if run['label']=='empty':pr.axvspan(run['first_distance']-.124,run['last_distance']+.124,color='#f7dfe3')
pr.set(xlim=(0,distance),ylim=(31.2,32.5),xlabel='Distance along the A–B line (yd)',ylabel='Surface height (yd)')
pr.grid(alpha=.15);pr.set_title('All serialized ground polygons sampled, including water flags; pink bands have no sampled coverage',fontsize=10,loc='left')
fig.suptitle('Kalimdor bridge: disconnected deck fragments and excluded surface labels',fontsize=17,weight='bold')
fig.savefig(p/'bridge-mesh-diagnosis.png',dpi=180)
print(p/'bridge-mesh-diagnosis.png')
