#include "/workspace/scratch/20239ebfbca8/navigation_repro/case_87e934c9/native/navmesh/bridge.cpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <unordered_map>
#include <deque>
#include <filesystem>

const float START_W[3] = {float(-2820.714451053201), float(-3396.102114364935), float(32.11293029785156)};
const float GOAL_W[3] = {float(-2834.214451053201), float(-3348.352114364935), float(31.85224723815918)};

std::vector<unsigned char> readfile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if(!f) throw std::runtime_error("cannot read "+path);
    return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
void world(std::ostream& o,const float* p) {o<<'['<<p[2]<<','<<p[0]<<','<<p[1]<<']';}
void refjson(std::ostream& o,dtPolyRef ref) {o<<'"'<<uint64_t(ref)<<'"';}
bool lookup(Context* ctx,dtPolyRef ref,const dtMeshTile*& tile,const dtPoly*& poly) {
    return !dtStatusFailed(ctx->mesh.getTileAndPolyByRef(ref,&tile,&poly));
}
void polyjson(std::ostream& o,Context* ctx,dtPolyRef ref) {
    const dtMeshTile* t=nullptr; const dtPoly* p=nullptr;
    if(!lookup(ctx,ref,t,p)){o<<"null";return;}
    o<<"{\"ref\":"; refjson(o,ref);
    o<<",\"tile\":["<<t->header->x<<','<<t->header->y<<','<<t->header->layer<<"],\"poly\":"<<(p-t->polys)
     <<",\"flags\":"<<p->flags<<",\"area\":"<<int(p->getArea())<<",\"type\":"<<int(p->getType())
     <<",\"passes_filter\":"<<ctx->filter.passFilter(ref,t,p)<<",\"vertices_world\":[";
    for(int i=0;i<p->vertCount;i++){if(i)o<<',';world(o,t->verts+p->verts[i]*3);}o<<"],\"neis\":[";
    for(int i=0;i<p->vertCount;i++){if(i)o<<',';o<<p->neis[i];}o<<"],\"links\":[";
    bool first=true;
    for(unsigned i=p->firstLink;i!=DT_NULL_LINK;i=t->links[i].next){
        const auto& l=t->links[i]; if(!first)o<<',';first=false;
        o<<"{\"ref\":";refjson(o,l.ref);o<<",\"edge\":"<<int(l.edge)<<",\"side\":"<<int(l.side)
          <<",\"bmin\":"<<int(l.bmin)<<",\"bmax\":"<<int(l.bmax);
        const dtMeshTile* nt=nullptr;const dtPoly* np=nullptr;
        if(l.ref&&lookup(ctx,l.ref,nt,np))o<<",\"passes_filter\":"<<ctx->filter.passFilter(l.ref,nt,np)
            <<",\"flags\":"<<np->flags<<",\"area\":"<<int(np->getArea())
            <<",\"tile\":["<<nt->header->x<<','<<nt->header->y<<','<<nt->header->layer<<"],\"poly\":"<<(np-nt->polys);
        o<<'}';
    }o<<"]}";
}
void endpoint(std::ostream& o,Context* ctx,const float* w,Surface& resolved) {
    float p[3]={w[1],w[2],w[0]},ext[3]={.05f,2.5f,.05f};dtPolyRef refs[512];int n=0;
    auto st=ctx->query.queryPolygons(p,ext,&ctx->filter,refs,&n,512);
    o<<"{\"query_status\":"<<st<<",\"raw_candidates\":[";
    for(int i=0;i<n;i++){
        if(i)o<<',';float nearest[3]={};bool over=false;
        auto cs=ctx->query.closestPointOnPoly(refs[i],p,nearest,&over);
        o<<"{\"polygon\":";polyjson(o,ctx,refs[i]);o<<",\"closest_status\":"<<cs<<",\"over\":"<<over
          <<",\"accepted_before_height_dedup\":"<<(!dtStatusFailed(cs)&&over&&std::abs(nearest[1]-p[1])<=2.5f)
          <<",\"closest_world\":";world(o,nearest);o<<'}';
    }o<<"],\"deduplicated_surfaces\":[";
    std::vector<Surface> found;int sr=surfaces(ctx,w,found);
    for(size_t i=0;i<found.size();i++){if(i)o<<',';o<<"{\"ref\":";refjson(o,found[i].ref);o<<",\"world\":";world(o,found[i].p);o<<'}';}
    int rc=resolve(ctx,w,resolved);o<<"],\"surfaces_rc\":"<<sr<<",\"resolve_rc\":"<<rc<<",\"resolved\":";
    if(!rc)polyjson(o,ctx,resolved.ref);else o<<"null";o<<'}';
}
using Parents=std::unordered_map<dtPolyRef,dtPolyRef>;
Parents bfs(Context* ctx,dtPolyRef root,bool filtered,bool allow_offmesh=false) {
    Parents visited;visited.reserve(250000);std::vector<dtPolyRef> queue{root};visited[root]=0;
    for(size_t pos=0;pos<queue.size();pos++){
        dtPolyRef cur=queue[pos];const dtMeshTile* t=nullptr;const dtPoly* p=nullptr;
        if(!lookup(ctx,cur,t,p))throw std::runtime_error("BFS invalid current ref");
        for(unsigned k=p->firstLink;k!=DT_NULL_LINK;k=t->links[k].next){
            dtPolyRef nr=t->links[k].ref;if(!nr||visited.count(nr))continue;
            const dtMeshTile* nt=nullptr;const dtPoly* np=nullptr;
            if(!lookup(ctx,nr,nt,np))throw std::runtime_error("BFS invalid neighbor ref");
            if(!allow_offmesh&&np->getType()!=DT_POLYTYPE_GROUND)continue;
            if(filtered&&!ctx->filter.passFilter(nr,nt,np))continue;
            if(ctx->filter.blocked.count({cur,cur})||ctx->filter.blocked.count({nr,nr})||
               ctx->filter.blocked.count({cur,nr})||ctx->filter.blocked.count({nr,cur}))continue;
            visited[nr]=cur;queue.push_back(nr);
        }
    }return visited;
}
void pathjson(std::ostream& o,const Parents& parents,dtPolyRef goal){
    std::vector<dtPolyRef> result;
    if(parents.count(goal))for(auto cur=goal;cur;cur=parents.at(cur))result.push_back(cur);
    std::reverse(result.begin(),result.end());o<<'[';
    for(size_t i=0;i<result.size();i++){if(i)o<<',';refjson(o,result[i]);}o<<']';
}
void rayjson(std::ostream& o,Context* ctx,const Surface& a,const Surface& b){
    dtPolyRef path[16384];int n=0;float t=0,normal[3]={};
    auto st=ctx->query.raycast(a.ref,a.p,b.p,&ctx->filter,&t,normal,path,&n,16384);
    o<<"{\"status\":"<<st<<",\"t\":"<<t<<",\"last_equals_goal\":"<<(n>0&&path[n-1]==b.ref)
     <<",\"path_count\":"<<n<<",\"path\":[";
    for(int i=0;i<n;i++){if(i)o<<',';refjson(o,path[i]);}o<<"],\"hit_world\":";
    float hit[3];for(int i=0;i<3;i++)hit[i]=a.p[i]+std::min(1.f,t)*(b.p[i]-a.p[i]);world(o,hit);
    o<<",\"normal_detour\":["<<normal[0]<<','<<normal[1]<<','<<normal[2]<<"]}";
}
struct AllGroundFilter : dtQueryFilter {
    bool passFilter(dtPolyRef, const dtMeshTile*, const dtPoly* p) const override {
        return p->getType()==DT_POLYTYPE_GROUND;
    }
};
void columnjson(std::ostream& o,Context* ctx,float north,float west,const dtQueryFilter* filter){
    float p[3]={west,0,north},ext[3]={.05f,20000.f,.05f};dtPolyRef refs[4096];int n=0;
    auto status=ctx->query.queryPolygons(p,ext,filter,refs,&n,4096);
    o<<"{\"query_status\":"<<status<<",\"query_candidates\":"<<n<<",\"over_candidates\":[";bool first=true;
    for(int i=0;i<n;i++){
        float nearest[3]={};bool over=false;auto s=ctx->query.closestPointOnPoly(refs[i],p,nearest,&over);
        if(dtStatusFailed(s)||!over)continue;if(!first)o<<',';first=false;
        o<<"{\"height\":"<<nearest[1]<<",\"closest_world\":";world(o,nearest);o<<",\"polygon\":";polyjson(o,ctx,refs[i]);o<<'}';
    }o<<"]}";
}
void columns(const std::string& path,Context* ctx){
    std::ofstream o(path);o<<std::setprecision(10)<<std::boolalpha;AllGroundFilter all;
    o<<"{\"vertical_extent\":20000,\"height_deduplication\":false,\"samples\":[";
    for(int i=0;i<5;i++){
        if(i)o<<',';float t=float(i)/4;float n=START_W[0]+t*(GOAL_W[0]-START_W[0]);float w=START_W[1]+t*(GOAL_W[1]-START_W[1]);
        o<<"{\"fraction\":"<<t<<",\"world_xy\":["<<n<<','<<w<<"],\"original_filter\":";columnjson(o,ctx,n,w,&ctx->filter);
        o<<",\"all_ground_flags\":";columnjson(o,ctx,n,w,&all);o<<'}';
    }o<<"]}";
}
void profile(const std::string& path,Context* ctx,const Parents& fromA,const Parents& fromB,const Parents& fromCenter){
    std::ofstream o(path);o<<std::setprecision(12)<<std::boolalpha;AllGroundFilter all;
    o<<"{\"coordinates\":\"world [north,west,height]\",\"vertical_extent\":20000,\"height_deduplication\":false,\"purpose\":\"surface geometry profile, not a route\",\"samples\":[";
    for(int i=0;i<=200;i++){
        if(i)o<<',';double t=double(i)/200.;
        float north=float(START_W[0]+t*(GOAL_W[0]-START_W[0]));float west=float(START_W[1]+t*(GOAL_W[1]-START_W[1]));
        float p[3]={west,0,north},ext[3]={.05f,20000.f,.05f};dtPolyRef refs[4096];int n=0;
        auto status=ctx->query.queryPolygons(p,ext,&all,refs,&n,4096);
        o<<"{\"t\":"<<t<<",\"worldxy\":["<<north<<','<<west<<"],\"query_status\":"<<status<<",\"surfaces\":[";bool first=true;
        for(int j=0;j<n;j++){
            const dtMeshTile* tile=nullptr;const dtPoly* poly=nullptr;if(!lookup(ctx,refs[j],tile,poly))continue;
            // Include all serialized ground surface flags.
            float nearest[3]={};bool over=false;auto st=ctx->query.closestPointOnPoly(refs[j],p,nearest,&over);
            if(dtStatusFailed(st)||!over)continue;if(!first)o<<',';first=false;
            const char* component=fromA.count(refs[j])?"A":fromB.count(refs[j])?"B":fromCenter.count(refs[j])?"bridge":"other";
            o<<"{\"height\":"<<nearest[1]<<",\"poly\":"<<(poly-tile->polys)<<",\"ref\":";refjson(o,refs[j]);
            o<<",\"tile\":["<<tile->header->x<<','<<tile->header->y<<','<<tile->header->layer<<"],\"flags\":"<<poly->flags
             <<",\"area\":"<<int(poly->getArea())<<",\"component\":\""<<component<<"\",\"fromA\":"<<bool(fromA.count(refs[j]))
             <<",\"fromB\":"<<bool(fromB.count(refs[j]))<<",\"fromCenter\":"<<bool(fromCenter.count(refs[j]))<<'}';
        }o<<"]}";
    }o<<"]}";
}
void localmesh(const std::string& path,Context* ctx,const Parents& a,const Parents& b){
    std::ofstream o(path);o<<std::setprecision(10)<<std::boolalpha;
    float lowN=std::min(START_W[0],GOAL_W[0])-60,highN=std::max(START_W[0],GOAL_W[0])+60;
    float lowW=std::min(START_W[1],GOAL_W[1])-60,highW=std::max(START_W[1],GOAL_W[1])+60;
    o<<"{\"coordinates\":\"world [north,west,height]\",\"polygons\":[";bool first=true;
    for(int ti=0;ti<ctx->mesh.getMaxTiles();ti++){
        const auto* tile=static_cast<const dtNavMesh&>(ctx->mesh).getTile(ti);if(!tile||!tile->header)continue;
        auto base=ctx->mesh.getPolyRefBase(tile);
        for(int pi=0;pi<tile->header->polyCount;pi++){
            const auto* p=&tile->polys[pi];float minN=1e30f,maxN=-1e30f,minW=1e30f,maxW=-1e30f;
            for(int i=0;i<p->vertCount;i++){const float* v=tile->verts+p->verts[i]*3;minN=std::min(minN,v[2]);maxN=std::max(maxN,v[2]);minW=std::min(minW,v[0]);maxW=std::max(maxW,v[0]);}
            if(maxN<lowN||minN>highN||maxW<lowW||minW>highW)continue;
            dtPolyRef ref=base|dtPolyRef(pi);if(!first)o<<',';first=false;
            o<<"{\"reachable_from_start\":"<<bool(a.count(ref))<<",\"reachable_from_goal\":"<<bool(b.count(ref))<<",\"polygon\":";
            polyjson(o,ctx,ref);o<<'}';
        }
    }o<<"]}";
}

int main(int argc,char** argv) {
 try {
  if(argc!=3)throw std::runtime_error("usage probe asset-directory output-directory");
  const std::filesystem::path assets(argv[1]),out(argv[2]);
  auto bytes=readfile((assets/"0001.mmap").string());void* handle=nullptr;
  if(ad_create(bytes.data(),bytes.size(),&handle))throw std::runtime_error("create failed");
  auto* ctx=static_cast<Context*>(handle);
  for(int row=36;row<=38;row++)for(int col=37;col<=39;col++) {
   auto path=assets/("0001_"+std::to_string(row)+"_"+std::to_string(col)+".mmtile");
   auto b=readfile(path.string());if(ad_add(handle,b.data(),b.size()))throw std::runtime_error("add failed");
  }
  Surface a{},b{};if(resolve(ctx,START_W,a)||resolve(ctx,GOAL_W,b))throw std::runtime_error("endpoint failed");
  auto fromA=bfs(ctx,a.ref,true),fromB=bfs(ctx,b.ref,true),all=bfs(ctx,a.ref,false);
  std::ofstream o(out/"topology.json");o<<std::setprecision(10)<<std::boolalpha;
  o<<"{\"start\":";endpoint(o,ctx,START_W,a);o<<",\"goal\":";endpoint(o,ctx,GOAL_W,b);
  o<<",\"bfs\":{\"start_count\":"<<fromA.size()<<",\"goal_count\":"<<fromB.size()<<",\"all_ground_count\":"<<all.size()<<",\"ground_connected\":"<<bool(fromA.count(b.ref))<<"},\"ray_start_goal\":";rayjson(o,ctx,a,b);o<<",\"ray_goal_start\":";rayjson(o,ctx,b,a);o<<"}";o.close();
  localmesh((out/"local-mesh.json").string(),ctx,fromA,fromB);
  columns((out/"columns.json").string(),ctx);
  Parents empty;profile((out/"profile.json").string(),ctx,fromA,fromB,empty);
  std::ofstream anchors(out/"anchors.json");anchors<<std::setprecision(10)<<std::boolalpha;AllGroundFilter all_filter;
  anchors<<"[";
  for(int i=0;i<2;i++) {
   if(i)anchors<<",";
   float north=i?-2826.2647741383685f:-2822.3959568972805f;
   float west=i?-3373.0885816118953f:-3388.3883026864924f;
   anchors<<"{\"world_xy\":["<<north<<","<<west<<"],\"original_filter\":";columnjson(anchors,ctx,north,west,&ctx->filter);
   anchors<<",\"all_ground_flags\":";columnjson(anchors,ctx,north,west,&all_filter);anchors<<"}";
  }anchors<<"]";
  std::cout<<"ground_connected="<<bool(fromA.count(b.ref))<<" ground_polygons="<<fromA.size()<<" all_ground_polygons="<<all.size()<<std::endl;
  ad_destroy(handle);return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}
}
