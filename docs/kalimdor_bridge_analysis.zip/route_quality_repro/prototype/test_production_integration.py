"""Narrow integration checks for the production planner with a native-API fixture.

The real road helper is used. Captured sources/assets are never modified, no
DLL is loaded, and every diagnostic write is confined to a TemporaryDirectory.
Native asset geometry regressions are covered by the separate replay reports.
"""
from contextlib import contextmanager
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest import mock

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'case_d2f9f429'))
from adrive.models import PlanningError, Point, Route, Segment


def load_candidate(name, filename):
    spec = importlib.util.spec_from_file_location(name, BASE / 'working/adrive' / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


load_candidate('adrive.road_corridor', 'road_corridor.py')
candidate = load_candidate('adrive.production_integration_navmesh', 'navmesh.py')


def reviewed(points):
    return Route(points[0], points[-1], tuple(
        Segment((a, b), 'reviewed fixture', 'reviewed', f'road:{i}')
        for i, (a, b) in enumerate(zip(points, points[1:]))))


class NativeSurfaceFixture:
    """Two separate horizontal floors; an optional wall requires a wide detour."""

    def __init__(self, *, wall=None, failure=None, fallback_failures=0):
        self.wall, self.failure, self.fallback_failures = wall, failure, fallback_failures
        self.debug_context = {}
        self.calls, self.issued, self.loads, self.blocks = [], [], [], []
        self.active_blocks = None
        self.cancel_event = None

    def cancelled(self):
        return bool(self.cancel_event and self.cancel_event.is_set())

    def load(self, keys):
        self.loads.append(set(keys))
        self.active_blocks = None  # A newly loaded surface must receive exclusions.

    def block(self, edges):
        self.active_blocks = frozenset(edges)
        self.blocks.append(self.active_blocks)

    def heights(self, point):
        if point.z is None:
            return [0.0, 10.0]
        return [z for z in (0.0, 10.0) if abs(z-point.z) < .1]

    def path(self, start, goal, budget):
        call = {'start': start, 'goal': goal, 'budget': budget,
                'context': dict(self.debug_context), 'blocked': self.active_blocks}
        self.calls.append(call)
        code = self.failure
        if self.debug_context.get('stage') == 'fallback_path' and self.fallback_failures:
            self.fallback_failures -= 1
            code = 'no_route'
        if start.z != goal.z:
            code = 'no_route'
        if code:
            spent = budget if code == 'budget' else min(2, budget)
            call.update(expanded=spent, result=code)
            error = PlanningError(code, 'controlled native fixture failure')
            error.expanded = spent
            raise error
        points = [start, goal]
        if self.wall is not None and min(start.x, goal.x) < self.wall < max(start.x, goal.x):
            points = [start, Point(start.c, start.x, 45, start.z),
                      Point(goal.c, goal.x, 45, goal.z), goal]
        parts = [Segment((a, b), 'native_fixture', 'navmesh', f'fixture:{len(self.calls)}:{i}')
                 for i, (a, b) in enumerate(zip(points, points[1:]))]
        self.issued.extend(parts)
        spent = min(3, budget)
        call.update(expanded=spent, result='success')
        return parts, spent


class FixturePack:
    plan = candidate.NavMeshPack.plan
    _plan_geometry = candidate.NavMeshPack._plan_geometry
    _save_route_diagnostics = candidate.NavMeshPack._save_route_diagnostics
    around = staticmethod(candidate.NavMeshPack.around)

    def __init__(self, project, surface, *, record=False):
        self.root = Path(project) / 'data/navigation'
        self.root.mkdir(parents=True)
        self.identity = 'integration-fixture'
        self.raw = {'library': {'sha256': 'f' * 64}}
        self.surface = surface
        self.record_diagnostics = record

    @contextmanager
    def mesh(self, continent, cancel=None):
        self.surface.cancel_event = cancel
        yield self.surface


class ProductionIntegrationTests(unittest.TestCase):
    def test_wide_detour_resumes_from_verified_prefix_with_shared_budget_and_blocks(self):
        with tempfile.TemporaryDirectory() as project:
            surface = NativeSurfaceFixture(wall=220, fallback_failures=1)
            pack = FixturePack(project, surface)
            a, b = Point(0, .123456789, 0, 10), Point(0, 300.987654321, 0, 10)
            exclusions = frozenset({'nav:integration-fixture:0:1,2,3:1,2,4'})
            route = pack.plan(a, b, reviewed([a, b]), exclusions, max_expansions=2000)
            trace = pack.last_route_diagnostics['road_trace']
            resumed = [entry for entry in trace if entry['mode'] == 'remaining_native_fallback']
            self.assertEqual(len(resumed), 1)
            fallback = [call for call in surface.calls if call['context']['stage'] == 'fallback_path']
            self.assertEqual(len(fallback), 2)
            resume = fallback[0]['start']
            self.assertNotEqual(resume, a)
            self.assertGreater(resumed[0]['retained_prefix_segments'], 0)
            prefix_size = resumed[0]['retained_prefix_segments']
            self.assertEqual(route.segments[prefix_size-1].points[-1], resume)
            self.assertEqual(route.segments[prefix_size].points[0], resume)
            self.assertEqual(fallback[1]['start'], resume)
            self.assertEqual(fallback[0]['budget'], 2000-resumed[0]['expanded_before'])
            self.assertEqual(fallback[1]['budget'], fallback[0]['budget']-fallback[0]['expanded'])
            self.assertEqual(route.expanded, sum(call['expanded'] for call in surface.calls))
            self.assertTrue(all(call['budget'] > 0 for call in surface.calls))
            self.assertTrue(all(call['blocked'] == exclusions for call in surface.calls))
            self.assertEqual(len(surface.loads), len(surface.blocks))
            self.assertEqual(route.points[0], a)
            self.assertEqual(route.points[-1], b)
            self.assertTrue(all(point.z == 10 for point in route.points))
            self.assertTrue(all(segment in surface.issued for segment in route.segments))
            self.assertTrue(any(point.y == 45 for point in route.points))

    def test_budget_and_native_cancellation_do_not_trigger_fallback(self):
        for code in ('budget', 'cancelled'):
            with self.subTest(code=code), tempfile.TemporaryDirectory() as project:
                surface = NativeSurfaceFixture(failure=code)
                pack = FixturePack(project, surface)
                a, b = Point(0, 0, 0, 10), Point(0, 40, 0, 10)
                with self.assertRaises(PlanningError) as raised:
                    pack.plan(a, b, reviewed([a, b]), max_expansions=3)
                self.assertEqual(raised.exception.code, code)
                self.assertEqual(len(surface.calls), 1)
                self.assertNotIn('fallback_path', [c['context']['stage'] for c in surface.calls])
                self.assertFalse(any(t['mode'] == 'remaining_native_fallback'
                                     for t in pack.last_route_diagnostics['road_trace']))
                if code == 'budget':
                    self.assertEqual(sum(c['expanded'] for c in surface.calls), 3)

    def test_precancelled_request_issues_no_native_paths(self):
        with tempfile.TemporaryDirectory() as project:
            surface = NativeSurfaceFixture()
            pack = FixturePack(project, surface)
            event = threading.Event()
            event.set()
            a, b = Point(0, 0, 0, 10), Point(0, 40, 0, 10)
            with self.assertRaises(PlanningError) as raised:
                pack.plan(a, b, reviewed([a, b]), cancel=event)
            self.assertEqual(raised.exception.code, 'cancelled')
            self.assertEqual(surface.calls, [])

    def test_unknown_or_wrong_endpoint_floor_remains_an_error(self):
        for z, code in [(None, 'navmesh_height'), (7, 'navmesh_height_mismatch')]:
            with self.subTest(z=z), tempfile.TemporaryDirectory() as project:
                surface = NativeSurfaceFixture()
                pack = FixturePack(project, surface)
                a, b = Point(0, 0, 0, 10), Point(0, 40, 0, z)
                with self.assertRaises(PlanningError) as raised:
                    pack.plan(a, b, reviewed([a, b]))
                self.assertEqual(raised.exception.code, code)
                self.assertEqual(surface.calls, [])

    def test_diagnostics_are_opt_in_and_contain_actual_guide_result_and_trace(self):
        for record in (False, True):
            with self.subTest(record=record), tempfile.TemporaryDirectory() as project:
                surface = NativeSurfaceFixture()
                pack = FixturePack(project, surface, record=record)
                a, b = Point(0, .123456789, 0, 10), Point(0, 29.987654321, 0, 10)
                guide = reviewed([a, Point(0, 14, 2), b])
                route = pack.plan(a, b, guide)
                path = Path(project) / 'runtime/route-quality/last-plan.json'
                if not record:
                    self.assertFalse((Path(project) / 'runtime').exists())
                    continue
                report = json.loads(path.read_text(encoding='utf-8'))
                self.assertEqual(report['result']['status'], 'success')
                self.assertEqual(report['result']['expanded'], route.expanded)
                self.assertEqual(report['start']['x'], a.x)
                self.assertEqual(report['goal']['x'], b.x)
                self.assertEqual([s['edge_id'] for s in report['guide']['segments']],
                                 [s.edge_id for s in guide.segments])
                self.assertEqual(report['guide']['segments'][0]['points'][1]['y'], 2)
                self.assertEqual(report['result']['segments'][-1]['points'][-1]['x'], b.x)
                self.assertTrue(any(t['accepted'] for t in report['road_trace'] if 'accepted' in t))
                self.assertTrue(report['complete'])
                self.assertEqual(list(path.parent.iterdir()), [path])

    def test_diagnostic_write_failure_preserves_successful_route(self):
        with tempfile.TemporaryDirectory() as project:
            surface = NativeSurfaceFixture()
            pack = FixturePack(project, surface, record=True)
            a, b = Point(0, 0, 0, 10), Point(0, 40, 0, 10)
            with mock.patch.object(candidate.os, 'replace', side_effect=PermissionError('fixture denied')):
                route = pack.plan(a, b, reviewed([a, b]))
            self.assertEqual(route.points[0], a)
            self.assertEqual(route.points[-1], b)
            self.assertEqual(pack.last_route_diagnostics['result']['status'], 'success')
            self.assertIn('PermissionError', pack.last_route_diagnostics['report_write_error'])
            self.assertEqual(list((Path(project) / 'runtime/route-quality').iterdir()), [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
