"""Summarize existing diagnostic results and draw serialized surfaces only."""
from collections import Counter, deque
import hashlib
import json
import math
import os
from pathlib import Path
import struct

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "matplotlib-cache"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Patch
from matplotlib.lines import Line2D
from matplotlib.ticker import ScalarFormatter

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DELIVER = ROOT / "westfall_route_repro/deliverables"
DELIVER.mkdir(exist_ok=True)


def load(name):
    return json.loads((HERE / name).read_bytes())


topology = load("topology.json")
columns = load("columns.json")
paths = load("connectivity-paths.json")
profile = load("profile.json")
mesh = load("local-mesh.json")
assets = load("asset-verification.json")
tile_path = ROOT / "westfall_route_repro/case_9ec25b57/mmaps/0000_52_30.mmtile"
tile_bytes = tile_path.read_bytes()
low = struct.unpack_from("<3f", tile_bytes, 92)
high = struct.unpack_from("<3f", tile_bytes, 104)
world_bounds = dict(north=[low[2], high[2]], west=[low[0], high[0]], height=[low[1], high[1]])
window = dict(north=[-10900, -10820], west=[580, 720])
assert all(world_bounds[k][0] <= window[k][0] <= window[k][1] <= world_bounds[k][1] for k in ("north", "west"))

endpoint_summary = []
for entry, col in zip(topology["endpoints"], columns):
    selected = entry["endpoint"]["resolved"]
    endpoint_summary.append(dict(
        name=entry["name"], xy_world=col["world_xy"],
        selected_poly=selected["poly"], selected_flags=selected["flags"], selected_area=selected["area"],
        walkable_component_polygons=entry["walkable_component_count"],
        ground_reachable_from_816=entry["reachable_from_816_with_ground_filter"],
        surfaces=[dict(height_yards=s["height"], polygon=s["polygon"]["poly"],
                       flags=s["polygon"]["flags"], area=s["polygon"]["area"])
                  for s in col["all_flags"]["over_candidates"]]))

valid_detour = paths["shortest_hop_to_anchor824"]
assert valid_detour["complete_with_resolved_heights"]
summary = dict(
    schema=1,
    fixed_route_source="kalimdor_bridge_repro/case_d10b202e/last-plan.json",
    fixed_route_sha256="18bc407b2c9d699b808b07fb6cdd48fd45c78028a7ec53ab21962cd5b317dbb6",
    graph_scope=dict(loaded_tiles=46, verified_tile_bytes=assets["total_tile_bytes"],
                     all_required_46_hashes_verified=True, missing_required_tiles=0,
                     include_flags="0x11", exclude_flags="0x0e", blocked_edges=0,
                     offmesh_traversal=False,
                     caveat="Connectivity refers to exactly these 46 historical loaded tiles, not every tile on the continent."),
    source_target=dict(map=0, row=52, col=30, detour_tile=[15, 9, 0],
                       bytes=len(tile_bytes), sha256=hashlib.sha256(tile_bytes).hexdigest(),
                       world_bounds_yards=world_bounds,
                       diagnostic_window_entirely_inside_target_tile=True),
    endpoints=endpoint_summary,
    full_graph=dict(anchor816_anchor824_and_final_goal_share_ground_component=True,
                    shared_ground_component_polygons=133157,
                    anchor817_818_upper_component_polygons=5,
                    anchor817_818_lower_component_polygons=9,
                    both_selected_upper_and_lower_are_unreachable_from_816=True,
                    area_unfiltered_component_polygons=146274),
    local_graph=dict(window_world_yards=window,
                     polygon_inclusion="Every polygon whose XY bounding box intersects this window; a superset of wholly contained polygons.",
                     reachable_ground_polygons=paths["local_ground_polygons"],
                     ground_reaches_anchor824=paths["local_ground_reaches_anchor824"],
                     reachable_ignoring_flags_polygons=paths["local_any_flags_polygons"],
                     ignoring_flags_reaches_anchor824=paths["local_any_flags_reaches_anchor824"],
                     ignored_flags_witness_polygons=12, witness_water_polygons=4,
                     warning="The path obtained by ignoring area flags is a topology witness only, not a walkable route or proposed fix."),
    observed_filter_boundary=dict(west_yards=639.999938965,
                                  anchor816_ground_poly=1868, anchor817_same_height_water_poly=1878,
                                  shared_surface_height_yards=31.5235118866,
                                  water_flags=4, water_area=9),
    valid_long_detour=dict(start="anchor816", goal="anchor824",
                           construction="BFS minimizes polygon count, then original Detour findStraightPath; every returned height resolved.",
                           polygon_count=valid_detour["polygon_count"],
                           all_corridor_polygons_ground_area11=True,
                           length_xy_yards=valid_detour["length_xy"],
                           length_3d_yards=valid_detour["length_3d"],
                           max_xy_deviation_from_endpoint_segment_yards=valid_detour["max_xy_deviation_from_endpoint_segment"],
                           world_bounds_north_west_yards=valid_detour["bounds_north_west"],
                           is_proven_shortest_geometric_route=False,
                           note="This is one validated long corridor establishing connectivity. It was not produced successfully by the original capped A* query and is not a proposed navigation change."),
    native_probe=dict(per_call_expansion_budget=500000, node_pool_capacity=65535,
                      failed_targets=[dict(target=q["target"], rc=q["native"]["rc"],
                                           expanded=q["native"]["expanded"], native_reason="node_pool_exhausted")
                                      for q in topology["queries_from_816"] if q["native"]["rc"]==6],
                      note="Native probe asset loading is sorted; exact historical planner replay is documented separately under replay/."),
    limitations=[
        "Only serialized navigation surfaces are present for map0/52/30; original terrain, VMAP models, and debug generation geometry for this tile are missing.",
        "A same-height surface carrying NAV_WATER does not prove that the tag is wrong or that the real bridge is present and walkable.",
        "Cannot identify the original Recast stage or assert that the cause matches either earlier bridge without the raw source data.",
        "No source extraction, production mesh edit, filter relaxation, or planner modification was performed.",
        "Centroid-weighted diagnostic corridors did not resolve all output heights; they are not accepted as valid routes or shortest-distance evidence.",
    ],
    required_next_evidence="Collect the pinned map0/52/30 raw generation inputs and isolated baseline/debug outputs, including the normal neighboring source strips and referenced VMOs.",
    evidence_files=["asset-verification.json", "topology.json", "columns.json", "profile.json", "local-mesh.json", "connectivity-paths.json"],
)
(HERE / "diagnosis-summary.json").write_text(json.dumps(summary, indent=2) + "\n")

local_by_ref = {r["polygon"]["ref"]: r for r in mesh["polygons"]}


def component(seed):
    visited, queue = {seed}, deque([seed])
    while queue:
        ref = queue.popleft()
        for link in local_by_ref[ref]["polygon"]["links"]:
            r = link["ref"]
            if r not in visited and r in local_by_ref and link.get("passes_filter"):
                visited.add(r)
                queue.append(r)
    return visited


upper = component(topology["endpoints"][1]["endpoint"]["resolved"]["ref"])
lower = component(topology["endpoints"][2]["endpoint"]["resolved"]["ref"])
assert len(upper) == 5 and len(lower) == 9
colors = dict(main="#22856B", water="#397DB8", upper="#8C5DB7", lower="#D48B31", other="#858C96")


def category(poly, from_start):
    if poly["flags"] & 4:
        return "water"
    if poly["ref"] in upper:
        return "upper"
    if poly["ref"] in lower:
        return "lower"
    return "main" if from_start and poly["passes_filter"] else "other"


plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10.5, "axes.titlesize": 12,
                     "axes.labelsize": 10, "axes.spines.top": False, "axes.spines.right": False})
fig = plt.figure(figsize=(13, 8.8), facecolor="#F9FAFC")
grid = fig.add_gridspec(2, 1, left=.095, right=.965, top=.815, bottom=.195, hspace=.50,
                       height_ratios=[1, 1.05])
ax = fig.add_subplot(grid[0])
hp = fig.add_subplot(grid[1])
for pane in (ax, hp):
    pane.set_facecolor("white")
    pane.grid(color="#DCE2E8", linewidth=.65, alpha=.6)
    pane.set_axisbelow(True)

for row in mesh["polygons"]:
    p = row["polygon"]
    verts = p["vertices_world"]
    mean_height = sum(v[2] for v in verts) / len(verts)
    if not 30 <= mean_height <= 33:
        continue
    cat = category(p, row["reachable_from_start"])
    ax.add_patch(Polygon([(v[1], v[0]) for v in verts], closed=True,
                         facecolor=colors[cat], edgecolor=colors[cat], alpha=.32, linewidth=.85))

start = columns[0]["world_xy"]
goal = columns[5]["world_xy"]
ax.plot([start[1], goal[1]], [start[0], goal[0]], "--", color="#252D3A", linewidth=1.6, zorder=5)
anchor_points = {"816": start, "817": columns[1]["world_xy"], "818": columns[3]["world_xy"], "824": goal}
for name, point in anchor_points.items():
    ax.scatter(point[1], point[0], s=28, color="#1D2839", zorder=7)
    if name in ("817", "818"):
        ax.annotate(name, (point[1], point[0]), xytext=(0, 28 if name=="817" else -32), textcoords="offset points",
                    ha="center", weight="bold", arrowprops=dict(arrowstyle="-", color="#384252", lw=.8))
    else:
        ax.annotate(name, (point[1], point[0]), xytext=(-13, -20), textcoords="offset points", weight="bold")
ax.axvline(640, color="#BC4C4C", linestyle=":", linewidth=1.5)
ax.text(640.8, -10844, "Ground-filter boundary: Y = 640", color="#A53E3E", fontsize=9.5, va="top")
ax.set_xlim(627, 695)
ax.set_ylim(-10883, -10842)
ax.set_aspect("equal", adjustable="box")
ax.set_ylabel("World X / north (yards)")
ax.set_xlabel("World Y / west (yards)")
ax.set_title("XY view: serialized polygons with mean vertex height 30–33 yards", loc="left", pad=10)
ax.ticklabel_format(axis="both", style="plain", useOffset=False)

points_by_category = {k: [] for k in colors}
for sample in profile["samples"]:
    for s in sample["surfaces"]:
        p = dict(s, passes_filter=bool((s["flags"] & 0x11) and not(s["flags"] & 0x0e)))
        cat = category(p, s["fromA"])
        points_by_category[cat].append((sample["worldxy"][1], s["height"]))
for cat, points in points_by_category.items():
    if points:
        hp.scatter([p[0] for p in points], [p[1] for p in points], s=8, color=colors[cat], alpha=.9, zorder=3)
for col in (columns[1], columns[3]):
    for s in col["all_flags"]["over_candidates"]:
        hp.scatter(col["world_xy"][1], s["height"], marker="x", color="#212A39", s=46, linewidths=1.4, zorder=6)
hp.axvline(640, color="#BC4C4C", linestyle=":", linewidth=1.5)
hp.annotate("817: 40.154 / 31.524 / 21.442", xy=(640.625, 40.154), xytext=(645.0, 43.4),
            fontsize=9.5, arrowprops=dict(arrowstyle="-", color="#394251", lw=.8))
hp.annotate("818: 40.447 / 31.524 / 25.599", xy=(646.875, 25.599), xytext=(651.5, 22.1),
            fontsize=9.5, arrowprops=dict(arrowstyle="-", color="#394251", lw=.8))
hp.text(651, 32.55, "Same-height surface is serialized as WATER", color=colors["water"], fontsize=9.5)
hp.set_xlim(632, 690)
hp.set_ylim(19.8, 45.2)
hp.set_xlabel("World Y / west (yards)")
hp.set_ylabel("Surface height (yards)")
hp.set_title("Height profile along the dashed XY chord; × marks exact anchor queries", loc="left", pad=10)

legend = [Patch(facecolor=colors["main"], label="Ground: main component (133,157 polys)"),
          Patch(facecolor=colors["water"], label="Water tag: flags 4 / area 9 (filtered)"),
          Patch(facecolor=colors["upper"], label="Ground: upper island (5 polys)"),
          Patch(facecolor=colors["lower"], label="Ground: lower island (9 polys)")]
fig.suptitle("Westfall: a local ground-filter break with multiple surface heights", x=.095, y=.97,
             ha="left", fontsize=17, weight="bold", color="#202D3C")
fig.text(.095, .928, "Map 0 · tile 52,30 · fixed anchors 816–824 · all 46 historical tiles verified", color="#5A6674", fontsize=11)
fig.legend(handles=legend, loc="upper left", bbox_to_anchor=(.085,.903), ncol=2,
           frameon=False, columnspacing=2.3, handlelength=1.4, fontsize=10)
fig.text(.095, .092,
         "Local ground graph does not connect 816→824. The 46-tile graph does connect them; one validated detour is 6,982.67 yards (3D).",
         color="#263548", fontsize=10)
fig.text(.095, .059,
         "These are serialized navigation surfaces, not a drawing of the physical bridge. Raw collision/terrain is required to judge whether the WATER tag is correct.",
         color="#5D6774", fontsize=9.4)
output = DELIVER / "westfall_surface_diagnosis.png"
fig.savefig(output, dpi=180, facecolor=fig.get_facecolor())
print(output)
print(HERE / "diagnosis-summary.json")
