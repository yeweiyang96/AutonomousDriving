#include "/workspace/scratch/20239ebfbca8/navigation_repro/case_87e934c9/native/navmesh/bridge.cpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <unordered_map>
#include <deque>
#include <filesystem>
#include <array>
#include <queue>
#include <map>
#include <unordered_set>

const float START_W[3] = {float(-10863.542), float(634.375), float(31.52351188659668)};
const float GOAL_W[3] = {float(-10867.18725), float(687.50025), float(31.436214447021484)};

std::vector<unsigned char> readfile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if(!f) throw std::runtime_error("cannot read "+path);
    return {std::istreambuf_iterator<char>(f),std::istreambuf_iterator<char>()};
}
void world(std::ostream& o,const float* p) {o<<'['<<p[2]<<','<<p[0]<<','<<p[1]<<']';}
void refjson(std::ostream& o,dtPolyRef ref) {o<<'"'<<uint64_t(ref)<<'"';}
bool lookup(Context* ctx,dtPolyRef ref,const dtMeshTile*& tile,const dtPoly*& poly) {
    return !dtStatusFailed(ctx->mesh.getTileAndPolyByRef(ref,&tile,&poly));
}
void polyjson(std::ostream& o,Context* ctx,dtPolyRef ref) {
    const dtMeshTile* t=nullptr; const dtPoly* p=nullptr;
    if(!lookup(ctx,ref,t,p)){o<<"null";return;}
    o<<"{\"ref\":"; refjson(o,ref);
    o<<",\"tile\":["<<t->header->x<<','<<t->header->y<<','<<t->header->layer<<"],\"poly\":"<<(p-t->polys)
     <<",\"flags\":"<<p->flags<<",\"area\":"<<int(p->getArea())<<",\"type\":"<<int(p->getType())
     <<",\"passes_filter\":"<<ctx->filter.passFilter(ref,t,p)<<",\"vertices_world\":[";
    for(int i=0;i<p->vertCount;i++){if(i)o<<',';world(o,t->verts+p->verts[i]*3);}o<<"],\"neis\":[";
    for(int i=0;i<p->vertCount;i++){if(i)o<<',';o<<p->neis[i];}o<<"],\"links\":[";
    bool first=true;
    for(unsigned i=p->firstLink;i!=DT_NULL_LINK;i=t->links[i].next){
        const auto& l=t->links[i]; if(!first)o<<',';first=false;
        o<<"{\"ref\":";refjson(o,l.ref);o<<",\"edge\":"<<int(l.edge)<<",\"side\":"<<int(l.side)
          <<",\"bmin\":"<<int(l.bmin)<<",\"bmax\":"<<int(l.bmax);
        const dtMeshTile* nt=nullptr;const dtPoly* np=nullptr;
        if(l.ref&&lookup(ctx,l.ref,nt,np))o<<",\"passes_filter\":"<<ctx->filter.passFilter(l.ref,nt,np)
            <<",\"flags\":"<<np->flags<<",\"area\":"<<int(np->getArea())
            <<",\"tile\":["<<nt->header->x<<','<<nt->header->y<<','<<nt->header->layer<<"],\"poly\":"<<(np-nt->polys);
        o<<'}';
    }o<<"]}";
}
void endpoint(std::ostream& o,Context* ctx,const float* w,Surface& resolved) {
    float p[3]={w[1],w[2],w[0]},ext[3]={.05f,2.5f,.05f};dtPolyRef refs[512];int n=0;
    auto st=ctx->query.queryPolygons(p,ext,&ctx->filter,refs,&n,512);
    o<<"{\"query_status\":"<<st<<",\"raw_candidates\":[";
    for(int i=0;i<n;i++){
        if(i)o<<',';float nearest[3]={};bool over=false;
        auto cs=ctx->query.closestPointOnPoly(refs[i],p,nearest,&over);
        o<<"{\"polygon\":";polyjson(o,ctx,refs[i]);o<<",\"closest_status\":"<<cs<<",\"over\":"<<over
          <<",\"accepted_before_height_dedup\":"<<(!dtStatusFailed(cs)&&over&&std::abs(nearest[1]-p[1])<=2.5f)
          <<",\"closest_world\":";world(o,nearest);o<<'}';
    }o<<"],\"deduplicated_surfaces\":[";
    std::vector<Surface> found;int sr=surfaces(ctx,w,found);
    for(size_t i=0;i<found.size();i++){if(i)o<<',';o<<"{\"ref\":";refjson(o,found[i].ref);o<<",\"world\":";world(o,found[i].p);o<<'}';}
    int rc=resolve(ctx,w,resolved);o<<"],\"surfaces_rc\":"<<sr<<",\"resolve_rc\":"<<rc<<",\"resolved\":";
    if(!rc)polyjson(o,ctx,resolved.ref);else o<<"null";o<<'}';
}
using Parents=std::unordered_map<dtPolyRef,dtPolyRef>;
Parents bfs(Context* ctx,dtPolyRef root,bool filtered,bool allow_offmesh=false) {
    Parents visited;visited.reserve(250000);std::vector<dtPolyRef> queue{root};visited[root]=0;
    for(size_t pos=0;pos<queue.size();pos++){
        dtPolyRef cur=queue[pos];const dtMeshTile* t=nullptr;const dtPoly* p=nullptr;
        if(!lookup(ctx,cur,t,p))throw std::runtime_error("BFS invalid current ref");
        for(unsigned k=p->firstLink;k!=DT_NULL_LINK;k=t->links[k].next){
            dtPolyRef nr=t->links[k].ref;if(!nr||visited.count(nr))continue;
            const dtMeshTile* nt=nullptr;const dtPoly* np=nullptr;
            if(!lookup(ctx,nr,nt,np))throw std::runtime_error("BFS invalid neighbor ref");
            if(!allow_offmesh&&np->getType()!=DT_POLYTYPE_GROUND)continue;
            if(filtered&&!ctx->filter.passFilter(nr,nt,np))continue;
            if(ctx->filter.blocked.count({cur,cur})||ctx->filter.blocked.count({nr,nr})||
               ctx->filter.blocked.count({cur,nr})||ctx->filter.blocked.count({nr,cur}))continue;
            visited[nr]=cur;queue.push_back(nr);
        }
    }return visited;
}
void pathjson(std::ostream& o,const Parents& parents,dtPolyRef goal){
    std::vector<dtPolyRef> result;
    if(parents.count(goal))for(auto cur=goal;cur;cur=parents.at(cur))result.push_back(cur);
    std::reverse(result.begin(),result.end());o<<'[';
    for(size_t i=0;i<result.size();i++){if(i)o<<',';refjson(o,result[i]);}o<<']';
}
void rayjson(std::ostream& o,Context* ctx,const Surface& a,const Surface& b){
    dtPolyRef path[16384];int n=0;float t=0,normal[3]={};
    auto st=ctx->query.raycast(a.ref,a.p,b.p,&ctx->filter,&t,normal,path,&n,16384);
    o<<"{\"status\":"<<st<<",\"t\":"<<t<<",\"last_equals_goal\":"<<(n>0&&path[n-1]==b.ref)
     <<",\"path_count\":"<<n<<",\"path\":[";
    for(int i=0;i<n;i++){if(i)o<<',';refjson(o,path[i]);}o<<"],\"hit_world\":";
    float hit[3];for(int i=0;i<3;i++)hit[i]=a.p[i]+std::min(1.f,t)*(b.p[i]-a.p[i]);world(o,hit);
    o<<",\"normal_detour\":["<<normal[0]<<','<<normal[1]<<','<<normal[2]<<"]}";
}
struct AllGroundFilter : dtQueryFilter {
    bool passFilter(dtPolyRef, const dtMeshTile*, const dtPoly* p) const override {
        return p->getType()==DT_POLYTYPE_GROUND;
    }
};
void columnjson(std::ostream& o,Context* ctx,float north,float west,const dtQueryFilter* filter){
    float p[3]={west,0,north},ext[3]={.05f,20000.f,.05f};dtPolyRef refs[4096];int n=0;
    auto status=ctx->query.queryPolygons(p,ext,filter,refs,&n,4096);
    o<<"{\"query_status\":"<<status<<",\"query_candidates\":"<<n<<",\"over_candidates\":[";bool first=true;
    for(int i=0;i<n;i++){
        float nearest[3]={};bool over=false;auto s=ctx->query.closestPointOnPoly(refs[i],p,nearest,&over);
        if(dtStatusFailed(s)||!over)continue;if(!first)o<<',';first=false;
        o<<"{\"height\":"<<nearest[1]<<",\"closest_world\":";world(o,nearest);o<<",\"polygon\":";polyjson(o,ctx,refs[i]);o<<'}';
    }o<<"]}";
}
void columns(const std::string& path,Context* ctx){
    std::ofstream o(path);o<<std::setprecision(10)<<std::boolalpha;AllGroundFilter all;
    o<<"{\"vertical_extent\":20000,\"height_deduplication\":false,\"samples\":[";
    for(int i=0;i<5;i++){
        if(i)o<<',';float t=float(i)/4;float n=START_W[0]+t*(GOAL_W[0]-START_W[0]);float w=START_W[1]+t*(GOAL_W[1]-START_W[1]);
        o<<"{\"fraction\":"<<t<<",\"world_xy\":["<<n<<','<<w<<"],\"original_filter\":";columnjson(o,ctx,n,w,&ctx->filter);
        o<<",\"all_ground_flags\":";columnjson(o,ctx,n,w,&all);o<<'}';
    }o<<"]}";
}
void profile(const std::string& path,Context* ctx,const Parents& fromA,const Parents& fromB,const Parents& fromCenter){
    std::ofstream o(path);o<<std::setprecision(12)<<std::boolalpha;AllGroundFilter all;
    o<<"{\"coordinates\":\"world [north,west,height]\",\"vertical_extent\":20000,\"height_deduplication\":false,\"purpose\":\"surface geometry profile, not a route\",\"samples\":[";
    for(int i=0;i<=200;i++){
        if(i)o<<',';double t=double(i)/200.;
        float north=float(START_W[0]+t*(GOAL_W[0]-START_W[0]));float west=float(START_W[1]+t*(GOAL_W[1]-START_W[1]));
        float p[3]={west,0,north},ext[3]={.05f,20000.f,.05f};dtPolyRef refs[4096];int n=0;
        auto status=ctx->query.queryPolygons(p,ext,&all,refs,&n,4096);
        o<<"{\"t\":"<<t<<",\"worldxy\":["<<north<<','<<west<<"],\"query_status\":"<<status<<",\"surfaces\":[";bool first=true;
        for(int j=0;j<n;j++){
            const dtMeshTile* tile=nullptr;const dtPoly* poly=nullptr;if(!lookup(ctx,refs[j],tile,poly))continue;
            // Include all serialized ground surface flags.
            float nearest[3]={};bool over=false;auto st=ctx->query.closestPointOnPoly(refs[j],p,nearest,&over);
            if(dtStatusFailed(st)||!over)continue;if(!first)o<<',';first=false;
            const char* component=fromA.count(refs[j])?"A":fromB.count(refs[j])?"B":fromCenter.count(refs[j])?"bridge":"other";
            o<<"{\"height\":"<<nearest[1]<<",\"poly\":"<<(poly-tile->polys)<<",\"ref\":";refjson(o,refs[j]);
            o<<",\"tile\":["<<tile->header->x<<','<<tile->header->y<<','<<tile->header->layer<<"],\"flags\":"<<poly->flags
             <<",\"area\":"<<int(poly->getArea())<<",\"component\":\""<<component<<"\",\"fromA\":"<<bool(fromA.count(refs[j]))
             <<",\"fromB\":"<<bool(fromB.count(refs[j]))<<",\"fromCenter\":"<<bool(fromCenter.count(refs[j]))<<'}';
        }o<<"]}";
    }o<<"]}";
}
void localmesh(const std::string& path,Context* ctx,const Parents& a,const Parents& b){
    std::ofstream o(path);o<<std::setprecision(10)<<std::boolalpha;
    float lowN=std::min(START_W[0],GOAL_W[0])-60,highN=std::max(START_W[0],GOAL_W[0])+60;
    float lowW=std::min(START_W[1],GOAL_W[1])-60,highW=std::max(START_W[1],GOAL_W[1])+60;
    o<<"{\"coordinates\":\"world [north,west,height]\",\"polygons\":[";bool first=true;
    for(int ti=0;ti<ctx->mesh.getMaxTiles();ti++){
        const auto* tile=static_cast<const dtNavMesh&>(ctx->mesh).getTile(ti);if(!tile||!tile->header)continue;
        auto base=ctx->mesh.getPolyRefBase(tile);
        for(int pi=0;pi<tile->header->polyCount;pi++){
            const auto* p=&tile->polys[pi];float minN=1e30f,maxN=-1e30f,minW=1e30f,maxW=-1e30f;
            for(int i=0;i<p->vertCount;i++){const float* v=tile->verts+p->verts[i]*3;minN=std::min(minN,v[2]);maxN=std::max(maxN,v[2]);minW=std::min(minW,v[0]);maxW=std::max(maxW,v[0]);}
            if(maxN<lowN||minN>highN||maxW<lowW||minW>highW)continue;
            dtPolyRef ref=base|dtPolyRef(pi);if(!first)o<<',';first=false;
            o<<"{\"reachable_from_start\":"<<bool(a.count(ref))<<",\"reachable_from_goal\":"<<bool(b.count(ref))<<",\"polygon\":";
            polyjson(o,ctx,ref);o<<'}';
        }
    }o<<"]}";
}


struct NamedPoint { const char* name; std::array<float,3> point; };
std::vector<dtPolyRef> chain(const Parents& parents,dtPolyRef goal) {
 std::vector<dtPolyRef> p;
 if(parents.count(goal))for(auto r=goal;r;r=parents.at(r))p.push_back(r);
 std::reverse(p.begin(),p.end());return p;
}
std::array<float,3> centre(Context* ctx,dtPolyRef ref) {
 const dtMeshTile* t=nullptr;const dtPoly* p=nullptr;lookup(ctx,ref,t,p);
 std::array<float,3> r{};for(int i=0;i<p->vertCount;i++)for(int k=0;k<3;k++)r[k]+=t->verts[3*p->verts[i]+k]/p->vertCount;
 return r;
}
Parents dijkstra(Context* ctx,dtPolyRef root) {
 using Item=std::pair<double,dtPolyRef>;
 std::priority_queue<Item,std::vector<Item>,std::greater<Item>> queue;
 std::unordered_map<dtPolyRef,double> cost;Parents parents;
 std::unordered_map<dtPolyRef,std::array<float,3>> centres;
 cost[root]=0;parents[root]=0;centres[root]=centre(ctx,root);queue.push({0,root});
 while(!queue.empty()) {
  auto [distance,cur]=queue.top();queue.pop();if(distance!=cost[cur])continue;
  const dtMeshTile* t=nullptr;const dtPoly* p=nullptr;lookup(ctx,cur,t,p);auto a=centres.at(cur);
  for(unsigned i=p->firstLink;i!=DT_NULL_LINK;i=t->links[i].next) {
   dtPolyRef nr=t->links[i].ref;if(!nr)continue;
   const dtMeshTile* nt=nullptr;const dtPoly* np=nullptr;if(!lookup(ctx,nr,nt,np)||!ctx->filter.passFilter(nr,nt,np))continue;
   if(!centres.count(nr))centres[nr]=centre(ctx,nr);auto b=centres.at(nr);
   double increment=0;for(int k=0;k<3;k++)increment+=std::pow(double(a[k])-b[k],2);
   double next=distance+std::sqrt(increment);
   if(!cost.count(nr)||next<cost[nr]){cost[nr]=next;parents[nr]=cur;queue.push({next,nr});}
  }
 }
 return parents;
}
bool inwindow(Context* ctx,dtPolyRef r) {
 const dtMeshTile* t=nullptr;const dtPoly* p=nullptr;lookup(ctx,r,t,p);
 float minN=1e30f,maxN=-1e30f,minW=1e30f,maxW=-1e30f;
 for(int i=0;i<p->vertCount;i++){const float* v=t->verts+3*p->verts[i];minN=std::min(minN,v[2]);maxN=std::max(maxN,v[2]);minW=std::min(minW,v[0]);maxW=std::max(maxW,v[0]);}
 return maxN>=-10900&&minN<=-10820&&maxW>=580&&minW<=720;
}
Parents localbfs(Context* ctx,dtPolyRef root,bool filtered) {
 Parents p;p[root]=0;std::vector<dtPolyRef> q{root};
 for(size_t i=0;i<q.size();i++){
  const dtMeshTile* t=nullptr;const dtPoly* poly=nullptr;lookup(ctx,q[i],t,poly);
  for(unsigned j=poly->firstLink;j!=DT_NULL_LINK;j=t->links[j].next){
   auto r=t->links[j].ref;if(!r||p.count(r)||!inwindow(ctx,r))continue;
   const dtMeshTile* nt=nullptr;const dtPoly* np=nullptr;if(!lookup(ctx,r,nt,np)||np->getType()!=DT_POLYTYPE_GROUND)continue;
   if(filtered&&!ctx->filter.passFilter(r,nt,np))continue;p[r]=q[i];q.push_back(r);
  }
 }return p;
}
void corridor(std::ostream& o,Context* ctx,const Surface& a,const Surface& b,const Parents& p) {
 auto polys=chain(p,b.ref);o<<"{\"polygon_count\":"<<polys.size()<<",\"polygons\":[";
 for(size_t i=0;i<polys.size();i++){if(i)o<<',';const dtMeshTile* t=nullptr;const dtPoly* x=nullptr;lookup(ctx,polys[i],t,x);o<<"{\"tile\":["<<t->header->x<<','<<t->header->y<<"],\"poly\":"<<(x-t->polys)<<",\"flags\":"<<x->flags<<",\"area\":"<<int(x->getArea())<<'}';}
 o<<']';if(polys.empty()){o<<'}';return;}
 std::vector<float> output(65535*3);std::vector<unsigned char> flags(65535);std::vector<dtPolyRef> refs(65535);int count=0;
 auto status=ctx->query.findStraightPath(a.p,b.p,polys.data(),polys.size(),output.data(),flags.data(),refs.data(),&count,65535,DT_STRAIGHTPATH_ALL_CROSSINGS);
 bool valid=!dtStatusFailed(status)&&count>0&&(flags[count-1]&DT_STRAIGHTPATH_END);
 double xy=0,xyz=0,deviation=0;std::array<float,4> bounds{1e30f,-1e30f,1e30f,-1e30f};
 for(int i=0;i<count;i++){
  auto ref=refs[i]?refs[i]:b.ref;float* pt=output.data()+3*i;float height=pt[1];
  if(dtStatusFailed(ctx->query.getPolyHeight(ref,pt,&height))){float closest[3];bool over=false;if(dtStatusFailed(ctx->query.closestPointOnPoly(ref,pt,closest,&over))||dtVdist2DSqr(pt,closest)>.0001f)valid=false;else height=closest[1];}pt[1]=height;
  if(i){auto prev=output.data()+3*(i-1);xy+=std::hypot(pt[0]-prev[0],pt[2]-prev[2]);xyz+=dtVdist(pt,prev);}
  bounds[0]=std::min(bounds[0],pt[2]);bounds[1]=std::max(bounds[1],pt[2]);bounds[2]=std::min(bounds[2],pt[0]);bounds[3]=std::max(bounds[3],pt[0]);
  float dx=b.p[0]-a.p[0],dz=b.p[2]-a.p[2],len=dx*dx+dz*dz;
  float fraction=len?std::max(0.f,std::min(1.f,((pt[0]-a.p[0])*dx+(pt[2]-a.p[2])*dz)/len)):0;
  deviation=std::max(deviation,double(std::hypot(pt[0]-a.p[0]-fraction*dx,pt[2]-a.p[2]-fraction*dz)));
 }
 o<<",\"straight_path_status\":"<<status<<",\"complete_with_resolved_heights\":"<<valid<<",\"length_xy\":"<<xy<<",\"length_3d\":"<<xyz<<",\"max_xy_deviation_from_endpoint_segment\":"<<deviation<<",\"bounds_north_west\":["<<bounds[0]<<','<<bounds[1]<<','<<bounds[2]<<','<<bounds[3]<<"],\"points\":[";
 for(int i=0;i<count;i++){if(i)o<<',';world(o,output.data()+3*i);}o<<"]}";
}
void pathquery(std::ostream& o,Context* ctx,const float* a,const float* b) {
 std::vector<float> points(3*65535);std::vector<uint64_t> refs(65535);int count=0,expanded=0;
 int rc=ad_path(ctx,a,b,500000,nullptr,points.data(),refs.data(),65535,&count,&expanded);
 uint32_t status=0;int why=ad_budget_reason(ctx,&status);
 double length=0;for(int i=1;i<count;i++){double d=0;for(int k=0;k<3;k++)d+=std::pow(double(points[3*i+k])-points[3*(i-1)+k],2);length+=std::sqrt(d);}
 o<<"{\"rc\":"<<rc<<",\"expanded\":"<<expanded<<",\"budget_reason\":"<<why<<",\"status\":"<<status<<",\"count\":"<<count<<",\"length3d\":"<<length<<",\"points\":[";
 for(int i=0;i<count;i++){if(i)o<<',';o<<'['<<points[3*i]<<','<<points[3*i+1]<<','<<points[3*i+2]<<']';}o<<"]}";
}
int main(int argc,char** argv) {
 try {
  if(argc!=3)throw std::runtime_error("usage probe verified-assets-list output-directory");
  const std::filesystem::path out(argv[2]);
  std::ifstream listing(argv[1]);std::string line;if(!std::getline(listing,line))throw std::runtime_error("empty asset list");
  auto bytes=readfile(line);void* handle=nullptr;if(ad_create(bytes.data(),bytes.size(),&handle))throw std::runtime_error("create failed");
  auto* ctx=static_cast<Context*>(handle);int loaded=0;
  while(std::getline(listing,line)) {if(line.empty())continue;auto b=readfile(line);if(ad_add(handle,b.data(),b.size()))throw std::runtime_error("add failed: "+line);loaded++;}
  const std::vector<NamedPoint> targets={
   {"anchor816",{-10863.542f,634.375f,31.52351188659668f}},
   {"anchor817_upper",{-10863.542f,640.625f,40.154048919677734f}},
   {"anchor817_lower",{-10863.542f,640.625f,21.44226837158203f}},
   {"anchor818_upper",{-10864.06275f,646.875f,40.44746017456055f}},
   {"anchor818_lower",{-10864.06275f,646.875f,25.598556518554688f}},
   {"anchor824",{-10867.18725f,687.50025f,31.436214447021484f}},
   {"fallback_start",{-10863.542f,621.875f,31.52351188659668f}},
   {"final_goal",{-11031.469938793904f,1498.066095269559f,43.45751953125f}}
  };
  std::vector<Surface> resolved(targets.size());std::vector<Parents> components;
  for(size_t i=0;i<targets.size();i++){if(resolve(ctx,targets[i].point.data(),resolved[i]))throw std::runtime_error("resolve failed: "+std::string(targets[i].name));components.push_back(bfs(ctx,resolved[i].ref,true));}
  auto unfiltered=bfs(ctx,resolved[0].ref,false);
  std::ofstream o(out/"topology.json");o<<std::setprecision(12)<<std::boolalpha;
  o<<"{\"loaded_tile_count\":"<<loaded<<",\"scope\":\"Exactly the 46 fixed historical query tiles; no offmesh, no blocked edges\",\"endpoints\":[";
  for(size_t i=0;i<targets.size();i++){if(i)o<<',';o<<"{\"name\":\""<<targets[i].name<<"\",\"walkable_component_count\":"<<components[i].size()<<",\"reachable_from_816_with_ground_filter\":"<<bool(components[0].count(resolved[i].ref))<<",\"reachable_from_816_ignoring_area_flags\":"<<bool(unfiltered.count(resolved[i].ref))<<",\"endpoint\":";endpoint(o,ctx,targets[i].point.data(),resolved[i]);o<<'}';}
  o<<"],\"ground_reachability_matrix\":[";
  for(size_t i=0;i<targets.size();i++){if(i)o<<',';o<<'[';for(size_t j=0;j<targets.size();j++){if(j)o<<',';o<<bool(components[i].count(resolved[j].ref));}o<<']';}
  o<<"],\"ignoring_area_flags_component_count\":"<<unfiltered.size()<<",\"queries_from_816\":[";
  for(size_t i=1;i<targets.size();i++){if(i>1)o<<',';o<<"{\"target\":\""<<targets[i].name<<"\",\"native\":";pathquery(o,ctx,targets[0].point.data(),targets[i].point.data());o<<",\"ray\":";rayjson(o,ctx,resolved[0],resolved[i]);o<<",\"unfiltered_polygon_path\":";pathjson(o,unfiltered,resolved[i].ref);o<<'}';}o<<"]}";o.close();
  localmesh((out/"local-mesh.json").string(),ctx,components[0],components[5]);
  profile((out/"profile.json").string(),ctx,components[0],components[5],components[1]);
  std::ofstream c(out/"columns.json");c<<std::setprecision(12)<<std::boolalpha;AllGroundFilter af;
  c<<"[";for(size_t i=0;i<targets.size();i++){if(i)c<<',';c<<"{\"name\":\""<<targets[i].name<<"\",\"world_xy\":["<<targets[i].point[0]<<','<<targets[i].point[1]<<"],\"all_flags\":";columnjson(c,ctx,targets[i].point[0],targets[i].point[1],&af);c<<'}';}c<<"]";
  auto weighted=dijkstra(ctx,resolved[0].ref),localGround=localbfs(ctx,resolved[0].ref,true),localAny=localbfs(ctx,resolved[0].ref,false);
  std::ofstream extra(out/"connectivity-paths.json");extra<<std::setprecision(12)<<std::boolalpha;
  extra<<"{\"scope\":\"Diagnostic corridors in exactly 46 loaded tiles; Dijkstra minimizes polygon-centre distances, not an exact geodesic; no production mesh/filter changes\",\"local_bbox_north_west\":[-10900,-10820,580,720],\"bbox_policy\":\"Include every polygon whose XY bbox intersects the window; this is a superset of polygons wholly inside\",\"local_ground_polygons\":"<<localGround.size()<<",\"local_any_flags_polygons\":"<<localAny.size()<<",\"local_ground_reaches_anchor824\":"<<bool(localGround.count(resolved[5].ref))<<",\"local_any_flags_reaches_anchor824\":"<<bool(localAny.count(resolved[5].ref))<<",\"shortest_hop_to_anchor824\":";
  corridor(extra,ctx,resolved[0],resolved[5],components[0]);extra<<",\"centroid_dijkstra_to_anchor824\":";corridor(extra,ctx,resolved[0],resolved[5],weighted);
  extra<<",\"centroid_dijkstra_resume_to_goal\":";corridor(extra,ctx,resolved[6],resolved[7],weighted);
  extra<<",\"local_ignore_flags_witness_NOT_A_WALKABLE_ROUTE\":";corridor(extra,ctx,resolved[0],resolved[5],localAny);extra<<"}";
  std::cout<<"loaded="<<loaded<<" start_component="<<components[0].size()<<" all_flags_component="<<unfiltered.size()<<std::endl;
  for(size_t i=0;i<targets.size();i++)std::cout<<targets[i].name<<" count="<<components[i].size()<<" reachable="<<bool(components[0].count(resolved[i].ref))<<" any_flags="<<bool(unfiltered.count(resolved[i].ref))<<std::endl;
  ad_destroy(handle);return 0;
 }catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 1;}
}
