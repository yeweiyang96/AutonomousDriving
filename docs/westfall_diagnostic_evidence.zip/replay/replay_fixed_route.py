"""Replay only the saved Westfall failure, preserving the complete tile index.

The historical manifest is used with v1; the new capture's exact manifest and
source bytes are used with v2. Both consume the same pinned original diagnostic
guide. Unavailable requested assets fail instead of being removed from the index.
"""
from contextlib import contextmanager
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time
import types

HERE = Path(__file__).resolve().parent
FIXTURE = HERE / 'fixture'
NATIVE_SHA = 'cf921f698b6e3e2b9ead57ae24ec234abd89c5822d00e297c4751cdb6393f284'
PLAN_SHA = '18bc407b2c9d699b808b07fb6cdd48fd45c78028a7ec53ab21962cd5b317dbb6'
sys.dont_write_bytecode = True


def sha(data):
    return hashlib.sha256(data).hexdigest()


def xyz(point):
    return [point.x, point.y, point.z]


def load_modules(version):
    package_name = '_westfall_replay_' + version
    package = types.ModuleType(package_name)
    package.__package__, package.__path__ = package_name, []
    sys.modules[package_name] = package
    modules, sources = {}, {}
    for short in ('models', 'data', 'road_corridor', 'navmesh', 'planner'):
        path = FIXTURE / 'sources' / version / (short + '.py')
        content = path.read_bytes()
        name = package_name + '.' + short
        module = types.ModuleType(name)
        module.__file__, module.__package__ = str(path), package_name
        sys.modules[name] = module
        setattr(package, short, module)
        exec(compile(content, str(path), 'exec'), module.__dict__)
        modules[short] = module
        sources[short] = {'path': str(path), 'bytes': len(content), 'sha256': sha(content)}
    return modules, sources


def run(version):
    manifest = FIXTURE / 'data/navigation' / ('manifest.reference.json' if version == 'v1' else 'manifest.json')
    output = HERE / (version + '-fixed-route.json')
    if output.exists():
        raise ValueError('Refusing to overwrite existing replay evidence')
    inventory = json.loads((FIXTURE / 'fixture-inventory.json').read_text())
    for item in inventory['inventory']:
        path = FIXTURE / item['relative_path']
        content = path.read_bytes()
        if len(content) != item['bytes'] or sha(content) != item['sha256']:
            raise ValueError('Fixture changed: ' + str(path))
    source = FIXTURE / 'reference-last-plan.json'
    diagnostic_bytes = source.read_bytes()
    if sha(diagnostic_bytes) != PLAN_SHA:
        raise ValueError('Wrong source diagnostic')
    diagnostic = json.loads(diagnostic_bytes)
    if diagnostic['start']['c'] != 0 or diagnostic['goal']['x'] != -11031.469938793904:
        raise ValueError('Wrong fixed route')
    reference = json.loads((FIXTURE / 'reference-case.json').read_text())
    if any(diagnostic[key] != reference['route'][key] for key in ('start', 'goal')):
        raise ValueError('Fixed endpoints differ from the reference case')
    modules, sources = load_modules(version)
    nav, models = modules['navmesh'], modules['models']
    original_native = nav.Native
    native_path = FIXTURE / 'native/libadrive_navmesh.so'
    if sha(native_path.read_bytes()) != NATIVE_SHA:
        raise ValueError('Pinned native replay library changed')
    def native_loader(path):
        expected = FIXTURE / 'data/navigation/adrive_navmesh.dll'
        if Path(path).resolve() != expected or sha(expected.read_bytes()) != diagnostic['native_library_sha256']:
            raise ValueError('Unexpected original Windows DLL')
        return original_native(native_path)
    nav.Native = native_loader

    class TracedMesh(nav.Mesh):
        def load(self, keys):
            keys = set(keys)
            self.pack.requested.update((self.c, *key) for key in keys)
            item = {'context': dict(self.debug_context), 'requested': sorted(keys),
                    'before_loaded': len(self.loaded), 'before_bytes': self.bytes}
            self.pack.loads.append(item)
            try:
                return super().load(keys)
            finally:
                item.update(after_loaded=len(self.loaded), after_bytes=self.bytes,
                            loaded_keys=sorted(self.loaded))

        def heights(self, point):
            result = super().heights(point)
            self.pack.surfaces.append({'point': xyz(point), 'heights': result,
                                       'trace_index': len(self.pack.last_route_diagnostics['road_trace'])})
            return result

        def path(self, start, goal, budget):
            item = {'call_index': len(self.pack.calls), 'start': xyz(start), 'goal': xyz(goal),
                    'budget': budget, 'context': dict(self.debug_context),
                    'trace_index_before': len(self.pack.last_route_diagnostics['road_trace']),
                    'loaded_tiles': len(self.loaded), 'loaded_bytes': self.bytes}
            self.pack.calls.append(item)
            try:
                segments, expanded = super().path(start, goal, budget)
                route = models.Route(start, goal, tuple(segments), expanded)
                item.update(status='success', expanded=expanded, length_xy=route.distance,
                            points=[xyz(point) for point in route.points])
                return segments, expanded
            except models.PlanningError as error:
                item.update(status=error.code, message=str(error), expanded=getattr(error, 'expanded', None),
                            native=self.native_budget_details())
                raise

    class StrictReplayPack(nav.NavMeshPack):
        def __init__(self):
            self.calls, self.surfaces, self.loads = [], [], []
            self.reads, self.failed_reads, self.requested = {}, [], set()
            super().__init__(manifest)
            self.record_diagnostics = False
            if len(self.tiles) != len(self.raw['tiles']) or len(self.tiles) != 1724:
                raise ValueError('The full manifest index was not preserved')
            if sha(json.dumps(self.raw['tiles'], sort_keys=True).encode())[:16] != self.identity:
                raise ValueError('Manifest identity mismatch')

        def read(self, entry):
            try:
                content = super().read(entry)
            except Exception as error:
                self.failed_reads.append({'entry': entry, 'error': str(error)})
                raise
            self.reads[entry['path']] = {'bytes': len(content), 'sha256': sha(content)}
            return content

        @contextmanager
        def mesh(self, continent, cancel=None):
            mesh = TracedMesh(self, continent, cancel)
            try:
                yield mesh
            finally:
                mesh.close()

    point = lambda value: models.Point(**value)
    start, goal = point(diagnostic['start']), point(diagnostic['goal'])
    if diagnostic['guide'].get('truncated'):
        raise ValueError('The saved guide is incomplete')
    guide = models.Route(start, goal, tuple(
        models.Segment(tuple(point(p) for p in segment['points']), segment['source'],
                       segment['reliability'], segment['edge_id'])
        for segment in diagnostic['guide']['segments']))
    pack = StrictReplayPack()
    began = time.monotonic()
    report = {'version': version, 'source_diagnostic': str(source), 'source_diagnostic_sha256': PLAN_SHA,
              'current_last_plan_used': False, 'sources': sources, 'manifest': str(manifest),
              'manifest_sha256': sha(manifest.read_bytes()), 'identity': pack.identity,
              'native_library_sha256': NATIVE_SHA, 'start': xyz(start), 'goal': xyz(goal),
              'guide_segments': len(guide.segments), 'guide_length_xy': guide.distance,
              'full_manifest_index_count': len(pack.tiles), 'required_fixture_tile_count': 46,
              'budget': diagnostic['max_expansions'], 'blocked_edges': diagnostic['blocked_edges']}
    try:
        route = pack.plan(start, goal, guide=guide, blocked_edges=frozenset(diagnostic['blocked_edges']),
                          max_expansions=diagnostic['max_expansions'])
        report.update(status='success', expanded=route.expanded, length_xy=route.distance,
                      length_3d=sum(math.dist(xyz(a), xyz(b)) for a, b in zip(route.points, route.points[1:])),
                      points=[xyz(p) for p in route.points])
    except models.PlanningError as error:
        report.update(status=error.code, expanded=getattr(error, 'expanded', None), message=str(error))
    report.update(elapsed_seconds=time.monotonic()-began, loads=pack.loads, calls=pack.calls,
                  surfaces=pack.surfaces, assets=pack.reads, failed_asset_reads=pack.failed_reads,
                  requested_keys=sorted(pack.requested),
                  requested_not_in_manifest=sorted(key for key in pack.requested if key not in pack.tiles),
                  requested_missing_assets=sorted(key for key in pack.requested if key in pack.tiles
                                                  and not (pack.root/pack.tiles[key]['path']).is_file()),
                  diagnostic=pack.last_route_diagnostics)
    report['loaded_missing_count'] = len(report['requested_missing_assets'])
    report['omitted_requested_tiles'] = []  # No index filtering occurs anywhere in this harness.
    trace = report['diagnostic']['road_trace']
    report['focus_road_trace'] = [{'index': index, **item} for index, item in enumerate(trace)
                                if item.get('from_anchor', -1) >= 810 or item.get('mode') == 'remaining_native_fallback']
    report['focus_native_calls'] = [item for item in pack.calls if item['status'] != 'success'
                                    or item['start'][0] < -10840]
    with output.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    summary = {k: report[k] for k in ('version','identity','status','expanded','message','elapsed_seconds',
                                     'full_manifest_index_count','loaded_missing_count') if k in report}
    summary.update(output=str(output), native_queries=len(pack.calls), surface_queries=len(pack.surfaces),
                   requested_tiles=len(pack.requested), last_call=pack.calls[-1])
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', choices=['v1', 'v2'], required=True)
    run(parser.parse_args().version)
