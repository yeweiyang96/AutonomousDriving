"""Assemble the fixed Westfall 46-tile fixture without dropping manifest entries."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
NEW = ROOT / 'westfall_route_repro/case_9ec25b57'
OLD = ROOT / 'kalimdor_bridge_repro/case_d10b202e'
OUT = HERE / 'fixture'
SOURCE_HASHES = {
    'v1': {'navmesh': '64efa0d0f8f069632644c2db11bff6dd3a72a0a437f545f23c38bd28fbbd325d',
           'road_corridor': 'f42e3cfd5b8d6053a6452afc043278512189b559913c884cdbbcd0dd1bedf7b3'},
    'v2': {'navmesh': '54f75aea3a68e43935931cc951472a9935c1725579d12f7a40775e3d4581a54e',
           'road_corridor': 'ebb294704bddf569ca2035553676920934a7d83e600af3d7c1f7a32b370301b5'},
}
DEPENDENCIES = {'models': '5e13b795e98fd67a26d659b99f73ba6c9c30b8c52e178106460c2fd5e7bb6167',
                'data': 'd25c9a508cf69cfed7d8584ce5eeb9324ed42ab1368d2d32fddbe895a0931385',
                'planner': '5b4794ad8815acc9201d357aaea7ea9d1355380abed2312481ae069445eb7123'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if OUT.exists():
        raise ValueError('Fixture already exists; refusing to overwrite it')
    reference = json.loads((NEW / 'reference-case.json').read_text())
    before_data = (OLD / 'manifest.json').read_bytes()
    diagnostic_data = (OLD / 'last-plan.json').read_bytes()
    if sha(before_data) != reference['source_manifest_sha256'] or sha(diagnostic_data) != reference['source_plan_sha256']:
        raise ValueError('Historical fixed reference changed')
    manifest_data = (NEW / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_data)
    previous = json.loads(before_data)
    if sha(json.dumps(manifest['tiles'], sort_keys=True).encode())[:16] != manifest['identity']:
        raise ValueError('Current manifest identity is not self-consistent')
    current = {(t['c'], t['row'], t['col']): t for t in manifest['tiles']}
    historic = {(t['c'], t['row'], t['col']): t for t in previous['tiles']}
    available = {tuple(t['key']): Path(t['source']) for t in
                 json.loads((ROOT / 'westfall_route_repro/local_coverage.json').read_text())['verified_here']}
    captures = set(map(tuple, reference['capture_keys']))
    planned = []
    for entry in reference['tiles']:
        key = (entry['c'], entry['row'], entry['col'])
        if current[key] != entry or historic[key] != entry:
            raise ValueError('Fixed required map0 metadata differs: ' + str(key))
        source = (NEW / 'mmaps' / ('%04d_%02d_%02d.mmtile' % key)) if key in captures else available[key]
        data = source.read_bytes()
        if len(data) != entry['bytes'] or sha(data) != entry['sha256']:
            raise ValueError('Tile bytes/SHA do not match fixed reference: ' + str(key))
        planned.append((source, Path('data/navigation') / entry['path'], data, key))
    if len(planned) != 46 or len(captures) != 12 or len(available) != 34:
        raise ValueError('Unexpected fixed fixture cardinality')
    nav_original = ROOT / 'navigation_repro/case_87e934c9/data/navigation'
    for entry in manifest['maps']:
        source = NEW / 'mmaps/0000.mmap' if entry['c'] == 0 else ROOT / 'kalimdor_bridge_repro/case_d10b202e/0001.mmap'
        data = source.read_bytes()
        if len(data) != entry['bytes'] or sha(data) != entry['sha256']:
            raise ValueError('Map header differs')
        planned.append((source, Path('data/navigation') / entry['path'], data, None))
    library = manifest['library']
    source = nav_original / library['path']
    data = source.read_bytes()
    if len(data) != library['bytes'] or sha(data) != library['sha256'] or data[:2] != b'MZ':
        raise ValueError('Original Windows DLL changed')
    planned.append((source, Path('data/navigation') / library['path'], data, None))
    for version, directory in [('v1', ROOT/'route_quality_repro/working/adrive'), ('v2', NEW/'adrive')]:
        for name, expected in {**DEPENDENCIES, **SOURCE_HASHES[version]}.items():
            source = directory / (name+'.py')
            data = source.read_bytes()
            if sha(data) != expected:
                raise ValueError('Source changed: ' + version + '/' + name)
            planned.append((source, Path('sources') / version / (name+'.py'), data, None))
    for source, relative, expected in [
        (ROOT/'navigation_repro/replay/libadrive_navmesh.so', Path('native/libadrive_navmesh.so'),
         'cf921f698b6e3e2b9ead57ae24ec234abd89c5822d00e297c4751cdb6393f284'),
        (ROOT/'route_quality_repro/case_d2f9f429/data/bundle.json', Path('data/bundle.json'),
         '9d5065b341ec1063f083e319807c12d3f47eb2c67d2f8a11f23a20b2d6b1fd18'),
    ]:
        data = source.read_bytes()
        if sha(data) != expected:
            raise ValueError('Pinned replay input changed: ' + str(source))
        planned.append((source, relative, data, None))
    planned += [(NEW/'manifest.json', Path('data/navigation/manifest.json'), manifest_data, None),
                (OLD/'manifest.json', Path('data/navigation/manifest.reference.json'), before_data, None),
                (OLD/'last-plan.json', Path('reference-last-plan.json'), diagnostic_data, None),
                (NEW/'reference-case.json', Path('reference-case.json'), (NEW/'reference-case.json').read_bytes(), None)]
    OUT.mkdir()
    inventory = []
    for source, relative, data, key in planned:
        path = OUT / relative
        if not path.resolve().is_relative_to(OUT.resolve()):
            raise ValueError('Fixture destination escapes root')
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as stream:
            stream.write(data)
        if sha(path.read_bytes()) != sha(data):
            raise ValueError('Fixture copy verification failed')
        inventory.append(dict(source=str(source), relative_path=relative.as_posix(), key=key,
                              bytes=len(data), sha256=sha(data)))
    report = dict(fixture=str(OUT), required_tile_count=46, supplied_new_tiles=12, supplied_prior_tiles=34,
                  required_tiles_missing=0, full_manifest_index_retained=len(manifest['tiles']),
                  requested_keys_known_in_advance=[(t['c'],t['row'],t['col']) for t in reference['tiles']],
                  current_identity=manifest['identity'], historical_identity=previous['identity'],
                  source_plan_sha256=sha(diagnostic_data), tile_bytes=sum(t['bytes'] for t in reference['tiles']),
                  note='Unrequested manifest entries are retained; a requested unavailable asset must fail, never be filtered.',
                  inventory=inventory)
    (OUT/'fixture-inventory.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('inventory','requested_keys_known_in_advance')}, indent=2))


if __name__ == '__main__':
    main()
