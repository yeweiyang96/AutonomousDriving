from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
OUT = ROOT / 'deliverables' / 'kalimdor_bridge_repair_evidence.zip'

files = {}
allowed = {'.py', '.cpp', '.json', '.md', '.patch', '.bin', '.pmesh', '.dmesh', '.mmtile'}
for folder in ('generation_replay', 'source_analysis', 'candidate_validation', 'installer_work'):
    for path in (ROOT/folder).rglob('*'):
        if path.is_file() and path.suffix in allowed and '__pycache__' not in path.parts:
            files[path.relative_to(WORKSPACE).as_posix()] = path
for path in (ROOT/'candidate/adrive').glob('*.py'):
    files[path.relative_to(WORKSPACE).as_posix()] = path
for rel in ('tests/test_fallback_guard.py', 'tests/test_apply_kalimdor_bridge_fix.py',
            'make_repair_comparison.py', 'make_repair_bundle.py',
            'deliverables/apply_kalimdor_bridge_fix.py',
            'deliverables/kalimdor_bridge_repair_report.md',
            'deliverables/kalimdor_bridge_repair_comparison.png'):
    path = ROOT/rel
    if not path.is_file():
        raise RuntimeError('Required final deliverable missing: '+str(path))
    files[path.relative_to(WORKSPACE).as_posix()] = path

readme = '''# Kalimdor bridge repair evidence

The standalone Windows installer is included under
kalimdor_bridge_repro/deliverables/apply_kalimdor_bridge_fix.py.
Use the Chinese report beside it for results, installation and rollback.

This archive preserves analysis, generated meshes, candidate source,
reproduction scripts, installer source/tests and measured native results.
It is an analysis checkpoint, not a second installer. Binary executables,
bytecode caches and the 100 MB of reproducible per-cell CSV traces are omitted.

Analysis scripts retain their recorded workspace layout and need the original
input/source bundles. They are not advertised as a self-contained build kit.
The original inputs are unchanged and remain available in these files:

- Original bridge collision/generation capture:
  https://chatgpt.com/library?file_id=libfile_7860200b69208191be4620b989ce39cd&account_id=personal
- Original nine map1 navigation tiles and manifest:
  https://chatgpt.com/library?file_id=libfile_d10b202e30848191b953acd7f7606dbd&account_id=personal
- Original map1 route diagnostic:
  https://chatgpt.com/library?file_id=libfile_20d20a578a588191a80ca39dbb9b695b&account_id=personal
- Previously captured generator source and raw evidence:
  https://chatgpt.com/library?file_id=libfile_fe9a753111f08191ba8828d680b4d1d8&account_id=personal

Old map0 regressions reuse the earlier route_quality_repro and
navigation_repro fixtures. Their three missing peripheral request tiles are
explicitly recorded in candidate_validation reports. The installer does not
omit missing tiles; its Windows validation must succeed before activation.

Only the target map1 tile and two planner modules are included in the repair.
No claim is made that the separate new Westfall case is fixed.
'''

members = []
with zipfile.ZipFile(OUT, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, content in [('README.md', readme.encode()),
                          *[(name, path.read_bytes()) for name, path in sorted(files.items())]]:
        archive.writestr(name, content)
        members.append({'path':name, 'bytes':len(content), 'sha256':hashlib.sha256(content).hexdigest()})
    archive.writestr('inventory.json', json.dumps({'schema':1,'members':members},indent=2)+'\n')
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for row in members:
        content = archive.read(row['path'])
        assert len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']
print(json.dumps({'path':str(OUT),'members':len(members)+1,'bytes':OUT.stat().st_size,
                  'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()}))
