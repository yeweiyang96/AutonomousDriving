"""Assemble the single-file installer from frozen local inputs."""
import ast
import base64
import hashlib
import json
from pathlib import Path
import pprint
import zlib

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'kalimdor_bridge_repro/deliverables/apply_kalimdor_bridge_fix.py'


def assignments(path, names):
    result = {}
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    value = node.value
                    if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'dict' and not value.args:
                        result[target.id] = {item.arg: ast.literal_eval(item.value) for item in value.keywords}
                    else:
                        result[target.id] = ast.literal_eval(value)
    if result.keys() != names:
        raise ValueError('Missing frozen constant')
    return result


old = assignments(ROOT / 'route_quality_repro/deliverables/apply_route_quality_fix.py',
                  {'DLL_SHA', 'BUNDLE_SHA', 'SOURCE_HASHES', 'SETTINGS', 'CLIENT',
                   'SHORT_A', 'SHORT_B', 'LONG_A', 'LONG_B', 'ACCEPTANCE_GATES', 'BRIDGE_WINDOWS'})
patch = assignments(ROOT / 'generation_repro/deliverables/apply_bridge_fix.py', {'SOURCE_PATCH'})['SOURCE_PATCH']
manifest = json.loads((ROOT / 'kalimdor_bridge_repro/case_d10b202e/manifest.json').read_text())
candidate = ROOT / 'kalimdor_bridge_repro/generation_replay/higher-span-area-monotone/reconverted.mmtile'
module_dir = ROOT / 'kalimdor_bridge_repro/candidate/adrive'
expected = {
    'tile': 'd8497ef8ac2cb510a2b950af4e24360d746cbe7f71699773c2ad3bcbd824f7ce',
    'navmesh': '54f75aea3a68e43935931cc951472a9935c1725579d12f7a40775e3d4581a54e',
    'road_corridor': 'ebb294704bddf569ca2035553676920934a7d83e600af3d7c1f7a32b370301b5',
}
payload = {}
for name, path in [('tile', candidate), ('navmesh', module_dir/'navmesh.py'), ('road_corridor', module_dir/'road_corridor.py')]:
    data = path.read_bytes()
    value = hashlib.sha256(data).hexdigest()
    if value != expected[name]:
        raise ValueError('Frozen candidate changed: ' + name)
    payload[name] = {'bytes': len(data), 'sha256': value, 'b85': base64.b85encode(zlib.compress(data, 9)).decode('ascii')}
constants = dict(
    VERSION='kalimdor-bridge-0001-37-38-v1',
    REPAIR_ID='kalimdor-bridge-0001-37-38-d8497ef8ac2c-v2',
    DEFAULT_ROOT=r'D:\wangzekun\Documents\AutonomousDriving',
    TARGET=(1, 37, 38), BEFORE_IDENTITY='9e09d71b0068bb29',
    OLD_TILE_SHA='bf81052e0ebbc9e5bbd58e2ae269181b14c0e59e9a2f9874d5ba6707e292a825',
    OLD_TILE_BYTES=1008288, NEW_TILE_SHA=expected['tile'], NEW_TILE_BYTES=payload['tile']['bytes'],
    OLD_SOURCE_HASHES={'navmesh': '64efa0d0f8f069632644c2db11bff6dd3a72a0a437f545f23c38bd28fbbd325d',
                       'road_corridor': 'f42e3cfd5b8d6053a6452afc043278512189b559913c884cdbbcd0dd1bedf7b3'},
    NEW_SOURCE_HASHES={k: expected[k] for k in ('navmesh', 'road_corridor')},
    MAP_HASHES={m['c']: m['sha256'] for m in manifest['maps']},
    MAP0_BRIDGE_SHA='74dd28d4d559518bca84b678ac3fb3ccd5ba294c8ab65bebcede927acc46df1c',
    RAW_GEOMETRY_SHA='a658249ea0abee414fea9933224353022a2b53ee79836cc35dc4c75052185f3c',
    NEIGHBORS=[t for t in manifest['tiles'] if t['c'] == 1 and 36 <= t['row'] <= 38 and 37 <= t['col'] <= 39],
    FILE_LIMIT=32*1024*1024, SOURCE_PATCH=patch,
    **old,
)
a = (-2820.714451053201, -3396.102114364935, None)
b = (-2834.214451053201, -3348.352114364935, None)
gates = constants['ACCEPTANCE_GATES']
cases = []
for label, start, goal, guided, start_z, goal_z in [
    ('bridge_A_to_B', a, b, True, 32.11293029785156, 31.82605743408203),
    ('bridge_B_to_A', b, a, True, 31.82605743408203, 32.11293029785156),
    ('bridge_A_to_B_direct', a, b, False, 32.11293029785156, 31.82605743408203),
    ('bridge_B_to_A_direct', b, a, False, 31.82605743408203, 32.11293029785156),
]:
    cases.append((label, 1, start, goal, guided))
    gates[label] = dict(min_length_3d=48, max_length_3d=55, max_expanded=4096,
                       max_reversed_axis_yards=1, max_road_deviation_yards=6,
                       start_surface_z=start_z, goal_surface_z=goal_z)
for label, start, goal in [('short_A_to_B', old['SHORT_A'], old['SHORT_B']),
                           ('short_B_to_A', old['SHORT_B'], old['SHORT_A']),
                           ('known_long_route', old['LONG_A'], old['LONG_B']),
                           ('known_long_reverse', old['LONG_B'], old['LONG_A'])]:
    cases.append((label, 0, start, goal, True))
constants['VALIDATION_CASES'] = tuple(cases)
header = '''#!/usr/bin/env python3
"""Validate and install the one-tile Kalimdor bridge repair and v2 route guard.

Uses the current Windows DLL before activation. Writes exact backups, then
atomically replaces helper, planner and manifest in that order. --rollback only
restores this update's exact matching saved state. No WSL or compiler is used.
"""
from __future__ import annotations

import argparse
import base64
from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import stat
import struct
import sys
import tempfile
import types
import uuid
import zlib

ANY = object()

'''
text = header + '\n\n'.join(name+' = '+pprint.pformat(value, width=110, sort_dicts=False)
                            for name, value in constants.items()) + '\n\n\n'
text += (HERE/'reused_core.py').read_text() + '\n\n' + (HERE/'combined_core.py').read_text()
# Keep payload after all reviewable logic, in bounded-width literal chunks.
text += '\n\n# Frozen exact payloads, zlib + Base85; verified before use.\nPAYLOAD = {\n'
for name, record in payload.items():
    text += '    '+repr(name)+': {\n'
    text += '        "bytes": '+str(record['bytes'])+',\n        "sha256": '+repr(record['sha256'])+',\n        "b85": (\n'
    value = record['b85']
    text += '\n'.join('            '+repr(value[i:i+110]) for i in range(0, len(value), 110))
    text += '\n        ),\n    },\n'
text += '}\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n'
compile(text, str(OUT), 'exec')
OUT.write_text(text)
print(json.dumps({'path': str(OUT), 'bytes': OUT.stat().st_size,
                  'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest()}, indent=2))
