def say(message):
    print(message, flush=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def beneath(base, path):
    base = Path(base).resolve()
    path = Path(path)
    result = path.resolve()
    if not result.is_relative_to(base):
        raise ValueError('Path escapes the permitted directory: ' + str(path))
    current = base
    for part in path.relative_to(base).parts:
        current /= part
        try:
            details = current.lstat()
        except FileNotFoundError:
            break
        if stat.S_ISLNK(details.st_mode) or getattr(details, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
            raise ValueError('Linked/reparse path is not accepted: ' + str(current))
    return result


def asset(base, relative):
    if not isinstance(relative, str) or '\\' in relative or ':' in relative:
        raise ValueError('Invalid relative navigation path')
    name = PurePosixPath(relative)
    if name.is_absolute() or not name.parts or any(p in ('.', '..') for p in name.parts):
        raise ValueError('Unsafe relative navigation path')
    return beneath(base, Path(base).joinpath(*name.parts))


def read(path):
    if not path.is_file() or path.stat().st_size > FILE_LIMIT:
        raise ValueError('Missing or oversized input: ' + str(path))
    with path.open('rb') as stream:
        data = stream.read(FILE_LIMIT + 1)
    if len(data) > FILE_LIMIT:
        raise ValueError('Input grew beyond the read limit: ' + str(path))
    return data


def remember(snapshots, path, data):
    value = {'bytes': len(data), 'sha256': sha(data)}
    previous = snapshots.get(path, ANY)
    if previous is not ANY and previous != value:
        raise RuntimeError('Input changed during validation: ' + str(path))
    snapshots[path] = value


def recheck(snapshots, root):
    for path, value in snapshots.items():
        beneath(root, path)
        if value is None:
            if path.exists() or path.is_symlink():
                raise RuntimeError('A previously absent file appeared: ' + str(path))
        else:
            data = read(path)
            if len(data) != value['bytes'] or sha(data) != value['sha256']:
                raise RuntimeError('Input changed during validation: ' + str(path))


def atomic_replace(path, data, expected=ANY, *, root=None):
    if root is not None:
        beneath(root, path)
    handle, name = tempfile.mkstemp(prefix='.kalimdor-bridge-', suffix='.tmp', dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(handle, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        # An optimistic comparison immediately before atomic replacement, not
        # an operating-system compare-and-swap operation.
        if expected is None:
            if path.exists() or path.is_symlink():
                raise RuntimeError('Destination appeared before replacement: ' + str(path))
        elif expected is not ANY and read(path) != expected:
            raise RuntimeError('Destination changed before replacement: ' + str(path))
        if root is not None:
            beneath(root, path)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def durable_new(path, data, *, root=None):
    if root is not None:
        beneath(root, path)
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def checked_asset(nav, entry, snapshots):
    path = asset(nav, entry['path'])
    data = read(path)
    if len(data) != entry['bytes'] or sha(data) != entry['sha256']:
        raise ValueError('Navigation integrity check failed: ' + str(path))
    remember(snapshots, path, data)
    return path, data


@contextmanager
def candidate_modules(payload, inputs):
    name = '_kalimdor_bridge_probe_' + uuid.uuid4().hex
    package = types.ModuleType(name)
    package.__path__ = []
    package.__package__ = name
    sys.modules[name] = package
    modules = {}
    try:
        for short in ('models', 'data', 'road_corridor', 'navmesh', 'planner'):
            content = payload[short] if short in payload else inputs['sources'][short]
            module_name = name + '.' + short
            module = types.ModuleType(module_name)
            module.__package__ = name
            module.__file__ = str(inputs['nav_source'].parent / (short + '.py'))
            sys.modules[module_name] = module
            setattr(package, short, module)
            exec(compile(content, module.__file__, 'exec'), module.__dict__)
            modules[short] = module
        yield modules
    finally:
        for module_name in list(sys.modules):
            if module_name == name or module_name.startswith(name + '.'):
                del sys.modules[module_name]


def clip_segment(a, b, bounds):
    lower, upper = 0.0, 1.0
    for k, (lo, hi) in enumerate(bounds):
        delta = b[k] - a[k]
        if abs(delta) < 1e-14:
            if not lo <= a[k] <= hi:
                return None
        else:
            p, q = (lo-a[k])/delta, (hi-a[k])/delta
            if p > q:
                p, q = q, p
            lower, upper = max(lower, p), min(upper, q)
            if lower > upper:
                return None
    return ([a[k]+lower*(b[k]-a[k]) for k in (0, 1)],
            [a[k]+upper*(b[k]-a[k]) for k in (0, 1)])


def bridge_window_checks(points, *, reverse=False):
    """Measure the two fixed regression windows; never edit route geometry."""
    results = []
    for window in BRIDGE_WINDOWS:
        bounds = (window['north_bounds'], window['west_bounds'])
        indices = [i for i, p in enumerate(points)
                   if all(lo <= p[k] <= hi for k, (lo, hi) in enumerate(bounds))]
        vector = [b-a for a, b in zip(window['forward_from'], window['forward_to'])]
        norm = math.hypot(*vector)
        axis = [v/norm*(-1 if reverse else 1) for v in vector]
        backward = 0.0
        for a, b in zip(points, points[1:]):
            clipped = clip_segment(a, b, bounds)
            if clipped is not None:
                u, v = clipped
                progress = sum((v[k]-u[k])*axis[k] for k in (0, 1))
                backward += max(0.0, -progress)
        progress = (sum((points[indices[-1]][k]-points[indices[0]][k])*axis[k] for k in (0, 1))
                    if len(indices) >= 2 else 0.0)
        results.append(dict(window=window['name'], reverse=reverse, actual_points_inside=len(indices),
                            net_forward_progress_yards=progress, backward_progress_yards=backward,
                            backward_tolerance_yards=1.0,
                            passed=len(indices) >= 2 and progress > 1.0 and backward <= 1.0))
    return results


def road_reference(start, goal, guide):
    """Original soft-road reference, without coarse terrain cell centres."""
    points = [[start.x, start.y]]
    for segment in guide.segments if guide is not None else ():
        if segment.reliability not in ('reviewed', 'candidate'):
            continue
        for p in segment.points:
            point = [p.x, p.y]
            if math.dist(points[-1], point) > 1e-5:
                points.append(point)
    last = [goal.x, goal.y]
    if math.dist(points[-1], last) > 1e-5 or len(points) == 1:
        points.append(last)
    else:
        points[-1] = last
    return points


def curve_samples(points):
    yield points[0][:2]
    for a, b in zip(points, points[1:]):
        distance = math.hypot(b[0]-a[0], b[1]-a[1])
        count = max(1, math.ceil(distance))
        for k in range(1, count+1):
            fraction = k/count
            yield (a[0]+fraction*(b[0]-a[0]), a[1]+fraction*(b[1]-a[1]))


def sampled_curve_distance(points, polyline):
    spans = [(a[0], a[1], b[0]-a[0], b[1]-a[1], (b[0]-a[0])**2+(b[1]-a[1])**2)
             for a, b in zip(polyline, polyline[1:])]
    maximum, sample_count = 0.0, 0
    for x, y in curve_samples(points):
        nearest = math.inf
        for ax, ay, dx, dy, denominator in spans:
            fraction = max(0.0, min(1.0, ((x-ax)*dx+(y-ay)*dy)/denominator)) if denominator else 0.0
            squared = (x-ax-fraction*dx)**2 + (y-ay-fraction*dy)**2
            nearest = min(nearest, squared)
        maximum = max(maximum, nearest)
        sample_count += 1
    return math.sqrt(maximum), sample_count


def route_record(label, route, guide, start, goal, identity):
    points = route.points
    values = [[p.x, p.y, p.z] for p in points]
    if len(values) < 2 or not all(v is not None and math.isfinite(v) for p in values for v in p):
        raise ValueError('Candidate returned an incomplete or non-finite path: ' + label)
    if not route.segments or any(p.c != start.c for p in points):
        raise ValueError('Candidate returned no verified segments or changed continent: ' + label)
    prefix = 'nav:%s:%d:' % (identity, start.c)
    if any(s.reliability != 'navmesh' or not s.edge_id.startswith(prefix) for s in route.segments):
        raise ValueError('Candidate returned a segment outside the current native navigation context: ' + label)
    for a, b in zip(route.segments, route.segments[1:]):
        p, q = a.points[-1], b.points[0]
        if math.dist((p.x, p.y, p.z), (q.x, q.y, q.z)) > .05:
            raise ValueError('Candidate route contains a discontinuous segment join: ' + label)
    for actual, requested in ((points[0], start), (points[-1], goal)):
        if abs(actual.x-requested.x) > 1e-5 or abs(actual.y-requested.y) > 1e-5:
            raise ValueError('Candidate relocated a requested XY endpoint: ' + label)
    length = sum(math.dist(a, b) for a, b in zip(values, values[1:]))
    dx, dy = goal.x-start.x, goal.y-start.y
    direct = math.hypot(dx, dy)
    progress = [((p.x-start.x)*dx + (p.y-start.y)*dy)/direct for p in points]
    reversed_axis = sum(max(0.0, a-b) for a, b in zip(progress, progress[1:]))
    reference = road_reference(start, goal, guide)
    path_to_road, path_samples = sampled_curve_distance(values, reference)
    road_to_path, road_samples = sampled_curve_distance(reference, values)
    record = dict(name=label, start=[start.x, start.y, start.z], goal=[goal.x, goal.y, goal.z],
                  points=values, length_xy=route.distance, length_3d=length,
                  expanded=route.expanded, reversed_endpoint_axis_yards=reversed_axis,
                  coarse_guide_segments=len(guide.segments) if guide else 0, coarse_guide_expanded=guide.expanded if guide else 0,
                  guide_present=guide is not None, blocked_edges=[], road_reference=reference,
                  road_corridor_deviation=dict(route_to_reference_max_yards=path_to_road,
                                               reference_to_route_max_yards=road_to_path,
                                               sample_spacing_at_most_yards=1.0,
                                               route_sample_count=path_samples, reference_sample_count=road_samples))
    if label in ('known_long_route', 'known_long_reverse'):
        record['bridge_windows'] = bridge_window_checks(values, reverse=label == 'known_long_reverse')
    return record
