def payload_bytes():
    result = {}
    if set(PAYLOAD) != {'tile', 'navmesh', 'road_corridor'}:
        raise ValueError('Unexpected embedded payload members')
    for name, item in PAYLOAD.items():
        data = zlib.decompress(base64.b85decode(item['b85']))
        if len(data) != item['bytes'] or len(data) > FILE_LIMIT or sha(data) != item['sha256']:
            raise ValueError('Embedded payload integrity failed: ' + name)
        if name != 'tile':
            compile(data, name + '.py', 'exec')
        result[name] = data
    tile = result['tile']
    header = struct.unpack_from('<4IB3B', tile)
    mesh = struct.unpack_from('<15i', tile, 20)
    if header != (0x4d4d4150, 7, 16, len(tile)-20, 1, 0, 0, 0):
        raise ValueError('Unexpected candidate tile header')
    if mesh[:6] != (0x444e4156, 7, 10, 18, 0, 0) or mesh[13] != 0:
        raise ValueError('Unexpected candidate tile coordinates or off-mesh links')
    if struct.unpack_from('<3f', tile, 80) != (1.5999995470046997, .5333331823348999, .5333331823348999):
        raise ValueError('Candidate agent dimensions changed')
    if sha(tile) != NEW_TILE_SHA or len(tile) != NEW_TILE_BYTES:
        raise ValueError('Candidate tile differs from the frozen native-verified tile')
    for name in ('navmesh', 'road_corridor'):
        if sha(result[name]) != NEW_SOURCE_HASHES[name]:
            raise ValueError('Candidate planner differs from its frozen version')
    return result


def index_identity(raw):
    return sha(json.dumps(raw['tiles'], sort_keys=True).encode())[:16]


def validate_manifest(root, nav, raw, snapshots):
    if (raw.get('schema'), raw.get('kind'), raw.get('mmap_version')) != (1, 'adrive-ground-navmesh', 16):
        raise ValueError('Unsupported navigation manifest')
    for category, expected in [('client', CLIENT), ('settings', SETTINGS)]:
        if raw.get(category) != expected:
            raise ValueError('Captured client or agent settings changed: ' + category)
    tiles = {(t['c'], t['row'], t['col']): t for t in raw['tiles']}
    maps = {m['c']: m for m in raw['maps']}
    if len(tiles) != len(raw['tiles']) or len(maps) != len(raw['maps']) or set(maps) != {0, 1}:
        raise ValueError('Duplicate or incomplete navigation index')
    if index_identity(raw) != raw.get('identity'):
        raise ValueError('Navigation identity does not match the indexed tiles')
    if type(raw.get('bytes')) is not int or raw['bytes'] != sum(t['bytes'] for t in raw['tiles']):
        raise ValueError('Navigation aggregate byte count is inconsistent')
    if raw.get('tile_count') != len(tiles):
        raise ValueError('Navigation tile count is inconsistent')
    target = tiles.get(TARGET, {})
    actual = (target.get('sha256'), target.get('bytes'))
    if actual == (OLD_TILE_SHA, OLD_TILE_BYTES):
        tile_state = 'original'
        if raw['identity'] != BEFORE_IDENTITY:
            raise ValueError('Original navigation identity differs from the captured baseline')
    elif actual == (NEW_TILE_SHA, NEW_TILE_BYTES):
        tile_state = 'candidate'
    else:
        raise ValueError('Target tile contains an unknown change; refusing to overwrite it')
    for expected in NEIGHBORS:
        key = (expected['c'], expected['row'], expected['col'])
        current = tiles.get(key, {})
        fields = ('mesh_x', 'mesh_y') if key == TARGET else ('bytes', 'sha256', 'mesh_x', 'mesh_y')
        if any(current.get(field) != expected[field] for field in fields):
            raise ValueError('A required Kalimdor neighbor changed: ' + str(key))
    if (tiles.get((0, 50, 34), {}).get('sha256'), tiles.get((0, 50, 34), {}).get('bytes')) != (MAP0_BRIDGE_SHA, 888768):
        raise ValueError('The previously verified map0 bridge repair is not active')
    for continent, expected_sha in MAP_HASHES.items():
        if (maps[continent].get('sha256'), maps[continent].get('bytes')) != (expected_sha, 40):
            raise ValueError('Navigation map header changed: ' + str(continent))
    library = raw['library']
    if (library.get('sha256'), library.get('bytes')) != (DLL_SHA, 169472):
        raise ValueError('Current Windows DLL differs from the captured version')
    entries = [*raw['maps'], *raw['tiles'], library]
    for entry in entries:
        asset(nav, entry['path'])
    dll_path, _ = checked_asset(nav, library, snapshots)
    for entry in maps.values():
        checked_asset(nav, entry, snapshots)
    for expected in NEIGHBORS:
        checked_asset(nav, tiles[(expected['c'], expected['row'], expected['col'])], snapshots)
    checked_asset(nav, tiles[(0, 50, 34)], snapshots)
    return dict(target=target, tile_state=tile_state, tiles=tiles, maps=maps,
                dll_path=dll_path, allowed_entries={(e['path'], e['bytes'], e['sha256']) for e in entries})


def preflight(root, payload, snapshots):
    sources = {}
    for name, expected in SOURCE_HASHES.items():
        path = beneath(root, root / 'adrive' / (name + '.py'))
        data = read(path)
        if sha(data) != expected:
            raise ValueError('Required planner dependency changed: ' + str(path))
        remember(snapshots, path, data)
        sources[name] = data
    before_sources, source_paths, source_states = {}, {}, {}
    for name in ('navmesh', 'road_corridor'):
        path = beneath(root, root / 'adrive' / (name + '.py'))
        data = read(path)
        value = sha(data)
        if value == OLD_SOURCE_HASHES[name]:
            source_states[name] = 'original'
        elif data == payload[name]:
            source_states[name] = 'candidate'
        else:
            raise ValueError(name + '.py contains an unknown change; refusing to overwrite it')
        remember(snapshots, path, data)
        before_sources[name], source_paths[name] = data, path
    bundle_path = beneath(root, root / 'data/bundle.json')
    bundle = read(bundle_path)
    if sha(bundle) != BUNDLE_SHA:
        raise ValueError('Road bundle differs from the captured case')
    remember(snapshots, bundle_path, bundle)
    nav = beneath(root, root / 'data/navigation')
    manifest = beneath(nav, nav / 'manifest.json')
    manifest_bytes = read(manifest)
    raw = json.loads(manifest_bytes.decode('utf-8-sig'))
    remember(snapshots, manifest, manifest_bytes)
    details = validate_manifest(root, nav, raw, snapshots)
    return dict(root=root, nav=nav, manifest=manifest, manifest_bytes=manifest_bytes,
                raw=raw, sources=sources, nav_source=source_paths['navmesh'],
                source_paths=source_paths, before_sources=before_sources,
                source_states=source_states, bundle_path=bundle_path, **details)


def repair_record(prefix):
    return dict(id=REPAIR_ID, tile=list(TARGET), provenance=prefix+'repair.json',
                manifest_before=prefix+'manifest.before.json', manifest_after=prefix+'manifest.after.json')


def changed_manifest(before, prefix):
    after = copy.deepcopy(before)
    target = next(t for t in after['tiles'] if (t['c'], t['row'], t['col']) == TARGET)
    if (target['sha256'], target['bytes'], before['identity']) != (OLD_TILE_SHA, OLD_TILE_BYTES, BEFORE_IDENTITY):
        raise ValueError('The saved before-manifest is not the captured original state')
    target.update(path=prefix+'0001_37_38.mmtile', bytes=NEW_TILE_BYTES, sha256=NEW_TILE_SHA)
    after['identity'] = index_identity(after)
    after['bytes'] += NEW_TILE_BYTES - OLD_TILE_BYTES
    repairs = after.setdefault('repairs', [])
    if not isinstance(repairs, list) or any(isinstance(item, dict) and item.get('id') == REPAIR_ID for item in repairs):
        raise ValueError('Conflicting existing repair metadata')
    repairs.append(repair_record(prefix))
    return after


def check_gate(record):
    gate = ACCEPTANCE_GATES[record['name']]
    if not gate['min_length_3d'] <= record['length_3d'] < gate['max_length_3d']:
        raise ValueError('Candidate failed route-length acceptance: ' + record['name'])
    if not 0 <= record['expanded'] <= gate['max_expanded']:
        raise ValueError('Candidate failed expansion-cost acceptance: ' + record['name'])
    if 'max_reversed_axis_yards' in gate and record['reversed_endpoint_axis_yards'] >= gate['max_reversed_axis_yards']:
        raise ValueError('Candidate route still backtracks: ' + record['name'])
    for index, key in ((0, 'start_surface_z'), (-1, 'goal_surface_z')):
        if abs(record['points'][index][2] - gate[key]) > .05:
            raise ValueError('Candidate selected a different endpoint surface: ' + record['name'])
    deviation = record['road_corridor_deviation']
    if max(deviation['route_to_reference_max_yards'], deviation['reference_to_route_max_yards']) > gate['max_road_deviation_yards']:
        raise ValueError('Candidate left or skipped the measured corridor: ' + record['name'])
    if 'bridge_windows' in record and not all(item['passed'] for item in record['bridge_windows']):
        raise ValueError('Candidate failed the previously verified map0 bridge windows')
    diagnostic = record.get('road_diagnostics')
    if not diagnostic or diagnostic.get('planner_version') != 'road-corridor-v2' or diagnostic.get('result', {}).get('status') != 'success':
        raise ValueError('Candidate did not expose successful v2 query diagnostics')
    if record['guide_present']:
        trace = diagnostic.get('road_trace', [])
        if not any(row.get('accepted') for row in trace) or any(row.get('mode') == 'remaining_native_fallback' for row in trace):
            raise ValueError('Candidate bypassed expected road-following validation')


def verify_native(payload, inputs, proposed, snapshots, report, native_factory=None):
    with candidate_modules(payload, inputs) as modules:
        nav, data, models, planner = (modules[name] for name in ('navmesh', 'data', 'models', 'planner'))
        original_native = nav.Native
        def pinned_native(path):
            if Path(path).resolve() != inputs['dll_path']:
                raise ValueError('Unexpected DLL selected during the candidate probe')
            beneath(inputs['root'], path)
            if sha(read(inputs['dll_path'])) != DLL_SHA:
                raise ValueError('DLL changed before the native probe')
            return native_factory(original_native, path) if native_factory else original_native(path)
        nav.Native = pinned_native
        candidate_entry = next(t for t in proposed['tiles'] if (t['c'], t['row'], t['col']) == TARGET)
        class SnapshotPack(nav.NavMeshPack):
            def read(self, entry):
                if entry == candidate_entry:
                    return payload['tile']
                if (entry['path'], entry['bytes'], entry['sha256']) not in inputs['allowed_entries']:
                    raise ValueError('An unverified manifest entry was selected by the probe')
                _, content = checked_asset(inputs['nav'], entry, snapshots)
                return content
        bundle = data.DataBundle.load(inputs['bundle_path'])
        coarse = planner.Planner(bundle)
        report['native_queries'] = []
        for label, continent, a, b, guided in VALIDATION_CASES:
            say('验证路线 ' + label + ' ...')
            start, goal = models.Point(continent, *a), models.Point(continent, *b)
            guide = coarse._plan_coarse(start, goal, allow_candidates=False) if guided else None
            pack = SnapshotPack(inputs['manifest'])
            if pack.raw != inputs['raw']:
                raise ValueError('Active manifest changed before a candidate query')
            # All candidate entries are in memory; the active manifest/tile is untouched.
            pack.raw = copy.deepcopy(proposed)
            pack.identity = proposed['identity']
            pack.tiles = {(t['c'], t['row'], t['col']): t for t in pack.raw['tiles']}
            pack.maps = {t['c']: t for t in pack.raw['maps']}
            pack.record_diagnostics = False
            route = pack.plan(start, goal, guide=guide, blocked_edges=frozenset())
            record = route_record(label, route, guide, start, goal, proposed['identity'])
            record['road_diagnostics'] = pack.last_route_diagnostics
            report['native_queries'].append(record)
            check_gate(record)
            say('  通过：%.4f 码，%d 个点，展开 %d 次' %
                (record['length_3d'], len(record['points']), record['expanded']))
    report['native_validation_passed'] = True


def load_receipt(inputs, folder, payload, snapshots):
    root, nav = inputs['root'], inputs['nav']
    folder = beneath(nav, folder)
    if folder.parent != nav / 'repairs' or not folder.name.startswith('kalimdor-bridge-0001-37-38-'):
        raise ValueError('Receipt directory is outside this repair namespace')
    prefix = folder.relative_to(nav).as_posix() + '/'
    saved = {}
    for name in ('manifest.before.json', 'manifest.after.json', 'navmesh.before.py', 'navmesh.after.py',
                 'road_corridor.before.py', 'road_corridor.after.py', 'repair.json', '0001_37_38.mmtile'):
        path = beneath(root, folder / name)
        saved[name] = read(path)
        remember(snapshots, path, saved[name])
    receipt = json.loads(saved['repair.json'])
    if receipt.get('version') != VERSION or receipt.get('repair_id') != REPAIR_ID:
        raise ValueError('Receipt belongs to a different repair')
    if saved['0001_37_38.mmtile'] != payload['tile']:
        raise ValueError('Receipt tile differs from the frozen payload')
    for name in ('navmesh', 'road_corridor'):
        if sha(saved[name+'.before.py']) != OLD_SOURCE_HASHES[name] or saved[name+'.after.py'] != payload[name]:
            raise ValueError('Receipt planner backups do not match this exact update')
    before = json.loads(saved['manifest.before.json'].decode('utf-8-sig'))
    after = changed_manifest(before, prefix)
    if saved['manifest.after.json'] != encoded(after):
        raise ValueError('Receipt after-manifest does not reconstruct exactly this repair')
    for key in ('manifest', 'navmesh', 'road_corridor'):
        suffix = '.json' if key == 'manifest' else '.py'
        for state in ('before', 'after'):
            name = key+'.'+state+suffix
            if receipt.get('backup_hashes', {}).get(name) != sha(saved[name]):
                raise ValueError('Receipt backup hash mismatch: ' + name)
    previous = validate_manifest(root, nav, before, snapshots)
    if previous['tile_state'] != 'original':
        raise ValueError('Receipt does not reference the original source tile')
    return dict(folder=folder, prefix=prefix, record=receipt, saved=saved, before=before, after=after)


def installed_receipt(inputs, payload, snapshots):
    records = [r for r in inputs['raw'].get('repairs', []) if isinstance(r, dict) and r.get('id') == REPAIR_ID]
    if len(records) != 1:
        raise ValueError('Active candidate lacks one unambiguous rollback receipt')
    folder = asset(inputs['nav'], records[0]['provenance']).parent
    result = load_receipt(inputs, folder, payload, snapshots)
    if records[0] != repair_record(result['prefix']) or inputs['manifest_bytes'] != result['saved']['manifest.after.json']:
        raise ValueError('Active manifest contains changes outside this exact repair')
    return result


def active_paths(inputs):
    return dict(manifest=inputs['manifest'], **inputs['source_paths'])


def active_bytes(inputs):
    return dict(manifest=inputs['manifest_bytes'], **inputs['before_sources'])


def write_report(report_path, report, root):
    atomic_replace(report_path, encoded(report), root=root)


def transact(root, operations, snapshots, initial, paths, report, report_path):
    """Compare, atomically replace, and reconcile failures without hiding partial writes."""
    current_snapshots = dict(snapshots)
    attempted = []
    report['transaction'] = []
    report['changes_were_written'] = False
    try:
        for name, path, before, after in operations:
            recheck(current_snapshots, root)
            event = dict(file=name, path=str(path), before_sha256=sha(before), after_sha256=sha(after), status='attempting')
            report['transaction'].append(event)
            attempted.append((name, path, before, after, event))
            atomic_replace(path, after, expected=before, root=root)
            if read(path) != after:
                raise RuntimeError('Destination differs immediately after replacement: ' + name)
            event['status'] = 'written'
            report['changes_were_written'] = True
            report['active_changed'] = True
            current_snapshots[path] = {'bytes': len(after), 'sha256': sha(after)}
            write_report(report_path, report, root)
        recheck(current_snapshots, root)
    except Exception as original_error:
        report['transaction_error'] = type(original_error).__name__ + ': ' + str(original_error)
        report['recovery'] = []
        for name, path, before, after, event in reversed(attempted):
            item = dict(file=name, path=str(path))
            report['recovery'].append(item)
            try:
                beneath(root, path)
                current = read(path)
                if current == before:
                    item['status'] = 'already_at_starting_bytes'
                elif current == after:
                    report['changes_were_written'] = True
                    atomic_replace(path, before, expected=after, root=root)
                    if read(path) != before:
                        raise RuntimeError('Restored bytes failed verification')
                    item['status'] = 'restored_starting_bytes'
                else:
                    raise RuntimeError('Destination changed again; automatic recovery refused to overwrite it')
            except Exception as recovery_error:
                item.update(status='recovery_failed', error=type(recovery_error).__name__ + ': ' + str(recovery_error))
        state = {}
        for name, path in paths.items():
            try:
                beneath(root, path)
                current = read(path)
                state[name] = dict(sha256=sha(current), equals_starting_bytes=current == initial[name])
            except Exception as error:
                state[name] = dict(equals_starting_bytes=False, error=type(error).__name__ + ': ' + str(error))
        report['active_state_after_failure'] = state
        report['active_changed'] = not all(item['equals_starting_bytes'] for item in state.values())
        report['rollback_failed'] = any(item['status'] == 'recovery_failed' for item in report['recovery'])
        report['status'] = 'failed_partial' if report['active_changed'] else 'failed_restored'
        raise RuntimeError('Update transaction failed: ' + report['transaction_error']) from original_error


def install(root, payload, report, report_path, native_factory):
    snapshots = {}
    say('阶段 1/3：核对源码、道路数据、DLL、地图头与九个桥区瓦片 ...')
    inputs = preflight(root, payload, snapshots)
    states = set(inputs['source_states'].values()) | {inputs['tile_state']}
    receipt = None
    if states == {'candidate'}:
        receipt = installed_receipt(inputs, payload, snapshots)
        proposed = inputs['raw']
        prefix = receipt['prefix']
    elif states == {'original'}:
        prefix = 'repairs/kalimdor-bridge-0001-37-38-' + report['attempt_id'] + '/'
        proposed = changed_manifest(inputs['raw'], prefix)
    else:
        raise ValueError('Known files are only partly installed; use --rollback to restore the exact saved state first')
    report.update(manifest_before_sha256=sha(inputs['manifest_bytes']), identity_before=inputs['raw']['identity'],
                  identity_after=proposed['identity'], candidate_tile_sha256=NEW_TILE_SHA,
                  native_library_sha256=DLL_SHA, bundle_sha256=BUNDLE_SHA)
    say('阶段 2/3：使用当前 Windows DLL 验证卡利姆多桥双向及原四条回归路线 ...')
    report['status'] = 'native_validation_in_progress'
    write_report(report_path, report, root)
    verify_native(payload, inputs, proposed, snapshots, report, native_factory)
    recheck(snapshots, root)
    if receipt:
        report.update(status='already_installed_verified', repair_directory=str(receipt['folder']),
                      backup_path=str(receipt['folder'] / 'manifest.before.json'))
        return
    say('阶段 3/3：保存三份精确备份，依次更新辅助模块、规划模块和单瓦片清单 ...')
    repairs = beneath(root, inputs['nav'] / 'repairs')
    repairs.mkdir(exist_ok=True)
    folder = asset(inputs['nav'], prefix[:-1])
    folder.mkdir(exist_ok=False)
    after_bytes = encoded(proposed)
    files = {'0001_37_38.mmtile': payload['tile'],
             'manifest.before.json': inputs['manifest_bytes'], 'manifest.after.json': after_bytes,
             'navmesh.before.py': inputs['before_sources']['navmesh'], 'navmesh.after.py': payload['navmesh'],
             'road_corridor.before.py': inputs['before_sources']['road_corridor'], 'road_corridor.after.py': payload['road_corridor'],
             'RecastRasterization.change.patch': SOURCE_PATCH.encode('utf-8')}
    provenance = dict(version=VERSION, repair_id=REPAIR_ID, created_at_utc=report['started_at_utc'],
                      target=list(TARGET), original_tile=inputs['target'], candidate_tile_sha256=NEW_TILE_SHA,
                      candidate_tile_bytes=NEW_TILE_BYTES, baseline_replay_byte_exact=True,
                      raw_geometry_sha256=RAW_GEOMETRY_SHA,
                      changes=['higher-span area preservation', 'Monotone partition for this one tile',
                               'road-corridor-v2 native fallback quality guard'],
                      agent_settings=SETTINGS, client=CLIENT,
                      source_generator_modified=False, dll_modified=False, offmesh_connections_added=False,
                      query_filters=dict(include='0x11', exclude='0x0e'),
                      backup_hashes={name: sha(data) for name, data in files.items()},
                      validation_report=report['report_path'], native_queries=report['native_queries'],
                      identity_note='Polygon indices changed; old-identity blocked navigation edges no longer match.',
                      identity_definition='sha256(json.dumps(manifest.tiles, sort_keys=True).encode())[:16]')
    files['repair.json'] = encoded(provenance)
    for name, data in files.items():
        path = folder / name
        durable_new(path, data, root=root)
        remember(snapshots, path, data)
    report.update(status='ready_to_install', repair_directory=str(folder),
                  backup_path=str(folder / 'manifest.before.json'), manifest_after_sha256=sha(after_bytes))
    write_report(report_path, report, root)
    recheck(snapshots, root)
    operations = [
        ('road_corridor', inputs['source_paths']['road_corridor'], inputs['before_sources']['road_corridor'], payload['road_corridor']),
        ('navmesh', inputs['source_paths']['navmesh'], inputs['before_sources']['navmesh'], payload['navmesh']),
        ('manifest', inputs['manifest'], inputs['manifest_bytes'], after_bytes),
    ]
    transact(root, operations, snapshots, active_bytes(inputs), active_paths(inputs), report, report_path)
    report.update(status='installed_verified', active_changed=True)


def rollback(root, payload, report, report_path):
    snapshots = {}
    inputs = preflight(root, payload, snapshots)
    states = set(inputs['source_states'].values()) | {inputs['tile_state']}
    if states == {'original'}:
        recheck(snapshots, root)
        report['status'] = 'already_original'
        return
    candidates = []
    if inputs['tile_state'] == 'candidate':
        candidates.append(installed_receipt(inputs, payload, snapshots))
    else:
        directory = beneath(root, inputs['nav'] / 'repairs')
        folders = sorted(directory.glob('kalimdor-bridge-0001-37-38-*'), reverse=True)
        if len(folders) > 128:
            raise ValueError('Too many matching repair directories for bounded rollback discovery')
        for folder in folders:
            local_snapshots = {}
            try:
                candidate = load_receipt(inputs, folder, payload, local_snapshots)
                if inputs['manifest_bytes'] == candidate['saved']['manifest.before.json']:
                    candidates.append(candidate)
                    snapshots.update(local_snapshots)
                    break
            except (OSError, ValueError, KeyError, TypeError):
                continue
    if not candidates:
        raise ValueError('No exact backup matches this partial or installed state; rollback refused')
    receipt = candidates[0]
    desired = {'manifest': receipt['saved']['manifest.before.json'],
               'navmesh': receipt['saved']['navmesh.before.py'],
               'road_corridor': receipt['saved']['road_corridor.before.py']}
    after = {'manifest': receipt['saved']['manifest.after.json'],
             'navmesh': payload['navmesh'], 'road_corridor': payload['road_corridor']}
    current, paths = active_bytes(inputs), active_paths(inputs)
    if any(current[name] not in (desired[name], after[name]) for name in desired):
        raise ValueError('Current files contain unrelated changes; rollback refused')
    operations = [(name, paths[name], current[name], desired[name])
                  for name in ('manifest', 'navmesh', 'road_corridor') if current[name] != desired[name]]
    report.update(status='ready_to_rollback', repair_directory=str(receipt['folder']),
                  backup_path=str(receipt['folder'] / 'manifest.before.json'),
                  identity_before=inputs['raw']['identity'], identity_after=receipt['before']['identity'])
    write_report(report_path, report, root)
    recheck(snapshots, root)
    transact(root, operations, snapshots, current, paths, report, report_path)
    report.update(status='rolled_back', active_changed=bool(operations))


def run(root, undo=False, *, _native_factory=None):
    """Native factory injection is for isolated offline tests; no CLI bypass exists."""
    root = Path(root).resolve()
    now = datetime.now(timezone.utc)
    attempt = now.strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    report = dict(version=VERSION, attempt_id=attempt, started_at_utc=now.isoformat(),
                  project_root=str(root), operation='rollback' if undo else 'apply', status='started',
                  active_changed=False, changes_were_written=False, native_validation_passed=False)
    report_path = None
    try:
        payload = payload_bytes()
        if not root.is_dir():
            raise ValueError('Project root does not exist')
        directory = beneath(root, root / 'runtime/kalimdor-bridge-fix-reports')
        directory.mkdir(parents=True, exist_ok=True)
        report_path = directory / (attempt + '.json')
        report['report_path'] = str(report_path)
        write_report(report_path, report, root)
        say('验证报告：' + str(report_path))
        if undo:
            rollback(root, payload, report, report_path)
        else:
            install(root, payload, report, report_path, _native_factory)
    except Exception as error:
        if not report['status'].startswith('failed_'):
            report['status'] = 'failed_before_activation'
        report['error'] = type(error).__name__ + ': ' + str(error)
        say('ERROR = ' + report['error'])
    report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    if report_path:
        try:
            write_report(report_path, report, root)
        except Exception as error:
            report['report_write_error'] = type(error).__name__ + ': ' + str(error)
            say('报告写入失败：' + report['report_write_error'])
        say('REPORT = ' + str(report_path))
    if report.get('backup_path'):
        say('BACKUP = ' + report['backup_path'])
    return report


def main(argv=None):
    say('KALIMDOR BRIDGE FIX ' + VERSION + '：启动，正在准备校验。')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', '--project-root', default=DEFAULT_ROOT, type=Path)
    parser.add_argument('--rollback', action='store_true', help='Restore only this update\'s exact saved three-file state.')
    args = parser.parse_args(argv)
    if os.name != 'nt':
        parser.exit(1, 'This command targets the captured Windows installation.\n')
    report = run(args.root, args.rollback)
    if report['status'].startswith('failed_'):
        say('KALIMDOR_BRIDGE_FIX_FAILED')
        if report['active_changed']:
            say('本次留下部分变更；已拒绝覆盖发生后续变化的文件。请发送报告核对当前状态。')
        elif report['changes_were_written']:
            say('本次更新未完成，已恢复到运行前的精确文件状态。')
        else:
            say('校验未通过，本次没有激活瓦片或规划代码。')
        return 1
    if args.rollback:
        say('KALIMDOR_BRIDGE_FIX_ROLLED_BACK' if report['active_changed'] else 'KALIMDOR_BRIDGE_FIX_ALREADY_ORIGINAL')
    else:
        say('KALIMDOR_BRIDGE_FIX_INSTALLED' if report['active_changed'] else 'KALIMDOR_BRIDGE_FIX_ALREADY_INSTALLED_VERIFIED')
        say('卡利姆多桥瓦片与路线质量保护已通过当前 DLL 验证。')
    say('请重新启动 AutonomousDriving 导航程序。')
    return 0
