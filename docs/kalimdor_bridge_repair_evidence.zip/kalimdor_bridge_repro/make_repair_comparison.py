from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/kalimdor-repair-matplotlib')
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Patch
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables' / 'kalimdor_bridge_repair_comparison.png'
A = np.array([-2820.714451053201, -3396.102114364935])
B = np.array([-2834.214451053201, -3348.352114364935])
distance = np.linalg.norm(B-A)
axis = (B-A)/distance
normal = np.array([-axis[1], axis[0]])

def read(name):
    return json.loads((ROOT/name).read_text())

def transform(points):
    delta = np.asarray(points)[:, :2]-A
    return np.column_stack((delta@axis, delta@normal))

def category(item):
    if item['polygon']['flags'] == 4:
        return 'water'
    if item['reachable_from_start']:
        return 'walk'
    return 'isolated'

colors = {'water': '#80bde2', 'walk': '#43ad8a', 'isolated': '#9368ba'}
old = read('mesh_analysis/local-mesh.json')['polygons']
new = read('comparison_mesh/local-mesh.json')['polygons']
case = read('candidate_validation/selected-full/v2.json')['cases'][2]
path = np.array(case['points'])
# Use the archived map1 guide, never the optional later map0 log.
road = json.loads((ROOT.parent/'upload/last-plan.json').read_text())
reference = [road['start']]
for segment in road['guide']['segments']:
    if segment['reliability'] in ('reviewed', 'candidate'):
        reference.extend(segment['points'])
reference.append(road['goal'])
reference = transform([[p['x'], p['y']] for p in reference])

plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':10, 'text.color':'#203449'})
fig, axes = plt.subplots(3, 1, figsize=(12, 10), layout='constrained',
                         gridspec_kw={'height_ratios':[1.15, 1.15, .9]})
for index, (ax, polygons, title) in enumerate(zip(axes[:2], (old, new),
    ('Original: fragmented deck and excluded water labels',
     'Repaired: continuous walking surface across the bridge'))):
    for item in sorted(polygons, key=lambda p: {'water':0, 'walk':1, 'isolated':2}[category(p)]):
        xyz = np.array(item['polygon']['vertices_world'])
        if xyz[:,2].max()<30.8 or xyz[:,2].min()>33:
            continue
        xy = transform(xyz)
        if xy[:,0].max()<-4 or xy[:,0].min()>54 or xy[:,1].max()<-7 or xy[:,1].min()>7:
            continue
        ax.add_patch(Polygon(xy, closed=True, facecolor=colors[category(item)],
                             edgecolor='white', linewidth=.6, alpha=.90))
    ax.plot(reference[:,0], reference[:,1], '--', color='#33485b', linewidth=1.5)
    if index:
        line = transform(path)
        ax.plot(line[:,0], line[:,1], color='#d24e3f', linewidth=2.3)
    for label, t in [('A', 0), ('B', distance)]:
        ax.scatter(t, 0, s=65, c='#203449', edgecolors='white', zorder=5)
        ax.annotate(label, (t,0), xytext=(0,10), textcoords='offset points', ha='center', weight='bold')
    ax.set(xlim=(-4,54), ylim=(-7,7), ylabel='Sideways distance (yd)')
    ax.set_title(title, loc='left', weight='bold', fontsize=12, pad=9)
    ax.set_aspect('equal')
    ax.grid(alpha=.15)
    ax.set_axisbelow(True)
    if index == 0:
        ax.annotate('1.33 yd mesh gap', xy=(9,-.5), xytext=(11,5.1), ha='center',
                    color='#8b2744', arrowprops={'arrowstyle':'->','color':'#8b2744'})
        ax.text(53, -6.1, 'Full A-to-B route: 449.68 yd (XY)', ha='right', fontsize=10,
                bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':3})
    else:
        ax.text(53, -6.1, 'A-to-B: 49.62 yd (XY) | 14 expansions | no backtracking', ha='right', fontsize=10,
                bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':3})
axes[1].set_xlabel('Distance along the original A-B axis (yd)')

ax = axes[2]
raw = read('source_analysis/bridge-profile.json')['samples']
solid, water = [], []
for sample in raw:
    candidates = [s['height'] for s in sample['debug_surfaces']
                  if s['source'] != 'liquid' and s['upward'] and s['slope_passes_50']]
    liquid = [s['height'] for s in sample['debug_surfaces'] if s['source'] == 'liquid']
    solid.append(max(candidates) if candidates else np.nan)
    water.append(max(liquid) if liquid else np.nan)
x = np.array([s['t'] for s in raw])*distance
ax.plot(x, solid, color='#384953', lw=1.6, label='Original upward collision surface')
ax.plot(x, water, color='#559ed0', lw=1.5, label='Actual water below the bridge')
old_profile = read('mesh_analysis/profile.json')['samples']
first = True
for s in old_profile:
    for p in s['surfaces']:
        if p['flags']==4 and p['height']>30.8:
            ax.scatter(s['t']*distance, p['height'], color='#80bde2', s=13,
                       label='Original NAV_WATER at deck height' if first else None)
            first = False
progress = transform(path)[:,0]
ax.plot(progress, path[:,2], '-o', color='#d24e3f', lw=1.8, markersize=3,
        label='Repaired native route height')
ax.set(xlim=(0,distance), ylim=(30.0,32.7), xlabel='Distance along the original A-B axis (yd)',
       ylabel='World height (yd)')
ax.grid(alpha=.2)
ax.set_title('Height check against the original collision geometry', loc='left', weight='bold', fontsize=12)
ax.legend(loc='lower right', fontsize=8.4, ncol=2, framealpha=.95)
fig.legend(handles=[Patch(facecolor=colors['walk'],label='Connected walking surface'),
                    Patch(facecolor=colors['isolated'],label='Isolated walking surface'),
                    Patch(facecolor=colors['water'],label='Water label (excluded from walking)'),
                    Line2D([],[],ls='--',color='#33485b',label='Reviewed road reference')],
           loc='outside lower center', ncol=2, frameon=False, fontsize=9)
fig.suptitle('Kalimdor bridge repair — map 1, tile 37 / 38', fontsize=17, weight='bold')
OUT.parent.mkdir(exist_ok=True)
fig.savefig(OUT, dpi=170, bbox_inches='tight')
print(OUT)
