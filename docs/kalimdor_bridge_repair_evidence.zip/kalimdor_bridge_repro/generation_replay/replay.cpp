// Standalone diagnostic harness. The supplied pinned Recast sources are linked
// unchanged. TileBuilder stage order/configuration are parameterized by the captured map/tile coordinates.
// This program writes only into an explicitly supplied, NEW analysis directory.
#include "Recast.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
constexpr float GRID_SIZE = 533.3333f;
constexpr float CELL = 0.2666666f;
constexpr unsigned char GROUND = 11, STEEP = 10;

struct Context : rcContext {
    Context() : rcContext(true) {}
    void doLog(const rcLogCategory category, const char* msg, const int len) override {
        std::cerr << "recast[" << category << "] " << std::string(msg, len) << '\n';
    }
};

template<class T> void read(std::ifstream& f, T* dest, size_t count) {
    if (!f.read(reinterpret_cast<char*>(dest), sizeof(T) * count))
        throw std::runtime_error("Truncated geometry input");
}
template<class T> void write(std::ofstream& f, const T* src, size_t count) {
    f.write(reinterpret_cast<const char*>(src), sizeof(T) * count);
    if (!f) throw std::runtime_error("Cannot write diagnostic artifact");
}

struct Geometry {
    int nv = 0, nt = 0, lv = 0, lt = 0;
    std::vector<float> verts;
    std::vector<int> tris, solids;
    std::vector<unsigned char> liquidAreas;
    Geometry(const std::string& mesh, int liquidVerts, int liquidTris, const std::string& areas)
        : lv(liquidVerts), lt(liquidTris) {
        std::ifstream f(mesh, std::ios::binary);
        read(f, &nv, 1);
        if (nv < 1 || nv > 10000000) throw std::runtime_error("Invalid vertex count");
        verts.resize(3 * nv); read(f, verts.data(), verts.size());
        read(f, &nt, 1);
        if (nt < 1 || nt > 10000000) throw std::runtime_error("Invalid triangle count");
        tris.resize(3 * nt); read(f, tris.data(), tris.size());
        if (f.peek() != EOF || lv < 0 || lv > nv || lt < 0 || lt > nt)
            throw std::runtime_error("Invalid geometry boundary");
        for (int i = 0; i < 3 * lt; ++i)
            if (tris[i] < 0 || tris[i] >= lv) throw std::runtime_error("Liquid index crosses split");
        solids.assign(tris.begin() + 3 * lt, tris.end());
        for (int& index : solids) {
            if (index < lv || index >= nv) throw std::runtime_error("Solid index crosses split");
            index -= lv;
        }
        std::ifstream a(areas, std::ios::binary);
        liquidAreas.resize(lt); read(a, liquidAreas.data(), liquidAreas.size());
        if (a.peek() != EOF) throw std::runtime_error("Liquid area sidecar length mismatch");
    }
};

// Preserve the original global height origin and subtile float arithmetic.
rcConfig configuration(const Geometry& g, int row, int col) {
    rcConfig c{};
    rcCalcBounds(g.verts.data(), g.nv, c.bmin, c.bmax);
    c.bmax[0] = (32 - col) * GRID_SIZE;
    c.bmax[2] = (32 - row) * GRID_SIZE;
    c.bmin[0] = c.bmax[0] - GRID_SIZE;
    c.bmin[2] = c.bmax[2] - GRID_SIZE;
    c.cs = c.ch = CELL;
    c.maxVertsPerPoly = 6;
    c.walkableSlopeAngle = c.walkableSlopeAngleNotSteep = 50.f;
    c.tileSize = 80;
    c.walkableRadius = 2;
    c.borderSize = 5;
    c.maxEdgeLen = 81;
    c.walkableHeight = 6;
    c.walkableClimb = 2;
    c.minRegionArea = 144;
    c.mergeRegionArea = 400;
    c.maxSimplificationError = 1.8f;
    c.detailSampleDist = c.cs * 16;
    c.detailSampleMaxError = c.ch;
    rcCalcGridSize(c.bmin, c.bmax, c.cs, &c.width, &c.height);
    return c;
}

struct Diagnostics {
    fs::path out;
    std::map<std::string, std::ofstream> files;
    std::map<std::string, std::array<long long, 3>> counts;
    int tx = 0, ty = 0;
    std::array<float, 4> window;
    explicit Diagnostics(fs::path path, std::array<float, 4> bounds)
        : out(std::move(path)), window(bounds) {}
    bool include(int x, int z, const float* bmin, float cs) const {
        if (x < 5 || z < 5 || x >= 85 || z >= 85) return false;
        const float wx = bmin[0] + (x + .5f) * cs;
        const float wz = bmin[2] + (z + .5f) * cs;
        return wx >= window[0] && wx <= window[1] && wz >= window[2] && wz <= window[3];
    }
    std::ofstream& stream(const std::string& stage, const char* header) {
        auto found = files.find(stage);
        if (found == files.end()) {
            std::ofstream file(out / (stage + ".csv"));
            if (!file) throw std::runtime_error("Cannot open diagnostic output");
            file << header << '\n' << std::setprecision(10);
            found = files.emplace(stage, std::move(file)).first;
        }
        return found->second;
    }
    void hf(const char* name, const rcHeightfield& h) {
        auto& file = stream(name, "tx,tz,lx,lz,gx,gz,x,z,smin,smax,area,ceiling");
        auto& count = counts[name];
        for (int z = 0; z < h.height; ++z) for (int x = 0; x < h.width; ++x) {
            for (rcSpan* s = h.spans[x + z * h.width]; s; s = s->next) {
                ++count[0]; if (s->area) ++count[1]; if (s->area == GROUND) ++count[2];
                if (!include(x, z, h.bmin, h.cs)) continue;
                file << tx << ',' << ty << ',' << x << ',' << z << ','
                     << tx * 80 + x - 5 << ',' << ty * 80 + z - 5 << ','
                     << h.bmin[0] + (x + .5f) * h.cs << ',' << h.bmin[2] + (z + .5f) * h.cs << ','
                     << s->smin << ',' << s->smax << ',' << int(s->area) << ','
                     << (s->next ? int(s->next->smin) : 65535) << '\n';
            }
        }
    }
    void chf(const char* name, const rcCompactHeightfield& h) {
        auto& file = stream(name, "tx,tz,lx,lz,gx,gz,x,z,floor,height,area,region,nfloor0,nfloor1,nfloor2,nfloor3");
        auto& count = counts[name];
        for (int z = 0; z < h.height; ++z) for (int x = 0; x < h.width; ++x) {
            const rcCompactCell& c = h.cells[x + z * h.width];
            for (unsigned i = c.index; i < c.index + c.count; ++i) {
                const rcCompactSpan& s = h.spans[i];
                ++count[0]; if (h.areas[i]) ++count[1]; if (h.areas[i] == GROUND) ++count[2];
                if (!include(x, z, h.bmin, h.cs)) continue;
                file << tx << ',' << ty << ',' << x << ',' << z << ','
                     << tx * 80 + x - 5 << ',' << ty * 80 + z - 5 << ','
                     << h.bmin[0] + (x + .5f) * h.cs << ',' << h.bmin[2] + (z + .5f) * h.cs << ','
                     << s.y << ',' << s.h << ',' << int(h.areas[i]) << ',' << s.reg;
                for (int d = 0; d < 4; ++d) {
                    int floor = -1;
                    if (rcGetCon(s, d) != RC_NOT_CONNECTED) {
                        int nx = x + rcGetDirOffsetX(d), nz = z + rcGetDirOffsetY(d);
                        unsigned ni = h.cells[nx + nz * h.width].index + rcGetCon(s, d);
                        if (ni < unsigned(h.spanCount)) floor = h.spans[ni].y;
                    }
                    file << ',' << floor;
                }
                file << '\n';
            }
        }
    }
    // Observe the exact scalar conditions used by pinned rcFilterLedgeSpans.
    // This diagnostic does not modify spans; the original function still runs.
    void ledges(const rcHeightfield& h, int height, int climb) {
        auto& file = stream("ledge-reasons", "gx,gz,x,z,floor,ceiling,min_neighbor_drop,accessible_min,accessible_max,cleared_drop,cleared_range");
        for (int z = 0; z < h.height; ++z) for (int x = 0; x < h.width; ++x) {
            if (!include(x, z, h.bmin, h.cs)) continue;
            for (rcSpan* s = h.spans[x + z * h.width]; s; s = s->next) {
                if (!s->area) continue;
                const int bot = s->smax, top = s->next ? s->next->smin : 65535;
                int minh = 65535, asmin = bot, asmax = bot;
                for (int d = 0; d < 4; ++d) {
                    int nx = x + rcGetDirOffsetX(d), nz = z + rcGetDirOffsetY(d);
                    if (nx < 0 || nz < 0 || nx >= h.width || nz >= h.height) {
                        minh = std::min(minh, -climb - bot); continue;
                    }
                    rcSpan* ns = h.spans[nx + nz * h.width];
                    int nbot = -climb, ntop = ns ? ns->smin : 65535;
                    if (std::min(top, ntop) - std::max(bot, nbot) > height)
                        minh = std::min(minh, nbot - bot);
                    for (; ns; ns = ns->next) {
                        nbot = ns->smax; ntop = ns->next ? ns->next->smin : 65535;
                        if (std::min(top, ntop) - std::max(bot, nbot) > height) {
                            minh = std::min(minh, nbot - bot);
                            if (std::abs(nbot - bot) <= climb) {
                                asmin = std::min(asmin, nbot); asmax = std::max(asmax, nbot);
                            }
                        }
                    }
                }
                file << tx * 80 + x - 5 << ',' << ty * 80 + z - 5 << ','
                     << h.bmin[0] + (x + .5f) * h.cs << ',' << h.bmin[2] + (z + .5f) * h.cs << ','
                     << bot << ',' << top << ',' << minh << ',' << asmin << ',' << asmax << ','
                     << (minh < -climb) << ',' << (asmax - asmin > climb) << '\n';
            }
        }
    }
    void contours(const rcContourSet& c) {
        if (c.bmax[0] < window[0] || c.bmin[0] > window[1] ||
            c.bmax[2] < window[2] || c.bmin[2] > window[3]) return;
        auto& file = stream("10-contours", "tx,tz,contour,kind,area,region,vertex,x,y,z,flags");
        for (int i = 0; i < c.nconts; ++i) {
            const rcContour& item = c.conts[i];
            for (int raw = 0; raw < 2; ++raw) {
                const int count = raw ? item.nrverts : item.nverts;
                const int* verts = raw ? item.rverts : item.verts;
                for (int j = 0; j < count; ++j) {
                    const int* v = verts + 4*j;
                    file << tx << ',' << ty << ',' << i << ',' << (raw ? "raw" : "simple") << ','
                         << int(item.area) << ',' << item.reg << ',' << j << ','
                         << c.bmin[0] + v[0]*c.cs << ',' << c.bmin[1] + v[1]*c.ch << ','
                         << c.bmin[2] + v[2]*c.cs << ',' << v[3] << '\n';
                }
            }
        }
    }
};

void writeMesh(const fs::path& path, rcPolyMesh& m) {
    // Exact debug serialization, including TileBuilder's debug-only +border.
    for (int i = 0; i < m.nverts; ++i) { m.verts[3*i] += 5; m.verts[3*i+2] += 5; }
    for (int i = 0; i < m.npolys; ++i)
        m.flags[i] = m.areas[i] ? (m.areas[i] >= 7 ? 1 << (11 - m.areas[i]) : 1) : 0;
    std::ofstream f(path, std::ios::binary);
    write(f, &m.cs, 1); write(f, &m.ch, 1); write(f, &m.nvp, 1);
    write(f, m.bmin, 3); write(f, m.bmax, 3); write(f, &m.nverts, 1);
    write(f, m.verts, m.nverts * 3); write(f, &m.npolys, 1);
    write(f, m.polys, m.npolys * m.nvp * 2); write(f, m.flags, m.npolys);
    write(f, m.areas, m.npolys); write(f, m.regs, m.npolys);
}
void writeDetail(const fs::path& path, const rcPolyMeshDetail& m) {
    std::ofstream f(path, std::ios::binary);
    write(f, &m.nverts, 1); write(f, m.verts, m.nverts * 3);
    write(f, &m.ntris, 1); write(f, m.tris, m.ntris * 4);
    write(f, &m.nmeshes, 1); write(f, m.meshes, m.nmeshes * 4);
}

int main(int argc, char** argv) try {
    static_assert(sizeof(int) == 4 && sizeof(float) == 4 && sizeof(unsigned short) == 2);
    if (argc != 14) {
        std::cerr << "replay mesh liquid_vertices liquid_triangles liquid_areas.bin NEW_OUT map row col baseline|monotone roi_min_x roi_max_x roi_min_z roi_max_z\n";
        return 2;
    }
    Geometry g(argv[1], std::stoi(argv[2]), std::stoi(argv[3]), argv[4]);
    fs::path out(argv[5]);
    if (!fs::create_directory(out)) throw std::runtime_error("Output must be a new directory");
    const int map = std::stoi(argv[6]), row = std::stoi(argv[7]), col = std::stoi(argv[8]);
    if (map < 0 || row < 0 || row > 63 || col < 0 || col > 63)
        throw std::runtime_error("Invalid captured map/tile coordinates");
    const std::string mode = argv[9];
    if (mode != "baseline" && mode != "monotone")
        throw std::runtime_error("Unknown partition counterfactual");
    const std::array<float, 4> window = {std::stof(argv[10]), std::stof(argv[11]), std::stof(argv[12]), std::stof(argv[13])};
    if (!(window[0] < window[1] && window[2] < window[3]))
        throw std::runtime_error("Invalid diagnostic window");
    const rcConfig config = configuration(g, row, col);
    rcConfig tileCfg = config;
    tileCfg.width = tileCfg.height = config.tileSize + 2 * config.borderSize;
    Context ctx;
    Diagnostics diagnostics(out, window);
    std::vector<rcPolyMesh*> pms;
    std::vector<rcPolyMeshDetail*> dms;
    std::ofstream tileRows(out / "subtiles.csv");
    tileRows << "tx,tz,spans,regions,polygons,vertices,detail_triangles\n";
    auto start = std::chrono::steady_clock::now();
    for (int ty = 0; ty < 25; ++ty) for (int tx = 0; tx < 25; ++tx) {
        tileCfg.bmin[0] = config.bmin[0] + tx * float(config.tileSize * config.cs);
        tileCfg.bmin[2] = config.bmin[2] + ty * float(config.tileSize * config.cs);
        tileCfg.bmax[0] = config.bmin[0] + (tx + 1) * float(config.tileSize * config.cs);
        tileCfg.bmax[2] = config.bmin[2] + (ty + 1) * float(config.tileSize * config.cs);
        tileCfg.bmin[0] -= tileCfg.borderSize * tileCfg.cs;
        tileCfg.bmin[2] -= tileCfg.borderSize * tileCfg.cs;
        tileCfg.bmax[0] += tileCfg.borderSize * tileCfg.cs;
        tileCfg.bmax[2] += tileCfg.borderSize * tileCfg.cs;
        diagnostics.tx = tx; diagnostics.ty = ty;
        rcHeightfield* solid = rcAllocHeightfield();
        if (!solid || !rcCreateHeightfield(&ctx, *solid, tileCfg.width, tileCfg.height,
                                           tileCfg.bmin, tileCfg.bmax, tileCfg.cs, tileCfg.ch))
            throw std::runtime_error("CreateHeightfield failed");
        const float* tv = g.verts.data() + 3 * g.lv;
        const int tn = g.nt - g.lt, vn = g.nv - g.lv;
        std::vector<unsigned char> flags(tn, STEEP);
        rcClearUnwalkableTriangles(&ctx, tileCfg.walkableSlopeAngle, tv, vn, g.solids.data(), tn, flags.data());
        rcMarkWalkableTriangles(&ctx, tileCfg.walkableSlopeAngleNotSteep, tv, vn, g.solids.data(), tn, flags.data(), GROUND);
        if (!rcRasterizeTriangles(&ctx, tv, vn, g.solids.data(), flags.data(), tn, *solid, config.walkableClimb))
            throw std::runtime_error("Solid rasterization failed");
        diagnostics.hf("01-solid-raster", *solid);
        rcFilterLowHangingWalkableObstacles(&ctx, config.walkableClimb, *solid);
        diagnostics.hf("02-low-hanging", *solid);
        diagnostics.ledges(*solid, tileCfg.walkableHeight, tileCfg.walkableClimb);
        rcFilterLedgeSpans(&ctx, tileCfg.walkableHeight, tileCfg.walkableClimb, *solid);
        diagnostics.hf("03-ledge", *solid);
        rcFilterWalkableLowHeightSpans(&ctx, tileCfg.walkableHeight, *solid);
        diagnostics.hf("04-clearance", *solid);
        if (!rcRasterizeTriangles(&ctx, g.verts.data(), g.lv, g.tris.data(), g.liquidAreas.data(), g.lt,
                                 *solid, config.walkableClimb)) throw std::runtime_error("Liquid rasterization failed");
        diagnostics.hf("05-liquid-raster", *solid);
        rcCompactHeightfield* compact = rcAllocCompactHeightfield();
        if (!compact || !rcBuildCompactHeightfield(&ctx, tileCfg.walkableHeight, tileCfg.walkableClimb, *solid, *compact))
            throw std::runtime_error("Compact heightfield failed");
        diagnostics.chf("06-compact", *compact);
        if (!rcErodeWalkableArea(&ctx, config.walkableRadius, *compact))
            throw std::runtime_error("Erosion failed");
        diagnostics.chf("07-erosion", *compact);
        if (!rcMedianFilterWalkableArea(&ctx, *compact)) throw std::runtime_error("Median filter failed");
        diagnostics.chf("08-median", *compact);
        bool regionOk = mode == "monotone"
            ? rcBuildRegionsMonotone(&ctx, *compact, tileCfg.borderSize, tileCfg.minRegionArea, tileCfg.mergeRegionArea)
            : rcBuildLayerRegions(&ctx, *compact, tileCfg.borderSize, tileCfg.minRegionArea);
        if (!regionOk && mode == "monotone")
            regionOk = rcBuildLayerRegions(&ctx, *compact, tileCfg.borderSize, tileCfg.minRegionArea);
        if (!regionOk)
            throw std::runtime_error("Layer regions failed");
        diagnostics.chf("09-regions", *compact);
        rcContourSet* contours = rcAllocContourSet();
        if (!contours || !rcBuildContours(&ctx, *compact, tileCfg.maxSimplificationError, tileCfg.maxEdgeLen, *contours))
            throw std::runtime_error("Contours failed");
        diagnostics.contours(*contours);
        rcPolyMesh* pm = rcAllocPolyMesh();
        if (!pm || !rcBuildPolyMesh(&ctx, *contours, tileCfg.maxVertsPerPoly, *pm))
            throw std::runtime_error("Polymesh failed");
        rcPolyMeshDetail* dm = rcAllocPolyMeshDetail();
        if (!dm || !rcBuildPolyMeshDetail(&ctx, *pm, *compact, tileCfg.detailSampleDist, tileCfg.detailSampleMaxError, *dm))
            throw std::runtime_error("Detail mesh failed");
        tileRows << tx << ',' << ty << ',' << compact->spanCount << ',' << compact->maxRegions << ','
                 << pm->npolys << ',' << pm->nverts << ',' << dm->ntris << '\n';
        pms.push_back(pm); dms.push_back(dm);
        rcFreeHeightField(solid); rcFreeCompactHeightfield(compact); rcFreeContourSet(contours);
    }
    rcPolyMesh* pm = rcAllocPolyMesh();
    rcPolyMeshDetail* dm = rcAllocPolyMeshDetail();
    if (!pm || !dm || !rcMergePolyMeshes(&ctx, pms.data(), int(pms.size()), *pm)
        || !rcMergePolyMeshDetails(&ctx, dms.data(), int(dms.size()), *dm))
        throw std::runtime_error("Merge failed");
    writeMesh(out / "replayed.pmesh", *pm);
    writeDetail(out / "replayed.dmesh", *dm);
    double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
    std::ofstream result(out / "summary.json");
    result << std::setprecision(12) << "{\n\"mode\":\"" << mode << "\",\"subtiles\":" << pms.size()
           << ",\"map_id\":" << map << ",\"tile_row\":" << row << ",\"tile_col\":" << col
           << ",\"elapsed_seconds\":" << elapsed << ",\"vertices\":" << pm->nverts << ",\"polygons\":" << pm->npolys
           << ",\"bmin\":[" << config.bmin[0] << ',' << config.bmin[1] << ',' << config.bmin[2]
           << "],\"bmax\":[" << config.bmax[0] << ',' << config.bmax[1] << ',' << config.bmax[2]
           << "],\"cell\":" << config.cs << ",\"height\":6,\"climb\":2,\"radius\":2,\"border\":5,"
           << "\"count_scope\":\"sum of processed subtiles including borders\",\"stage_counts\":{";
    bool first = true;
    for (const auto& [name, c] : diagnostics.counts) {
        if (!first) result << ',';
        first = false;
        result << '\n' << '"' << name << "\":{\"spans\":" << c[0] << ",\"walkable\":" << c[1] << ",\"ground\":" << c[2] << '}';
    }
    result << "\n}}\n";
    std::cout << "subtiles=" << pms.size() << " polygons=" << pm->npolys << " vertices=" << pm->nverts << " elapsed=" << elapsed << '\n';
    rcFreePolyMesh(pm); rcFreePolyMeshDetail(dm);
    for (auto* m : pms) rcFreePolyMesh(m);
    for (auto* m : dms) rcFreePolyMeshDetail(m);
    return 0;
} catch (const std::exception& e) {
    std::cerr << "replay failed: " << e.what() << '\n';
    return 1;
}
