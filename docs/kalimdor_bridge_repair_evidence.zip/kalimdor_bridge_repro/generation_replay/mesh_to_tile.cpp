// Standalone diagnostic conversion using the captured, unmodified Detour.
// Consumes one calibrated map/tile replay profile and writes one NEW .mmtile only.
// No production mesh, DLL, manifest, or source file is modified.
#include "DetourNavMesh.h"
#include "DetourNavMeshBuilder.h"
#include "DetourAlloc.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <regex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
constexpr uint32_t MMAP_MAGIC = 0x4d4d4150;
constexpr uint32_t MMAP_VERSION = 16;
constexpr float BASE_UNIT_DIM = 0.2666666f;
constexpr float GRID_SIZE = 533.3333f;

struct Reader {
    std::vector<unsigned char> data;
    size_t position = 0;
    explicit Reader(const fs::path& path) {
        const auto size = fs::file_size(path);
        if (!size || size > 32 * 1024 * 1024)
            throw std::runtime_error("Input file outside diagnostic size limit");
        std::ifstream f(path, std::ios::binary);
        data.resize(size);
        if (!f.read(reinterpret_cast<char*>(data.data()), size))
            throw std::runtime_error("Cannot read input file");
    }
    template<class T> T one() {
        T value;
        if (position + sizeof(T) > data.size()) throw std::runtime_error("Truncated input");
        std::memcpy(&value, data.data() + position, sizeof(T));
        position += sizeof(T);
        return value;
    }
    template<class T> std::vector<T> many(size_t count) {
        if (count > data.size() / sizeof(T) || position + count * sizeof(T) > data.size())
            throw std::runtime_error("Invalid input array count");
        std::vector<T> values(count);
        std::memcpy(values.data(), data.data() + position, count * sizeof(T));
        position += count * sizeof(T);
        return values;
    }
    void end() const {
        if (position != data.size()) throw std::runtime_error("Unexpected trailing input bytes");
    }
};

int count(Reader& reader, int maximum, const char* label) {
    const int value = reader.one<int>();
    if (value < 1 || value > maximum)
        throw std::runtime_error(std::string("Invalid ") + label);
    return value;
}

// Only scalar/array fields emitted by our replay summary are accepted. They
// are mandatory: a candidate never silently inherits the old tile's profile.
std::string field(const std::string& json, const std::string& name, bool array) {
    const std::string number = R"([-+]?[0-9]+(?:\.[0-9]+)?(?:[eE][-+]?[0-9]+)?)";
    const std::regex pattern("\\\"" + name + "\\\"\\s*:\\s*(" +
                             (array ? std::string(R"(\[[^\]]*\])") : number) + ")");
    std::sregex_iterator begin(json.begin(), json.end(), pattern), end;
    if (begin == end) throw std::runtime_error("Missing summary field: " + name);
    const std::string value = (*begin)[1];
    if (++begin != end) throw std::runtime_error("Duplicate summary field: " + name);
    return value;
}

int integer(const std::string& json, const std::string& name, int minimum, int maximum) {
    const double value = std::stod(field(json, name, false));
    if (!std::isfinite(value) || value != std::floor(value) || value < minimum || value > maximum)
        throw std::runtime_error("Invalid summary integer: " + name);
    return static_cast<int>(value);
}

std::array<float, 3> bounds(const std::string& json, const std::string& name) {
    std::string text = field(json, name, true);
    text = text.substr(1, text.size() - 2);
    std::replace(text.begin(), text.end(), ',', ' ');
    std::istringstream in(text);
    std::array<float, 3> result;
    for (float& value : result)
        if (!(in >> value) || !std::isfinite(value))
            throw std::runtime_error("Invalid summary bounds: " + name);
    in >> std::ws;
    if (!in.eof()) throw std::runtime_error("Too many summary bounds entries");
    return result;
}

struct TileHeader {
    uint32_t mmapMagic = MMAP_MAGIC;
    uint32_t dtVersion = DT_NAVMESH_VERSION;
    uint32_t mmapVersion = MMAP_VERSION;
    uint32_t size = 0;
    uint8_t usesLiquids = 1;
    uint8_t padding[3] = {};
};

int main(int argc, char** argv) try {
    static_assert(sizeof(float) == 4 && sizeof(int) == 4 && sizeof(unsigned short) == 2);
    static_assert(sizeof(dtPolyRef) == 8 && sizeof(dtNavMeshParams) == 28);
    static_assert(sizeof(TileHeader) == 20);
    const uint32_t endian = 1;
    if (*reinterpret_cast<const unsigned char*>(&endian) != 1)
        throw std::runtime_error("Captured inputs require a little-endian host");
    if (argc != 6) {
        std::cerr << "mesh_to_tile POLY.pmesh DETAIL.dmesh ORIGINAL.mmap SUMMARY.json NEW_OUT.mmtile\n"
                     "SUMMARY must describe this replay's bmin/bmax, cell, height, radius, climb, border.\n"
                     "This case has liquids enabled, layer 0, and no off-mesh connections.\n";
        return 2;
    }
    if (fs::exists(argv[5])) throw std::runtime_error("Output already exists");
    Reader summaryReader(argv[4]);
    const std::string summary(summaryReader.data.begin(), summaryReader.data.end());
    const auto bmin = bounds(summary, "bmin"), bmax = bounds(summary, "bmax");
    const int height = integer(summary, "height", 1, 255);
    const int radius = integer(summary, "radius", 0, 255);
    const int climb = integer(summary, "climb", 0, height - 1);
    const int border = integer(summary, "border", 0, 255);
    const float cell = std::stof(field(summary, "cell", false));
    if (cell != BASE_UNIT_DIM)
        throw std::runtime_error("Unsupported cell: this converter follows captured BASE_UNIT_DIM");
    for (int axis = 0; axis < 3; ++axis)
        if (bmin[axis] >= bmax[axis]) throw std::runtime_error("Invalid summary bounds order");

    Reader p(argv[1]);
    const float cs = p.one<float>(), ch = p.one<float>();
    const int nvp = count(p, DT_VERTS_PER_POLYGON, "vertices per polygon");
    const auto pmin = p.many<float>(3), pmax = p.many<float>(3);
    const int nv = count(p, 65534, "polygon vertex count");
    auto verts = p.many<unsigned short>(size_t(nv) * 3);
    const int np = count(p, 1000000, "polygon count");
    auto polys = p.many<unsigned short>(size_t(np) * nvp * 2);
    const auto flags = p.many<unsigned short>(np);
    const auto areas = p.many<unsigned char>(np);
    const auto regions = p.many<unsigned short>(np);
    p.end();
    if (cs != cell || ch != cell || nvp < 3)
        throw std::runtime_error("Polygon mesh and summary cell/profile mismatch");
    for (int axis = 0; axis < 3; ++axis)
        if (pmin[axis] != bmin[axis]) throw std::runtime_error("Polygon mesh and summary origin mismatch");
    for (int i = 0; i < nv; ++i) {
        if (verts[3*i] < border || verts[3*i+2] < border)
            throw std::runtime_error("Debug vertex smaller than reported padding");
        verts[3*i] -= border;
        verts[3*i+2] -= border;
    }

    Reader d(argv[2]);
    const int dnv = count(d, 10000000, "detail vertex count");
    const auto detailVerts = d.many<float>(size_t(dnv) * 3);
    const int dnt = count(d, 10000000, "detail triangle count");
    const auto detailTris = d.many<unsigned char>(size_t(dnt) * 4);
    const int dnm = count(d, 1000000, "detail mesh count");
    const auto detailMeshes = d.many<unsigned int>(size_t(dnm) * 4);
    d.end();
    if (dnm != np) throw std::runtime_error("Detail/polygon count mismatch");

    Reader m(argv[3]);
    if (m.one<uint32_t>() != MMAP_MAGIC || m.one<uint32_t>() != MMAP_VERSION)
        throw std::runtime_error("Unsupported mmap header");
    const dtNavMeshParams map = m.one<dtNavMeshParams>();
    if (m.one<uint32_t>() != 0) throw std::runtime_error("Off-mesh inputs are not supported by this case converter");
    m.end();
    if (map.tileWidth != GRID_SIZE || map.tileHeight != GRID_SIZE)
        throw std::runtime_error("Unexpected source map tile size");

    dtNavMeshCreateParams params{};
    params.verts = verts.data(); params.vertCount = nv;
    params.polys = polys.data(); params.polyFlags = flags.data();
    params.polyAreas = areas.data(); params.polyCount = np; params.nvp = nvp;
    params.detailMeshes = detailMeshes.data();
    params.detailVerts = detailVerts.data(); params.detailVertsCount = dnv;
    params.detailTris = detailTris.data(); params.detailTriCount = dnt;
    params.walkableHeight = BASE_UNIT_DIM * height;
    params.walkableRadius = BASE_UNIT_DIM * radius;
    params.walkableClimb = BASE_UNIT_DIM * climb;
    params.tileX = (((bmin[0] + bmax[0]) / 2) - map.orig[0]) / GRID_SIZE;
    params.tileY = (((bmin[2] + bmax[2]) / 2) - map.orig[2]) / GRID_SIZE;
    std::copy(bmin.begin(), bmin.end(), params.bmin);
    std::copy(bmax.begin(), bmax.end(), params.bmax);
    params.cs = cs; params.ch = ch; params.tileLayer = 0; params.buildBvTree = true;
    const int row = integer(summary, "tile_row", 0, 63);
    const int col = integer(summary, "tile_col", 0, 63);
    const float expectedMaxX = (32 - col) * GRID_SIZE;
    const float expectedMaxZ = (32 - row) * GRID_SIZE;
    if (bmax[0] != expectedMaxX || bmax[2] != expectedMaxZ ||
        bmin[0] != expectedMaxX - GRID_SIZE || bmin[2] != expectedMaxZ - GRID_SIZE)
        throw std::runtime_error("Replay bounds do not match captured tile coordinates");

    unsigned char* data = nullptr;
    int size = 0;
    if (!dtCreateNavMeshData(&params, &data, &size)) throw std::runtime_error("dtCreateNavMeshData failed");
    struct FreeData { unsigned char* ptr; ~FreeData() { dtFree(ptr); } } freeData{data};
    // The actual saveMoveMapTileToFile inserts the tile before writing it.
    // Insertion populates internal link data and must be reproduced for hashes.
    dtNavMesh mesh;
    if (dtStatusFailed(mesh.init(&map))) throw std::runtime_error("dtNavMesh init failed");
    dtTileRef ref = 0;
    if (dtStatusFailed(mesh.addTile(data, size, 0, 0, &ref)) || !ref)
        throw std::runtime_error("dtNavMesh addTile failed");

    TileHeader header;
    header.size = size;
    FILE* out = std::fopen(argv[5], "wbx");
    if (!out) throw std::runtime_error("Cannot create NEW output file");
    const bool written = std::fwrite(&header, sizeof(header), 1, out) == 1
                         && std::fwrite(data, 1, size, out) == size;
    const int closed = std::fclose(out);
    if (!written || closed != 0) {
        fs::remove(argv[5]);
        throw std::runtime_error("Writing diagnostic tile failed");
    }
    std::cout << std::setprecision(12)
              << "{\"bytes\":" << size + sizeof(header) << ",\"tileX\":" << params.tileX
              << ",\"tileY\":" << params.tileY << ",\"polygons\":" << np << ",\"vertices\":" << nv
              << ",\"height\":" << params.walkableHeight << ",\"radius\":" << params.walkableRadius
              << ",\"climb\":" << params.walkableClimb << ",\"removed_debug_border\":" << border
              << ",\"internal_links_initialized\":true,\"offmesh_count\":0}\n";
    return 0;
} catch (const std::exception& error) {
    std::cerr << "mesh_to_tile failed: " << error.what() << '\n';
    return 1;
}
