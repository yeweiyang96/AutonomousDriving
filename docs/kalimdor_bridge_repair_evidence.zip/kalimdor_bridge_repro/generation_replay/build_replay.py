"""Compile only bounded analysis harnesses against captured pinned sources."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'generation_repro/case_4066c49b/wsl/source-recorded-revision/dep/recastnavigation'


def build(name, harness, directory, variant=None):
    sources = sorted((SOURCE / directory / 'Source').glob('*.cpp'))
    if variant:
        sources = [OUT / 'patches' / variant / p.name if p.name == 'RecastRasterization.cpp' else p for p in sources]
    command = ['g++', '-std=c++17', '-O3', '-DNDEBUG', '-I', str(SOURCE / directory / 'Include'),
               str(OUT / harness), *map(str, sources), '-o', str(OUT / name)]
    result = subprocess.run(command, capture_output=True, text=True)
    record = {'name': name, 'command': command, 'returncode': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr,
              'source_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in [OUT / harness, *sources]}}
    if result.returncode:
        raise RuntimeError(json.dumps(record))
    record['binary_sha256'] = hashlib.sha256((OUT / name).read_bytes()).hexdigest()
    print(name + ' compiled', flush=True)
    return record


if __name__ == '__main__':
    tasks = [('replay_original', 'replay.cpp', 'Recast', None),
             ('replay_higher_span', 'replay.cpp', 'Recast', 'higher-span-area'),
             ('mesh_to_tile', 'mesh_to_tile.cpp', 'Detour', None)]
    with ThreadPoolExecutor(max_workers=3) as pool:
        records = list(pool.map(lambda args: build(*args), tasks))
    (OUT / 'build-provenance.json').write_text(json.dumps(records, indent=2) + '\n')
