"""Recover the captured liquid prefix without altering captured inputs.

Uses the fixed TerrainBuilder order and per-half ADT selection. The binary
debug mesh remains the authoritative float32 geometry and triangle ordering.
Referenced VMO files are structurally parsed and checked for nonempty liquid.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys

import numpy as np

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parents[2]
CAPTURE = BASE / 'kalimdor_bridge_repro/case_7860200b'
MAP, ROW, COL = 1, 37, 38
OUT = Path(__file__).resolve().parent
DECODER = BASE / 'generation_repro/analysis/raw_terrain/read_profile.py'
spec = importlib.util.spec_from_file_location('raw_terrain_decoder', DECODER)
terrain = importlib.util.module_from_spec(spec)
spec.loader.exec_module(terrain)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def clean(vertices, triangles):
    mapping, result, indices = {}, [], []
    for tri in triangles:
        converted = []
        for old in tri:
            if old not in mapping:
                mapping[old] = len(result)
                result.append(vertices[old])
            converted.append(mapping[old])
        indices.append(converted)
    return (np.asarray(result, dtype='<f4').reshape(-1, 3),
            np.asarray(indices, dtype='<i4').reshape(-1, 3))


def selected_squares(portion):
    return {
        'ENTIRE': range(16384),
        'LEFT': range(0, 16257, 128),
        'RIGHT': range(127, 16384, 128),
        'TOP': range(128),
        'BOTTOM': range(16256, 16384),
    }[portion]


def reconstruct():
    liquid_vertices, liquid_triangles, areas = [], [], []
    solid_vertices, solid_triangles, records = [], [], []
    load_order = [(ROW, COL, 'ENTIRE'), (ROW, COL+1, 'LEFT'),
                  (ROW, COL-1, 'RIGHT'), (ROW+1, COL, 'TOP'), (ROW-1, COL, 'BOTTOM')]
    for row, col, portion in load_order:
        path = CAPTURE / 'inputs/maps' / f'{MAP:04}_{row:02}_{col:02}.map'
        decoded = terrain.decode(path)
        # decode() exposes the original heights before its ENTIRE pass. Reset
        # them here and run only the original requested neighboring strip.
        solid = [[p[1], p[2], p[0]] for p in decoded['vertices']]
        liquid = [[p[1], h, p[0]] for p, h in zip(
            decoded['liquid_vertices'], decoded['original_liquid_heights'])]
        original_heights = decoded['original_liquid_heights']
        solid_offset, liquid_offset = len(solid_vertices), len(liquid_vertices)
        local_solid, local_liquid, local_areas = [], [], []
        for square in selected_squares(portion):
            ts, ls = terrain.triangles(square)
            state = decoded['half_states'][square][0]
            typ, hole = state['liquid_flags'], state['hole']
            for half in (0, 1):
                use_solid = True
                use_liquid = decoded['liquid_header'] is not None
                area = 0
                if use_liquid:
                    if typ & 16:
                        use_solid = use_liquid = False
                    elif typ & 3:
                        area = 9
                    elif typ & 12:
                        area = 8
                    else:
                        use_liquid = False
                lt = ls[half]
                st = ts[2*half:2*half+2]
                if use_liquid:
                    valid = [original_heights[i] for i in lt
                             if original_heights[i] != terrain.INVALID
                             and original_heights[i] < terrain.INVALID_MAX]
                    if 0 < len(valid) < 3:
                        total = 0.0
                        for height in valid:
                            total = terrain.f32(total + height)
                        average = terrain.f32(total / len(valid))
                        for index in lt:
                            if liquid[index][1] == terrain.INVALID or liquid[index][1] > terrain.INVALID_MAX:
                                liquid[index][1] = average
                    if not valid:
                        use_liquid = False
                if use_solid and hole:
                    use_solid = False
                if use_solid and use_liquid:
                    lh = [liquid[i][1] for i in lt]
                    th = [solid[i][1] for tri in st for i in tri]
                    if min(lh) > max(th):
                        use_solid = False
                    if min(th) > max(lh):
                        use_liquid = False
                if use_liquid:
                    local_liquid.append([i + liquid_offset for i in lt])
                    local_areas.append(area)
                if use_solid:
                    local_solid.extend([[i + solid_offset for i in tri] for tri in st])
        solid_vertices.extend(solid)
        solid_triangles.extend(local_solid)
        if decoded['liquid_header'] is not None:
            liquid_vertices.extend(liquid)
        liquid_triangles.extend(local_liquid)
        areas.extend(local_areas)
        records.append(dict(path=str(path), sha256=decoded['sha256'], portion=portion,
                            solid_triangles=len(local_solid), liquid_triangles=len(local_liquid),
                            liquid_areas={str(a): local_areas.count(a) for a in sorted(set(local_areas))}))
    lv, lt = clean(liquid_vertices, liquid_triangles)
    sv, st = clean(solid_vertices, solid_triangles)
    return lv, lt, bytes(areas), sv, st, records


def main():
    global CAPTURE, OUT, MAP, ROW, COL
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', type=Path, default=CAPTURE)
    parser.add_argument('--output', type=Path, default=OUT)
    parser.add_argument('--map', type=int, default=MAP)
    parser.add_argument('--row', type=int, default=ROW)
    parser.add_argument('--col', type=int, default=COL)
    args = parser.parse_args()
    CAPTURE, OUT, MAP, ROW, COL = args.capture.resolve(), args.output.resolve(), args.map, args.row, args.col
    OUT.mkdir(parents=True, exist_ok=True)
    source = CAPTURE / f'meshes/map{MAP:04}_{ROW:02}_{COL:02}.mesh'
    data = source.read_bytes()
    vertex_count, = struct.unpack_from('<i', data)
    triangle_offset = 4 + vertex_count * 12
    triangle_count, = struct.unpack_from('<i', data, triangle_offset)
    assert len(data) == triangle_offset + 4 + triangle_count * 12
    vertices = np.frombuffer(data, dtype='<f4', count=vertex_count*3, offset=4).reshape(-1, 3)
    triangles = np.frombuffer(data, dtype='<i4', count=triangle_count*3,
                              offset=triangle_offset+4).reshape(-1, 3)
    lv, lt, areas, sv, st, records = reconstruct()
    checks = {
        'liquid_vertices_exact_bytes': lv.tobytes() == vertices[:len(lv)].tobytes(),
        'liquid_triangles_exact_bytes': lt.tobytes() == triangles[:len(lt)].tobytes(),
        'solid_adt_vertices_exact_bytes': sv.tobytes() == vertices[len(lv):len(lv)+len(sv)].tobytes(),
        'solid_adt_triangles_exact_bytes': (st + len(lv)).astype('<i4').tobytes() == triangles[len(lt):len(lt)+len(st)].tobytes(),
        'liquid_indices_within_liquid_vertices': bool(np.all(triangles[:len(lt)] < len(lv))),
        'solid_indices_outside_liquid_vertices': bool(np.all(triangles[len(lt):] >= len(lv))),
    }
    if not all(checks.values()):
        print(json.dumps({'checks': checks, 'liquid_vertices': len(lv), 'liquid_triangles': len(lt),
                          'solid_adt_vertices': len(sv), 'solid_adt_triangles': len(st)}, indent=2))
        if not checks['liquid_vertices_exact_bytes']:
            different = np.argwhere(lv != vertices[:len(lv)])
            print('first liquid differences', different[:10].tolist())
        raise RuntimeError('Reconstructed ADT prefix is not byte-identical to captured geometry')
    # Independently walk every referenced VMO's complete chunk structure. No
    # liquid prefix claim is permitted if the terrain-only recovery omits VMAP liquid.
    decoder = BASE / 'generation_repro/analysis/identify_bridge_vmap.py'
    spec = importlib.util.spec_from_file_location('vmo_structure_decoder', decoder)
    vmo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(vmo)
    spawns = json.loads((CAPTURE / 'inputs/target-model-spawns.json').read_text())
    names = sorted({spawn['name'] + '.vmo' for spawn in spawns})
    models = []
    for name in names:
        model = vmo.parse(CAPTURE / 'inputs/vmaps' / name)
        models.append({'name': name, 'sha256': model['sha256'],
                       'bytes': model['bytes'], 'groups': len(model['groups']),
                       'nonempty_liquid_chunks': [g['ordinal'] for g in model['groups'] if g['liquid_chunk_bytes']]})
    wmo = {'unique_models_referenced': len(names), 'models': models,
           'models_with_liquid': sum(bool(m['nonempty_liquid_chunks']) for m in models)}
    (OUT / 'wmo-liquid.json').write_text(json.dumps(wmo, indent=2) + '\n')
    if wmo['models_with_liquid']:
        raise RuntimeError('This tile has VMAP liquid; terrain-only split recovery must not proceed')
    checks['all_captured_vmo_liquid_chunks_empty'] = True
    tile = (CAPTURE / f'mmaps/{MAP:04}_{ROW:02}_{COL:02}.mmtile').read_bytes()
    bmin = list(struct.unpack_from('<3f', tile, 92))
    bmax = list(struct.unpack_from('<3f', tile, 104))
    area_file = OUT / 'liquid_areas.bin'
    area_file.write_bytes(areas)
    report = {
        'schema': 1, 'target': [MAP, ROW, COL], 'mesh_path': str(source), 'mesh_sha256': digest(data), 'mesh_bytes': len(data),
        'coordinates': 'Detour [world_west, world_height, world_north]',
        'vertex_count': vertex_count, 'triangle_count': triangle_count,
        'liquid_vertex_count': len(lv), 'liquid_triangle_count': len(lt),
        'solid_vertex_count': vertex_count-len(lv), 'solid_triangle_count': triangle_count-len(lt),
        'solid_adt_vertex_count': len(sv), 'solid_adt_triangle_count': len(st),
        'solid_vmap_vertex_count': vertex_count-len(lv)-len(sv),
        'solid_vmap_triangle_count': triangle_count-len(lt)-len(st),
        'liquid_areas_file': str(area_file), 'liquid_areas_bytes': len(areas),
        'liquid_areas_sha256': digest(areas),
        'liquid_area_histogram': {str(a): areas.count(a) for a in sorted(set(areas))},
        'geometry_bounds_min': vertices.min(axis=0).tolist(),
        'geometry_bounds_max': vertices.max(axis=0).tolist(),
        'tile_bounds_min': bmin, 'tile_bounds_max': bmax,
        'checks': checks, 'adt_load_order': records,
        'wmo_liquid_evidence_file': str(OUT / 'wmo-liquid.json'),
        'wmo_liquid_evidence_sha256': digest((OUT / 'wmo-liquid.json').read_bytes()),
        'notes': [
            'Use original .mesh float32 vertices and int32 indices; do not reconstruct or reorder solid VMAP geometry.',
            'Liquid stream is first; solid indices must be reduced by liquid_vertex_count when split.',
            'ADT retention and cleaning reproduce every liquid vertex/triangle and ADT solid prefix byte-for-byte.',
            f'All {len(models)} referenced VMO models have zero nonempty LIQU chunks; no unrecorded VMAP liquid area remains.',
            'All remaining solid triangles receive slope classification in the fixed Recast pipeline; do not prelabel them all walkable.',
        ],
    }
    (OUT / 'geometry.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['vertex_count', 'triangle_count', 'liquid_vertex_count',
                      'liquid_triangle_count', 'solid_vertex_count', 'solid_triangle_count',
                      'liquid_area_histogram', 'checks']}, indent=2))


if __name__ == '__main__':
    main()
