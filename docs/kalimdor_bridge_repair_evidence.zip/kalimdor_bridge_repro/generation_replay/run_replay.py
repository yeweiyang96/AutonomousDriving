"""Replay one isolated Kalimdor tile variant; retain inputs, commands and hashes."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CASE = ROOT / 'kalimdor_bridge_repro/case_7860200b'


def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rasterizer', choices=['original', 'higher-span-area'], required=True)
    parser.add_argument('--partition', choices=['baseline', 'monotone'], required=True)
    parser.add_argument('--name', required=True)
    args = parser.parse_args()
    if Path(args.name).name != args.name or args.name in ('.', '..'):
        raise ValueError('Expected one new output directory name')
    out = HERE / args.name
    if out.exists():
        raise ValueError('Refusing existing output directory')
    geometry = json.loads((HERE / 'geometry.json').read_text())
    executable = HERE / ('replay_original' if args.rasterizer == 'original' else 'replay_higher_span')
    command = [str(executable), geometry['mesh_path'], str(geometry['liquid_vertex_count']),
               str(geometry['liquid_triangle_count']), str(HERE / 'liquid_areas.bin'), str(out),
               '1', '37', '38', args.partition, '-3410', '-3335', '-2843', '-2810']
    print('Replaying ' + args.name, flush=True)
    result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    record = {'rasterization_variant': args.rasterizer, 'partition': args.partition,
              'replay_command': command, 'replay_exit_code': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr,
              'inputs': [info(Path(geometry['mesh_path'])), info(HERE / 'liquid_areas.bin'),
                         info(CASE / 'mmaps/0001.mmap')], 'binary': info(executable)}
    if result.returncode:
        (out / 'run-result.json').write_text(json.dumps(record, indent=2) + '\n')
        raise RuntimeError(result.stderr)
    conversion = [str(HERE / 'mesh_to_tile'), str(out / 'replayed.pmesh'),
                  str(out / 'replayed.dmesh'), str(CASE / 'mmaps/0001.mmap'),
                  str(out / 'summary.json'), str(out / 'reconverted.mmtile')]
    result = subprocess.run(conversion, capture_output=True, text=True, timeout=30)
    record.update(conversion_command=conversion, conversion_exit_code=result.returncode,
                  conversion_stdout=result.stdout, conversion_stderr=result.stderr)
    if result.returncode:
        (out / 'run-result.json').write_text(json.dumps(record, indent=2) + '\n')
        raise RuntimeError(result.stderr)
    products = [('replayed.pmesh', 'meshes/0001_37_38.pmesh'),
                ('replayed.dmesh', 'meshes/0001_37_38.dmesh'),
                ('reconverted.mmtile', 'mmaps/0001_37_38.mmtile')]
    record['products'] = {name: {**info(out / name), 'matches_original_bytes':
                                (out / name).read_bytes() == (CASE / original).read_bytes()}
                          for name, original in products}
    (out / 'run-result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record['products'], indent=2), flush=True)
    if args.rasterizer == 'original' and args.partition == 'baseline':
        if not all(product['matches_original_bytes'] for product in record['products'].values()):
            raise RuntimeError('Original replay failed byte-exact baseline calibration')


if __name__ == '__main__':
    main()
