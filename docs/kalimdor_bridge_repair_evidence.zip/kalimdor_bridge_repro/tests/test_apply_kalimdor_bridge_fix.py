"""Required transaction checks plus real native probes on captured fixture data.

The full fixture intentionally lacks three map0 collar tiles. The full eight
case probe must therefore refuse activation. Transaction tests replace only the
verification function with an explicit stub; they do not claim Windows-native
certification. Four map1 gates execute the real captured-source Linux library.
"""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


installer = load('kalimdor_installer', ROOT / 'kalimdor_bridge_repro/deliverables/apply_kalimdor_bridge_fix.py')
fixture = load('kalimdor_fixture', ROOT / 'kalimdor_bridge_repro/candidate_validation/installer_fixture.py')


def validated_stub(payload, inputs, proposed, snapshots, report, native_factory=None):
    report['native_queries'] = [{'test_only': 'transaction fixture; native gate is separately tested'}]
    report['native_validation_passed'] = True


class InstallerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base_temp = tempfile.TemporaryDirectory()
        cls.base = Path(cls.base_temp.name) / 'project'
        cls.inventory = fixture.build_fixture(cls.base)
        cls.payload = installer.payload_bytes()

    @classmethod
    def tearDownClass(cls):
        cls.base_temp.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'project'
        shutil.copytree(self.base, self.root)
        self.paths = {
            'manifest': self.root / 'data/navigation/manifest.json',
            'navmesh': self.root / 'adrive/navmesh.py',
            'road_corridor': self.root / 'adrive/road_corridor.py',
        }
        self.original = self.state()

    def state(self):
        return {name: path.read_bytes() for name, path in self.paths.items()}

    def run_update(self, undo=False, real=False):
        with redirect_stdout(io.StringIO()):
            if real:
                return installer.run(self.root, undo, _native_factory=fixture.native_factory)
            with mock.patch.object(installer, 'verify_native', side_effect=validated_stub):
                return installer.run(self.root, undo)

    def installed(self):
        result = self.run_update()
        self.assertEqual(result['status'], 'installed_verified', result.get('error'))
        self.assertTrue(result['active_changed'])
        return result

    def test_real_native_four_bridge_gates(self):
        snapshots = {}
        inputs = installer.preflight(self.root, self.payload, snapshots)
        proposed = installer.changed_manifest(inputs['raw'], 'repairs/kalimdor-bridge-0001-37-38-test-native/')
        report = {}
        with mock.patch.object(installer, 'VALIDATION_CASES', installer.VALIDATION_CASES[:4]), redirect_stdout(io.StringIO()):
            installer.verify_native(self.payload, inputs, proposed, snapshots, report, fixture.native_factory)
        self.assertTrue(report['native_validation_passed'])
        self.assertEqual(len(report['native_queries']), 4)
        self.assertEqual([r['guide_present'] for r in report['native_queries']], [True, True, False, False])
        for row in report['native_queries']:
            self.assertAlmostEqual(row['length_xy'], 49.6221275095, places=6)
            self.assertAlmostEqual(row['length_3d'], 49.6950181, places=5)
            self.assertIn(row['expanded'], [12, 14])
        installer.recheck(snapshots, self.root)
        self.assertEqual(self.state(), self.original)

    def test_full_native_probe_refuses_missing_map0_evidence_before_activation(self):
        result = self.run_update(real=True)
        self.assertEqual(result['status'], 'failed_before_activation', result)
        self.assertFalse(result['native_validation_passed'])
        self.assertFalse(result['active_changed'])
        self.assertFalse(result['changes_were_written'])
        self.assertEqual(len(result['native_queries']), 6)
        self.assertIn('0000_48_30.mmtile', result['error'])
        self.assertEqual(self.state(), self.original)

    def test_install_repeat_and_exact_rollback(self):
        first = self.installed()
        current = self.state()
        self.assertEqual(current['navmesh'], self.payload['navmesh'])
        self.assertEqual(current['road_corridor'], self.payload['road_corridor'])
        before, after = json.loads(self.original['manifest']), json.loads(current['manifest'])
        changes = [(a, b) for a, b in zip(before['tiles'], after['tiles']) if a != b]
        self.assertEqual(len(changes), 1)
        self.assertEqual(tuple(changes[0][0][k] for k in ('c', 'row', 'col')), installer.TARGET)
        self.assertEqual(changes[0][1]['sha256'], installer.NEW_TILE_SHA)
        self.assertEqual(after['identity'], installer.index_identity(after))
        self.assertEqual(after['bytes'] - before['bytes'], installer.NEW_TILE_BYTES - installer.OLD_TILE_BYTES)
        nav = self.root / 'data/navigation'
        old_tile = nav / changes[0][0]['path']
        self.assertEqual(installer.sha(old_tile.read_bytes()), installer.OLD_TILE_SHA)
        folder = Path(first['repair_directory'])
        for name in self.original:
            suffix = '.json' if name == 'manifest' else '.py'
            self.assertEqual((folder / (name+'.before'+suffix)).read_bytes(), self.original[name])
        times = {name: path.stat().st_mtime_ns for name, path in self.paths.items()}
        with mock.patch.object(installer, 'verify_native', side_effect=validated_stub) as gate, redirect_stdout(io.StringIO()):
            second = installer.run(self.root)
        self.assertEqual(second['status'], 'already_installed_verified', second.get('error'))
        self.assertTrue(second['native_validation_passed'])
        self.assertEqual(gate.call_count, 1)
        self.assertFalse(second['active_changed'])
        self.assertEqual(self.state(), current)
        self.assertEqual({name: path.stat().st_mtime_ns for name, path in self.paths.items()}, times)
        restored = self.run_update(undo=True)
        self.assertEqual(restored['status'], 'rolled_back', restored.get('error'))
        self.assertEqual(self.state(), self.original)
        again = self.run_update(undo=True)
        self.assertEqual(again['status'], 'already_original')

    def test_unknown_source_before_install_is_refused(self):
        changed = self.original['navmesh'] + b'\n# separate user edit\n'
        self.paths['navmesh'].write_bytes(changed)
        with mock.patch.object(installer, 'verify_native') as gate, redirect_stdout(io.StringIO()):
            result = installer.run(self.root)
        self.assertEqual(result['status'], 'failed_before_activation')
        gate.assert_not_called()
        self.assertEqual(self.paths['navmesh'].read_bytes(), changed)
        self.assertEqual(self.paths['manifest'].read_bytes(), self.original['manifest'])

    def test_rollback_refuses_later_source_or_manifest_changes(self):
        self.installed()
        saved = self.state()
        for name in ('navmesh', 'manifest'):
            with self.subTest(file=name):
                if name == 'manifest':
                    raw = json.loads(saved[name]); raw['later_unrelated_change'] = True
                    changed = installer.encoded(raw)
                else:
                    changed = saved[name] + b'\n# later change\n'
                self.paths[name].write_bytes(changed)
                before = self.state()
                result = self.run_update(undo=True)
                self.assertEqual(result['status'], 'failed_before_activation', result)
                self.assertFalse(result['active_changed'])
                self.assertEqual(self.state(), before)
                self.paths[name].write_bytes(saved[name])

    def test_write_failure_before_nav_and_after_manifest_restores_all_bytes(self):
        actual = installer.atomic_replace
        for failing_file, after_write in [('navmesh', False), ('manifest', True)]:
            with self.subTest(file=failing_file, after_write=after_write):
                triggered = False
                def fail(path, data, *args, **kwargs):
                    nonlocal triggered
                    if Path(path) == self.paths[failing_file] and not triggered:
                        triggered = True
                        if after_write:
                            actual(path, data, *args, **kwargs)
                        raise OSError('injected transaction failure')
                    return actual(path, data, *args, **kwargs)
                with mock.patch.object(installer, 'atomic_replace', side_effect=fail):
                    result = self.run_update()
                self.assertTrue(triggered)
                self.assertEqual(result['status'], 'failed_restored', result)
                self.assertTrue(result['changes_were_written'])
                self.assertFalse(result['active_changed'])
                self.assertFalse(result['rollback_failed'])
                self.assertEqual(self.state(), self.original)

    def test_recovery_does_not_overwrite_a_later_edit(self):
        actual = installer.atomic_replace
        third_party = b'# another editor changed this file\n'
        triggered = False
        def fail(path, data, *args, **kwargs):
            nonlocal triggered
            if Path(path) == self.paths['navmesh'] and not triggered:
                triggered = True
                self.paths['road_corridor'].write_bytes(third_party)
                raise OSError('injected failure with a concurrent edit')
            return actual(path, data, *args, **kwargs)
        with mock.patch.object(installer, 'atomic_replace', side_effect=fail):
            result = self.run_update()
        self.assertEqual(result['status'], 'failed_partial')
        self.assertTrue(result['active_changed'])
        self.assertTrue(result['rollback_failed'])
        self.assertEqual(self.paths['road_corridor'].read_bytes(), third_party)
        self.assertEqual(self.paths['navmesh'].read_bytes(), self.original['navmesh'])
        self.assertEqual(self.paths['manifest'].read_bytes(), self.original['manifest'])
        attempted_undo = self.run_update(undo=True)
        self.assertEqual(attempted_undo['status'], 'failed_before_activation')
        self.assertEqual(self.paths['road_corridor'].read_bytes(), third_party)

    def test_known_partial_install_can_restore_its_exact_receipt(self):
        self.installed()
        self.paths['manifest'].write_bytes(self.original['manifest'])
        self.paths['navmesh'].write_bytes(self.original['navmesh'])
        result = self.run_update(undo=True)
        self.assertEqual(result['status'], 'rolled_back', result.get('error'))
        self.assertEqual(self.state(), self.original)

    def test_failed_rollback_restores_its_starting_installed_state(self):
        self.installed()
        installed_state = self.state()
        actual = installer.atomic_replace
        triggered = False
        def fail(path, data, *args, **kwargs):
            nonlocal triggered
            if Path(path) == self.paths['navmesh'] and not triggered:
                triggered = True
                raise OSError('injected rollback failure')
            return actual(path, data, *args, **kwargs)
        with mock.patch.object(installer, 'atomic_replace', side_effect=fail):
            result = self.run_update(undo=True)
        self.assertEqual(result['status'], 'failed_restored', result)
        self.assertFalse(result['active_changed'])
        self.assertTrue(result['changes_were_written'])
        self.assertEqual(self.state(), installed_state)

    def test_post_validation_change_and_linked_source_refuse_activation(self):
        def change_input(payload, inputs, proposed, snapshots, report, native_factory=None):
            validated_stub(payload, inputs, proposed, snapshots, report)
            inputs['bundle_path'].write_bytes(inputs['bundle_path'].read_bytes() + b' ')
        with mock.patch.object(installer, 'verify_native', side_effect=change_input), redirect_stdout(io.StringIO()):
            result = installer.run(self.root)
        self.assertEqual(result['status'], 'failed_before_activation')
        self.assertFalse(result['active_changed'])
        self.assertEqual(self.state(), self.original)
        shutil.copy2(self.base / 'data/bundle.json', self.root / 'data/bundle.json')
        outside = Path(self.temp.name) / 'outside-source.py'
        outside.write_bytes(self.original['road_corridor'])
        self.paths['road_corridor'].unlink()
        self.paths['road_corridor'].symlink_to(outside)
        result = self.run_update()
        self.assertEqual(result['status'], 'failed_before_activation')
        self.assertEqual(outside.read_bytes(), self.original['road_corridor'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
