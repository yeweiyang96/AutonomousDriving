"""Read captured map1 bridge source geometry without modifying inputs.

The source .mesh remains authoritative. ADT decode/VMO layout helpers are from
the previous read-only analysis, but this case's counts, model, and geometry
are independently recovered and matched against the new captured bytes.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import struct
import sys

import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
CASE = ROOT / "kalimdor_bridge_repro/case_7860200b"
OUT = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


terrain = module("source_terrain", ROOT / "generation_repro/analysis/raw_terrain/read_profile.py")
vmo = module("source_vmo", ROOT / "generation_repro/analysis/identify_bridge_vmap.py")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def audit():
    inventory = json.loads((CASE / "inventory.json").read_bytes())
    errors = []
    for item in inventory["members"]:
        data = (CASE / item["path"]).read_bytes()
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            errors.append(item["path"])
    collection = json.loads((CASE / "inputs/collection.json").read_bytes())
    input_errors = []
    checked = 0
    for item in collection["files"]:
        if item.get("included"):
            data = (CASE / "inputs" / item["path"]).read_bytes()
            checked += 1
            if len(data) != item["bytes"] or sha(data) != item["sha256"]:
                input_errors.append(item["path"])
    c = json.loads((CASE / "case.json").read_bytes())
    r = json.loads((CASE / "runner-result.json").read_bytes())
    report = dict(inventory_members_checked=len(inventory["members"]),
                  inventory_hash_mismatches=errors, raw_inputs_checked=checked,
                  raw_input_hash_mismatches=input_errors,
                  collection_complete=c["collection_complete"],
                  source_evidence_complete=c["source_evidence_complete"],
                  captured_input_stability=c["input_stability"],
                  final_snapshot_checks=c["final_snapshot_checks"],
                  runner_verified_baseline=r["verified_baseline"],
                  runner_input_unchanged=r["input_unchanged"],
                  runner_tool_unchanged=r["tool_unchanged"],
                  historical_raw_input_hashes_available=collection["historical_raw_input_hashes_available"],
                  warnings=c["warnings"])
    assert not errors and not input_errors
    save("input-integrity.json", report)


def clean(vertices, triangles):
    mapping, verts, tris = {}, [], []
    for tri in triangles:
        new = []
        for i in tri:
            if i not in mapping:
                mapping[i] = len(verts)
                verts.append(vertices[i])
            new.append(mapping[i])
        tris.append(new)
    return np.asarray(verts, dtype="<f4").reshape(-1, 3), np.asarray(tris, dtype="<i4").reshape(-1, 3)


def reconstruct_adt():
    sv, st, lv, lt, areas, records = [], [], [], [], [], []
    order = [(37, 38, "ENTIRE"), (37, 39, "LEFT"), (37, 37, "RIGHT"),
             (38, 38, "TOP"), (36, 38, "BOTTOM")]
    portions = {"ENTIRE": range(16384), "LEFT": range(0, 16257, 128),
                "RIGHT": range(127, 16384, 128), "TOP": range(128), "BOTTOM": range(16256, 16384)}
    for row, col, portion in order:
        path = CASE / f"inputs/maps/0001_{row:02}_{col:02}.map"
        d = terrain.decode(path)
        solids = [[p[1], p[2], p[0]] for p in d["vertices"]]
        liquids = [[p[1], z, p[0]] for p, z in zip(d["liquid_vertices"], d["original_liquid_heights"])]
        so, lo = len(sv), len(lv)
        nst, nlt = len(st), len(lt)
        for square in portions[portion]:
            solid_ids, liquid_ids = terrain.triangles(square)
            state = d["half_states"][square][0]
            for half in (0, 1):
                use_solid, use_liquid = True, d["liquid_header"] is not None
                typ = state["liquid_flags"]
                area = 0
                if use_liquid:
                    if typ & 16:
                        use_solid = use_liquid = False
                    elif typ & 3:
                        area = 9
                    elif typ & 12:
                        area = 8
                    else:
                        use_liquid = False
                li = liquid_ids[half]
                si = solid_ids[half * 2:half * 2 + 2]
                if use_liquid:
                    valid = [d["original_liquid_heights"][i] for i in li
                             if d["original_liquid_heights"][i] != terrain.INVALID
                             and d["original_liquid_heights"][i] < terrain.INVALID_MAX]
                    if 0 < len(valid) < 3:
                        total = 0.0
                        for height in valid:
                            total = terrain.f32(total + height)
                        avg = terrain.f32(total / len(valid))
                        for i in li:
                            if liquids[i][1] == terrain.INVALID or liquids[i][1] > terrain.INVALID_MAX:
                                liquids[i][1] = avg
                    if not valid:
                        use_liquid = False
                if use_solid and state["hole"]:
                    use_solid = False
                if use_solid and use_liquid:
                    sh = [solids[i][1] for tri in si for i in tri]
                    lh = [liquids[i][1] for i in li]
                    if min(lh) > max(sh):
                        use_solid = False
                    if min(sh) > max(lh):
                        use_liquid = False
                if use_liquid:
                    lt.append([i + lo for i in li])
                    areas.append(area)
                if use_solid:
                    st.extend([[i + so for i in tri] for tri in si])
        sv.extend(solids)
        if d["liquid_header"] is not None:
            lv.extend(liquids)
        records.append(dict(path=str(path), sha256=d["sha256"], portion=portion,
                            solid_triangles=len(st) - nst, liquid_triangles=len(lt) - nlt,
                            liquid_header=d["liquid_header"]))
    sv, st = clean(sv, st)
    lv, lt = clean(lv, lt)
    return sv, st, lv, lt, bytes(areas), records


def transform(vertices, spawn):
    # General Rz(yaw) Ry(pitch) Rx(roll). We match the result to actual debug
    # vertices with a stated tolerance; it is not presented as a binary replay.
    pitch, yaw, roll = [math.radians(v) for v in spawn["rotation_degrees"]]
    cz, sz = math.cos(yaw), math.sin(yaw)
    cy, sy = math.cos(pitch), math.sin(pitch)
    cx, sx = math.cos(roll), math.sin(roll)
    rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    rotation = rz @ ry @ rx
    origin = terrain.f32(32 * terrain.GRID)
    position = np.array(spawn["position_internal"]) - [origin, origin, 0]
    result = np.asarray(vertices) @ rotation.T * spawn["scale"] + position
    result[:, :2] *= -1
    return result


def main():
    audit()
    spawns = json.loads((CASE / "inputs/target-model-spawns.json").read_bytes())
    referenced = {s["name"] + ".vmo" for s in spawns}
    models, summaries = {}, []
    for path in sorted((CASE / "inputs/vmaps").glob("*.vmo")):
        model = vmo.parse(path)
        models[path.name] = model
        summaries.append(dict(name=path.name, sha256=model["sha256"], bytes=model["bytes"],
                              is_m2=model["is_m2"], group_count=len(model["groups"]),
                              liquid_chunk_sizes=[g["liquid_chunk_bytes"] for g in model["groups"]]))
    assert referenced == models.keys()
    assert all(not any(s["liquid_chunk_sizes"]) for s in summaries)
    save("wmo-liquid.json", dict(unique_models_referenced=len(referenced), parsed_models=len(models),
                                 models_with_liquid=0, wmo_liquid_triangle_count=0,
                                 missing_referenced_models=[], errors=[], models=summaries))

    raw = (CASE / "meshes/map0001_37_38.mesh").read_bytes()
    nv, = struct.unpack_from("<i", raw)
    off = 4 + nv * 12
    nt, = struct.unpack_from("<i", raw, off)
    assert len(raw) == off + 4 + nt * 12
    vertices = np.frombuffer(raw, dtype="<f4", count=3 * nv, offset=4).reshape(-1, 3)
    triangles = np.frombuffer(raw, dtype="<i4", count=3 * nt, offset=off + 4).reshape(-1, 3)
    sv, st, lv, lt, areas, records = reconstruct_adt()
    checks = dict(liquid_vertices_exact_bytes=lv.tobytes() == vertices[:len(lv)].tobytes(),
                  liquid_triangles_exact_bytes=lt.tobytes() == triangles[:len(lt)].tobytes(),
                  solid_adt_vertices_exact_bytes=sv.tobytes() == vertices[len(lv):len(lv)+len(sv)].tobytes(),
                  solid_adt_triangles_exact_bytes=(st+len(lv)).astype("<i4").tobytes() == triangles[len(lt):len(lt)+len(st)].tobytes(),
                  liquid_indices_within_split=bool(np.all(triangles[:len(lt)] < len(lv))),
                  solid_indices_after_split=bool(np.all(triangles[len(lt):] >= len(lv))))
    report = dict(mesh_sha256=sha(raw), vertex_count=nv, triangle_count=nt,
                  liquid_vertex_count=len(lv), liquid_triangle_count=len(lt),
                  solid_vertex_count=nv-len(lv), solid_triangle_count=nt-len(lt),
                  solid_adt_vertex_count=len(sv), solid_adt_triangle_count=len(st),
                  solid_vmap_vertex_count=nv-len(lv)-len(sv), solid_vmap_triangle_count=nt-len(lt)-len(st),
                  liquid_area_histogram=dict(Counter(areas)), checks=checks, adt_load_order=records)
    save("geometry-split.json", report)
    print(json.dumps(report, indent=2), flush=True)
    assert all(checks.values())
    (OUT / "liquid_areas.bin").write_bytes(areas)

    world = vertices[:, [2, 0, 1]].astype(np.float64)
    key = lambda p: tuple(math.floor(float(v) / 0.01) for v in p)
    index = defaultdict(list)
    for i, tri in enumerate(triangles):
        for shift in range(3):
            index[key(world[tri[shift]])].append((i, shift))

    def match(expected):
        anchor = key(expected[0])
        found = []
        for delta in itertools.product((-1, 0, 1), repeat=3):
            for i, shift in index.get(tuple(anchor[j] + delta[j] for j in range(3)), ()):
                actual = world[[triangles[i][(j + shift) % 3] for j in range(3)]]
                error = float(np.max(np.abs(expected - actual)))
                if error <= 0.002:
                    found.append((error, i))
        return sorted(set(found))

    spawn = next(s for s in spawns if s["id"] == 88584)
    model = models[spawn["name"] + ".vmo"]
    matches, ids = [], set()
    for group in model["groups"]:
        transformed = transform(group["vertices"], spawn)
        for ordinal, tri in enumerate(group["triangles"]):
            local_ids = list(reversed(tri)) if model["is_m2"] else list(tri)
            found = match(transformed[local_ids])
            matches.append(dict(group=group["ordinal"], triangle=ordinal,
                                matches=[dict(error=e, debug_triangle=i) for e, i in found]))
            if found:
                ids.add(found[0][1])
    assert all(m["matches"] for m in matches)
    bridge = {i: world[triangles[i]].tolist() for i in sorted(ids)}
    save("bridge-model.json", dict(spawn=spawn, model_path=model["path"], model_sha256=model["sha256"],
                                    is_m2=model["is_m2"], group_count=len(model["groups"]),
                                    triangles_matched=len(matches), triangles=len(matches),
                                    match_tolerance_per_coordinate=0.002,
                                    maximum_matching_error=max(m["matches"][0]["error"] for m in matches),
                                    matches=matches, actual_debug_triangles=bridge,
                                    all_triangles_are_solid_vmap=all(i >= len(lt)+len(st) for i in ids)))

    nav = json.loads((ROOT / "kalimdor_bridge_repro/mesh_analysis/profile.json").read_bytes())
    td = terrain.decode(CASE / "inputs/maps/0001_37_38.map")
    alltri = world[triangles]
    roi = ((alltri[:, :, 0].min(axis=1) <= -2815) & (alltri[:, :, 0].max(axis=1) >= -2840)
           & (alltri[:, :, 1].min(axis=1) <= -3340) & (alltri[:, :, 1].max(axis=1) >= -3405))
    local_ids = np.nonzero(roi)[0].tolist()
    local = {i: alltri[i].tolist() for i in local_ids}
    samples = []
    for sample in nav["samples"]:
        hits = []
        for i, tri in local.items():
            hit = vmo.hit(sample["worldxy"], tri)
            if hit is not None:
                hits.append(dict(debug_triangle=i, source="liquid" if i < len(lt) else "adt_solid" if i < len(lt)+len(st) else "vmap_solid",
                                 identified_bridge_model=i in ids, **hit))
        samples.append(dict(t=sample["t"], worldxy=sample["worldxy"],
                            raw_terrain=terrain.sample(td, sample["worldxy"]),
                            debug_surfaces=sorted(hits, key=lambda h: h["height"]),
                            navigation_surfaces=sample["surfaces"]))
    save("bridge-profile.json", dict(coordinates="world [north,west,height]", samples=samples,
                                     note="Actual captured debug triangles; upward/slope is before Recast filters."))
    save("local-raw-triangles.json", [dict(debug_triangle=i, vertices=tri,
        source="liquid" if i < len(lt) else "adt_solid" if i < len(lt)+len(st) else "vmap_solid",
        identified_bridge_model=i in ids) for i, tri in local.items()])
    print("bridge", len(matches), "matched triangles", min(ids), max(ids), flush=True)
    for sample in samples[::20]:
        print(json.dumps(dict(t=sample["t"], sources=[(h["source"], h["identified_bridge_model"], h["height"], h["slope_degrees"])
                                                      for h in sample["debug_surfaces"]], nav=sample["navigation_surfaces"])), flush=True)


if __name__ == "__main__":
    main()
