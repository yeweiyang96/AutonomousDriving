// Targeted diagnostic: link the original Recast rasterizer, observe each solid
// triangle's effect at selected bridge cells, without editing geometry.
#define main replay_main
#include "../generation_replay/replay.cpp"
#undef main
#include <sstream>

std::string spanState(const rcHeightfield& h, int x, int z) {
    std::ostringstream s; s << '[';
    bool first = true;
    for (rcSpan* p = h.spans[x + z * h.width]; p; p = p->next) {
        if (!first) s << ','; first = false;
        s << '[' << p->smin << ',' << p->smax << ',' << int(p->area) << ']';
    }
    return s.str() + ']';
}

int main(int argc, char** argv) try {
    if (argc != 4) throw std::runtime_error("raster_trace original.mesh liquid_areas.bin NEW_OUTPUT.json");
    if (fs::exists(argv[3])) throw std::runtime_error("Output already exists");
    Geometry g(argv[1], 5059, 8472, argv[2]);
    Context ctx;
    rcConfig cfg = configuration(g, 37, 38);
    const float* verts = g.verts.data() + 3 * g.lv;
    const int nv = g.nv - g.lv, nt = g.nt - g.lt;
    std::vector<unsigned char> flags(nt, STEEP);
    rcClearUnwalkableTriangles(&ctx, cfg.walkableSlopeAngle, verts, nv, g.solids.data(), nt, flags.data());
    rcMarkWalkableTriangles(&ctx, cfg.walkableSlopeAngleNotSteep, verts, nv, g.solids.data(), nt, flags.data(), GROUND);
    std::ofstream output(argv[3]); output << "{\"format\":\"span [smin,smax,area]; triangle indices are global zero-based .mesh\",\"cells\":[\n";
    const std::vector<std::array<int,2>> selected = {
        {1297,1413}, {1297,1410}, {1387,1387}
    };
    bool firstCell = true;
    for (const auto& grid : selected) {
        const int tx = grid[0] / 80, tz = grid[1] / 80;
        const int lx = grid[0] % 80 + 5, lz = grid[1] % 80 + 5;
        rcConfig c = cfg; c.width = c.height = c.tileSize + 2*c.borderSize;
        c.bmin[0] = cfg.bmin[0] + tx * float(cfg.tileSize * cfg.cs);
        c.bmin[2] = cfg.bmin[2] + tz * float(cfg.tileSize * cfg.cs);
        c.bmax[0] = cfg.bmin[0] + (tx+1) * float(cfg.tileSize * cfg.cs);
        c.bmax[2] = cfg.bmin[2] + (tz+1) * float(cfg.tileSize * cfg.cs);
        c.bmin[0] -= c.borderSize * c.cs; c.bmin[2] -= c.borderSize * c.cs;
        c.bmax[0] += c.borderSize * c.cs; c.bmax[2] += c.borderSize * c.cs;
        rcHeightfield* h = rcAllocHeightfield();
        if (!h || !rcCreateHeightfield(&ctx,*h,c.width,c.height,c.bmin,c.bmax,c.cs,c.ch))
            throw std::runtime_error("Cannot create diagnostic field");
        if (!firstCell) output << ','; firstCell = false;
        output << "{\"grid\":[" << grid[0] << ',' << grid[1] << "],\"tile\":[" << tx << ',' << tz
               << "],\"local\":[" << lx << ',' << lz << "],\"bmin\":[" << std::setprecision(12)
               << c.bmin[0] << ',' << c.bmin[1] << ',' << c.bmin[2] << "],\"world_center\":["
               << c.bmin[2]+(lz+.5f)*c.cs << ',' << c.bmin[0]+(lx+.5f)*c.cs << "],\"changes\":[\n";
        std::string before = "[]"; bool firstChange = true;
        for (int i = 0; i < nt; ++i) {
            const int* tr = g.solids.data() + 3*i;
            if (!rcRasterizeTriangle(&ctx,verts+3*tr[0],verts+3*tr[1],verts+3*tr[2],flags[i],*h,c.walkableClimb))
                throw std::runtime_error("Rasterization failed");
            std::string after = spanState(*h,lx,lz);
            if (after == before) continue;
            if (!firstChange) output << ','; firstChange = false;
            output << "{\"triangle\":" << i+g.lt << ",\"slope_area\":" << int(flags[i])
                   << ",\"before\":" << before << ",\"after\":" << after << ",\"verts_detour\":[";
            for (int k=0;k<3;++k) {
                if(k) output << ',';
                const float* v=verts+3*tr[k];output << '[' << v[0] << ',' << v[1] << ',' << v[2] << ']';
            }
            output << "]}\n"; before = after;
        }
        output << "],\"final\":" << before << "}\n";
        rcFreeHeightField(h);
    }
    output << "]}\n";
    return 0;
} catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
