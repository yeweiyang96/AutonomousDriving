# Map 1 bridge candidate validation

`validate_candidate.py` substitutes only tile `(1, 37, 38)` in an isolated,
in-memory navigation pack. It checks all nine captured neighbor tiles against
their manifest before use. It never installs a candidate or modifies a published
planner. The original A/B and reviewed guide come from `upload/last-plan.json`;
the reverse test reverses that exact guide.

Run the complete gate from the workspace root:

```sh
python kalimdor_bridge_repro/candidate_validation/validate_candidate.py \
  --tile kalimdor_bridge_repro/generation_replay/higher-span-area-monotone/reconverted.mmtile \
  --out kalimdor_bridge_repro/candidate_validation/selected-full
```

The default runs both the published v1 and frozen v2 planners in separate Python
package namespaces. `--skip-map0` is for candidate comparison only and deliberately
does not produce a complete installation gate or a zero exit status.

## Gates and evidence

- Original A → B and B → A, both direct native and with the real reviewed guide.
- Six native paths between bridge head, center and tail, in both directions.
  These points retain their exact XY. Their input heights are calculated from
  the authoritative original float32 solid WMO triangles, not from a guessed
  bridge height or a water surface.
- Every successful map 1 path must retain exact endpoint XY, stay within the
  specified length and lateral limits, have no more than one yard of backward
  progress, and contain only native segments.
- Every path is sampled at intervals no greater than half a yard and compared
  to original upward solid triangles with slope at most 50 degrees. Maximum
  allowed vertical approximation is `2 × 0.2666666 + 0.02 = 0.5533332` yards,
  covering voxel surface rounding and numeric margin. This is an approximation
  gate, not a claim that the simplified navigation surface equals raw geometry.
- The shared library is pinned to SHA-256
  `cf921f698b6e3e2b9ead57ae24ec234abd89c5822d00e297c4751cdb6393f284`.
  Its normal walking filter remains include `0x11`, exclude `0x0e`; no filter
  override, swimming allowance or off-mesh connection is introduced.
- Each planner also runs the four prior map 0 regression routes. Their final XYZ
  points and expansion counts must exactly equal the prior verified production
  replay reports. The map 0 fixture is explicitly partial: long routes request
  three unavailable neighboring tiles `(0,48,30)`, `(0,49,30)`, `(0,50,30)`.
  The short routes have no omitted requests. Missing assets are reported rather
  than fabricated.

## Results

| Tile variant | A → B native XY yards | B → A native XY yards | Bridge gates |
| --- | ---: | ---: | --- |
| Original baseline | 449.6811539 | 443.2697029 | Failed |
| Higher-span area fix, original layer regions | 449.6811539 | 443.1609873 | Failed |
| Original span merge, monotone regions | 1852.5265917 | 1868.0611821 | Failed |
| Higher-span area fix and monotone regions | 49.6221275 | 49.6221275 | Passed |

The selected tile has SHA-256
`d8497ef8ac2cb510a2b950af4e24360d746cbe7f71699773c2ad3bcbd824f7ce`
and is 1,269,700 bytes. Both v1 and v2 pass all ten bridge cases and all four map
0 regressions. The full reports are `selected-full/v1.json`,
`selected-full/v2.json`, and `selected-full/summary.json`.

For the selected tile the original A/B route has 13 points, 14 expansions
forward and 12 in reverse. Three-dimensional length is 49.6950181 yards.
All four full A/B paths have zero backward progress and maximum cross-track
deviation about 0.07585 yards. Maximum measured difference from eligible raw
solid surface height is about 0.54076 yards.

The four prior map 0 results remain 41.0717386, 41.0716539, 3514.8241907 and
3516.7395769 three-dimensional yards, with 19, 142, 5350 and 5553 expansions.

The original tile remains a failing control. With v1 its reviewed route accepts
the detour. With v2 the reviewed-route calls return
`road_connection_unverified`, while direct native queries still return the
detour. The selected tile instead restores the short native bridge crossing;
its success does not depend on the v2 rejection guard.

## Execution boundary

These are real calls to the captured native implementation rebuilt for Linux,
using real hash-checked navigation assets. They are not Windows execution. The
installer must preflight its candidate with the user's current Windows DLL
before writing production files. No game input, process attachment, modified
raw collision model, parameter sweep or synthetic path is involved.
