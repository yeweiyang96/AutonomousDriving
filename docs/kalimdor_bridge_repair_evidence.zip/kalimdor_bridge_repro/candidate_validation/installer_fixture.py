"""Import-only real-asset fixture for isolated installer transaction tests.

This deliberately retains the original full manifest but copies only captured
assets. Missing map 0 collar tiles stay missing and must not pass an installer's
strict required-asset gate. No asset, Windows PE header or path is synthesized.
There is no command-line switch for native substitution.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]
V1 = ROOT / 'route_quality_repro/working/adrive'
CAPTURE = ROOT / 'route_quality_repro/case_d2f9f429'
MAP0 = ROOT / 'navigation_repro/case_87e934c9/data/navigation'
MAP1 = ROOT / 'kalimdor_bridge_repro/case_d10b202e'
MAP0_REPAIR = ROOT / 'generation_repro/recast_replay/higher-span-area-monotone/reconverted.mmtile'
LIBRARY = ROOT / 'navigation_repro/replay/libadrive_navmesh.so'
LIBRARY_SHA = 'cf921f698b6e3e2b9ead57ae24ec234abd89c5822d00e297c4751cdb6393f284'
MANIFEST_SHA = '47a21c1b6845fa8cf74546d532959366eaad0da7b0de04c95cc91add1ec77c69'
BUNDLE_SHA = '9d5065b341ec1063f083e319807c12d3f47eb2c67d2f8a11f23a20b2d6b1fd18'
SOURCE_HASHES = {
    '__init__.py': 'b166caa40413d78db8443154c3e16c97c8f809d33210efdecbe8ae853587054b',
    'models.py': '5e13b795e98fd67a26d659b99f73ba6c9c30b8c52e178106460c2fd5e7bb6167',
    'data.py': 'd25c9a508cf69cfed7d8584ce5eeb9324ed42ab1368d2d32fddbe895a0931385',
    'planner.py': '5b4794ad8815acc9201d357aaea7ea9d1355380abed2312481ae069445eb7123',
    'navmesh.py': '64efa0d0f8f069632644c2db11bff6dd3a72a0a437f545f23c38bd28fbbd325d',
    'road_corridor.py': 'f42e3cfd5b8d6053a6452afc043278512189b559913c884cdbbcd0dd1bedf7b3',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(path, expected_sha, expected_bytes=None):
    if digest(path) != expected_sha:
        raise ValueError('Fixture source hash mismatch: ' + str(path))
    if expected_bytes is not None and path.stat().st_size != expected_bytes:
        raise ValueError('Fixture source size mismatch: ' + str(path))


def build_fixture(new_empty_root):
    """Copy real captured inputs into an empty project; return its inventory."""
    target = Path(new_empty_root).resolve()
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise ValueError('Fixture destination must be a new or empty directory')
    manifest_path = MAP1 / 'manifest.json'
    verify(manifest_path, MANIFEST_SHA)
    manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    if manifest['identity'] != '9e09d71b0068bb29':
        raise ValueError('Unexpected original navigation identity')

    copies = []
    for name, expected in SOURCE_HASHES.items():
        source = V1 / name
        verify(source, expected)
        copies.append((source, Path('adrive') / name))
    bundle = CAPTURE / 'data/bundle.json'
    verify(bundle, BUNDLE_SHA)
    copies.extend([(bundle, Path('data/bundle.json')),
                   (manifest_path, Path('data/navigation/manifest.json'))])
    navigation = Path('data/navigation')
    library = manifest['library']
    windows_dll = MAP0 / library['path']
    verify(windows_dll, library['sha256'], library['bytes'])
    if windows_dll.read_bytes()[:2] != b'MZ':
        raise ValueError('The original Windows DLL PE must remain in the fixture')
    copies.append((windows_dll, navigation / library['path']))
    for entry in manifest['maps']:
        source = MAP1 / Path(entry['path']).name if entry['c'] == 1 else MAP0 / entry['path']
        verify(source, entry['sha256'], entry['bytes'])
        copies.append((source, navigation / entry['path']))

    available = []
    for entry in manifest['tiles']:
        key = (entry['c'], entry['row'], entry['col'])
        if key[0] == 1:
            source = MAP1 / Path(entry['path']).name
        else:
            source = MAP0_REPAIR if key == (0, 50, 34) else MAP0 / entry['path']
        if not source.is_file():
            continue
        verify(source, entry['sha256'], entry['bytes'])
        available.append(key)
        copies.append((source, navigation / entry['path']))
    required_map1 = {(1, r, c) for r in range(36, 39) for c in range(37, 40)}
    if required_map1 - set(available):
        raise ValueError('Captured map 1 neighbors are incomplete')
    expected_missing = {(0, 48, 30), (0, 49, 30), (0, 50, 30)}
    if expected_missing & set(available):
        raise ValueError('The known partial fixture unexpectedly changed')
    target.mkdir(parents=True, exist_ok=True)
    for source, relative in copies:
        destination = (target / relative).resolve()
        if not destination.is_relative_to(target):
            raise ValueError('Fixture path escapes destination')
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Real copies avoid aliasing immutable evidence if a transaction test
        # intentionally corrupts or rewrites a fixture file.
        shutil.copy2(source, destination)
    return {
        'project_root': str(target), 'original_identity': manifest['identity'],
        'full_manifest_preserved': True, 'manifest_sha256': MANIFEST_SHA,
        'bundle_sha256': BUNDLE_SHA, 'source_hashes': dict(SOURCE_HASHES),
        'windows_dll_sha256': library['sha256'], 'asset_count': len(copies),
        'available_tiles': sorted(available),
        'missing_required_map0_collar': sorted(expected_missing),
        'fixture_is_partial': True,
    }


def native_factory(original_native, path):
    """Test injection only: retain fixture PE checks, execute the real Linux SO."""
    verify(LIBRARY, LIBRARY_SHA)
    return original_native(LIBRARY)
