"""Real native gates for the captured Kalimdor bridge; never installs a tile.

Only (1, 37, 38) is substituted in memory. All nine original neighbors, the
native shared library and authoritative source geometry are hash checked.
Normal native ground filtering is unchanged. Reports describe Linux execution,
not Windows DLL certification; the installer must run the latter itself.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import importlib
import importlib.util
import json
import math
from pathlib import Path
import struct
import sys
import time

import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
NEIGHBORS = ROOT / 'kalimdor_bridge_repro/case_d10b202e'
SOURCE = ROOT / 'kalimdor_bridge_repro/case_7860200b'
ANALYSIS = ROOT / 'kalimdor_bridge_repro/source_analysis'
LIBRARY = ROOT / 'navigation_repro/replay/libadrive_navmesh.so'
LIBRARY_SHA = 'cf921f698b6e3e2b9ead57ae24ec234abd89c5822d00e297c4751cdb6393f284'
ORIGINAL_TILE_SHA = 'bf81052e0ebbc9e5bbd58e2ae269181b14c0e59e9a2f9874d5ba6707e292a825'
MESH_SHA = 'a658249ea0abee414fea9933224353022a2b53ee79836cc35dc4c75052185f3c'
DIAGNOSTIC = ROOT / 'upload/last-plan.json'
TARGET = (1, 37, 38)
PLANNERS = {
    'v1': ROOT / 'route_quality_repro/working/adrive',
    'v2': ROOT / 'kalimdor_bridge_repro/candidate/adrive',
}
MAP0_CAPTURE = ROOT / 'route_quality_repro/case_d2f9f429'
MAP0_ORIGINAL = ROOT / 'navigation_repro/case_87e934c9/data/navigation'
MAP0_REPAIR = ROOT / 'generation_repro/recast_replay/higher-span-area-monotone/reconverted.mmtile'
MAP0_REPAIR_SHA = '74dd28d4d559518bca84b678ac3fb3ccd5ba294c8ab65bebcede927acc46df1c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def xyz(point):
    return [point.x, point.y, point.z]


def checked_asset(path, expected_sha=None, expected_bytes=None):
    data = path.read_bytes()
    digest = sha(data)
    if expected_sha is not None and digest != expected_sha:
        raise ValueError('SHA mismatch: ' + str(path))
    if expected_bytes is not None and len(data) != expected_bytes:
        raise ValueError('Size mismatch: ' + str(path))
    return data


def load_planner(version):
    directory = PLANNERS[version]
    name = '_bridge_validation_' + version
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(
            name, directory / '__init__.py', submodule_search_locations=[str(directory)])
        package = importlib.util.module_from_spec(spec)
        sys.modules[name] = package
        spec.loader.exec_module(package)
    return importlib.import_module(name + '.navmesh')


class SolidGeometry:
    """Vertical evidence from original solid faces, not from candidate flags."""

    def __init__(self):
        data = checked_asset(SOURCE / 'meshes/map0001_37_38.mesh', MESH_SHA)
        vertex_count = struct.unpack_from('<i', data)[0]
        vertices = np.frombuffer(data, '<f4', vertex_count * 3, 4).reshape(-1, 3)
        cursor = 4 + vertex_count * 12
        triangle_count = struct.unpack_from('<i', data, cursor)[0]
        indices = np.frombuffer(data, '<i4', triangle_count * 3, cursor + 4).reshape(-1, 3)
        if cursor + 4 + triangle_count * 12 != len(data):
            raise ValueError('Unexpected mesh trailing data')
        split = read_json(ANALYSIS / 'geometry-split.json')
        if split['mesh_sha256'] != MESH_SHA or not all(split['checks'].values()):
            raise ValueError('Source solid/liquid split has not been verified')
        world = vertices[:, [2, 0, 1]].astype('float64')
        triangles = world[indices]
        first_solid = split['liquid_triangle_count']
        self.triangle_ids = np.arange(first_solid, triangle_count)
        self.triangles = triangles[first_solid:]
        normals = np.cross(self.triangles[:, 1] - self.triangles[:, 0],
                           self.triangles[:, 2] - self.triangles[:, 0])
        norms = np.linalg.norm(normals, axis=1)
        eligible = (norms > 0) & (normals[:, 2] >= norms * math.cos(math.radians(50)))
        self.triangles = self.triangles[eligible]
        self.triangle_ids = self.triangle_ids[eligible]
        self.low = self.triangles[:, :, :2].min(axis=1)
        self.high = self.triangles[:, :, :2].max(axis=1)
        bridge = read_json(ANALYSIS / 'bridge-model.json')
        if bridge['triangles_matched'] != bridge['triangles'] or not bridge['all_triangles_are_solid_vmap']:
            raise ValueError('Bridge model has not been matched to original solid geometry')
        checked_asset(Path(bridge['model_path']), bridge['model_sha256'])
        self.bridge_ids = frozenset(map(int, bridge['actual_debug_triangles']))
        # These fractions are selected from the independently identified WMO
        # bridge span (t = .165 through .685), safely inside its end surfaces.
        diag = read_json(DIAGNOSTIC)
        a, b = diag['start'], diag['goal']
        self.samples = []
        for name, t in [('head', .18), ('center', .425), ('tail', .67)]:
            x, y = a['x'] + t * (b['x'] - a['x']), a['y'] + t * (b['y'] - a['y'])
            hits = [h for h in self.hits(x, y) if h['triangle'] in self.bridge_ids]
            if not hits:
                raise ValueError('Raw bridge sample has no slope-eligible model surface: ' + name)
            hit = max(hits, key=lambda h: h['z'])
            self.samples.append({'name': name, 't': t, 'xyz': [x, y, hit['z']],
                                 'source_triangle': hit['triangle']})

    def hits(self, x, y):
        selected = np.flatnonzero((self.low[:, 0] <= x + 1e-8) & (self.high[:, 0] >= x - 1e-8)
                                  & (self.low[:, 1] <= y + 1e-8) & (self.high[:, 1] >= y - 1e-8))
        hits = []
        for index in selected:
            a, b, c = self.triangles[index]
            v, w = b[:2] - a[:2], c[:2] - a[:2]
            denominator = v[0] * w[1] - v[1] * w[0]
            if abs(denominator) < 1e-12:
                continue
            d = np.array([x, y]) - a[:2]
            u = (d[0] * w[1] - d[1] * w[0]) / denominator
            v2 = (v[0] * d[1] - v[1] * d[0]) / denominator
            if min(u, v2, 1-u-v2) >= -1e-7:
                hits.append({'triangle': int(self.triangle_ids[index]),
                             'z': float(a[2] + u*(b[2]-a[2]) + v2*(c[2]-a[2]))})
        return hits

    def route_gate(self, points):
        errors, samples = [], 0
        maximum_error = 0.0
        # Two cell heights (0.5333332) plus 0.02 yards numerical margin.
        # This allows Recast's voxel surface offset, not the water layer.
        tolerance = .5533332
        for a, b in zip(points, points[1:]):
            steps = max(1, math.ceil(math.dist(a[:2], b[:2]) / .5))
            for i in range(steps + 1):
                t = i / steps
                p = [a[j] + t*(b[j]-a[j]) for j in range(3)]
                hits = self.hits(p[0], p[1])
                error = min((abs(p[2]-h['z']) for h in hits), default=math.inf)
                samples += 1
                maximum_error = max(maximum_error, error)
                if error > tolerance and len(errors) < 20:
                    errors.append({'xyz': p, 'closest_error': error if math.isfinite(error) else None,
                                   'solid_surfaces': hits})
        return {'passed': not errors, 'sample_count': samples,
                'sample_spacing_max_yards': .5, 'tolerance_yards': tolerance,
                'maximum_height_error_yards': maximum_error if math.isfinite(maximum_error) else None,
                'first_failures': errors}


def pack_class(nm):
    class TraceMesh(nm.Mesh):
        def load(self, keys):
            self.pack.requested.update((self.c, *k) for k in keys)
            return super().load(keys)

        def heights(self, point):
            result = super().heights(point)
            self.pack.surfaces.append({'point': xyz(point), 'heights': result})
            return result

        def path(self, start, goal, budget):
            record = {'start': xyz(start), 'goal': xyz(goal), 'budget': budget,
                      'context': dict(self.debug_context)}
            self.pack.calls.append(record)
            try:
                parts, count = super().path(start, goal, budget)
                route = nm.Route(start, goal, tuple(parts), count)
                record.update(status='success', expanded=count, length_xy=route.distance,
                              points=[xyz(p) for p in route.points])
                return parts, count
            except nm.PlanningError as exc:
                record.update(status=exc.code, expanded=getattr(exc, 'expanded', None), message=str(exc))
                raise

    class ValidationPack(nm.NavMeshPack):
        def __init__(self, tile=None, *, map0=False):
            manifest = (MAP0_CAPTURE / 'data/navigation/manifest.json') if map0 else (NEIGHBORS / 'manifest.json')
            self.raw = read_json(manifest)
            self.identity = self.raw['identity']
            self.original_identity = self.identity
            self.build = self.raw['client']['version']
            self.maps = {m['c']: m for m in self.raw['maps']}
            self.all_tiles = {(t['c'], t['row'], t['col']): t for t in self.raw['tiles']}
            self.root = MAP0_ORIGINAL if map0 else NEIGHBORS
            self.paths = {}
            for key, entry in self.all_tiles.items():
                path = (MAP0_REPAIR if key == (0, 50, 34) else MAP0_ORIGINAL / entry['path']) if map0 else NEIGHBORS / Path(entry['path']).name
                if path.is_file():
                    self.paths[key] = path
            self.tiles = {k: dict(self.all_tiles[k]) for k in self.paths}
            if not map0:
                if len(self.tiles) != 9 or set(self.tiles) != {(1, r, c) for r in range(36, 39) for c in range(37, 40)}:
                    raise ValueError('The exact nine-tile neighbor fixture is required')
                for k, path in self.paths.items():
                    entry = self.all_tiles[k]
                    checked_asset(path, entry['sha256'], entry['bytes'])
                if self.all_tiles[TARGET]['sha256'] != ORIGINAL_TILE_SHA:
                    raise ValueError('Unexpected original target tile')
                if tile is not None:
                    candidate = checked_asset(tile)
                    self.tiles[TARGET].update(sha256=sha(candidate), bytes=len(candidate))
                    self.paths[TARGET] = tile
                    if sha(candidate) != ORIGINAL_TILE_SHA:
                        self.identity = 'validation-' + sha(candidate)[:16]
            self.native = nm.Native(LIBRARY)
            self.max_bytes = 384 * 1024 * 1024
            self.record_diagnostics = False
            self.last_route_diagnostics = None
            self.calls, self.surfaces, self.reads, self.requested = [], [], {}, set()

        def read(self, entry):
            key = (entry.get('c'), entry.get('row'), entry.get('col'))
            path = self.paths[key] if key in self.paths else (
                self.root / entry['path'] if self.root == MAP0_ORIGINAL else self.root / Path(entry['path']).name)
            data = checked_asset(path, entry['sha256'], entry['bytes'])
            self.reads[str(path)] = {'bytes': len(data), 'sha256': sha(data)}
            return data

        @contextmanager
        def mesh(self, c, cancel=None):
            mesh = TraceMesh(self, c, cancel)
            try:
                yield mesh
            finally:
                mesh.close()

    return ValidationPack


def make_guide(nm, diag, reverse=False):
    start, goal = nm.Point(**diag['start']), nm.Point(**diag['goal'])
    segments = [nm.Segment(tuple(nm.Point(**p) for p in s['points']), s['source'],
                           s['reliability'], s['edge_id']) for s in diag['guide']['segments']]
    if reverse:
        start, goal = goal, start
        segments = [nm.Segment(tuple(reversed(s.points)), s.source, s.reliability, s.edge_id)
                    for s in reversed(segments)]
    return nm.Route(start, goal, tuple(segments))


def native_query(pack, nm, start, goal, *, height_tolerance=None):
    with pack.mesh(start.c) as mesh:
        mesh.load({(r, c) for continent, r, c in pack.tiles if continent == start.c})
        resolved = []
        for p in (start, goal):
            heights = mesh.heights(p)
            if not heights:
                raise nm.PlanningError('navmesh_outside', 'Native endpoint has no normal-filter ground surface')
            if p.z is None and len(heights) != 1:
                raise nm.PlanningError('navmesh_height', 'Native endpoint requires explicit height')
            height = min(heights, key=lambda h: abs(h-p.z)) if p.z is not None else heights[0]
            if height_tolerance is not None and p.z is not None and abs(height-p.z) > height_tolerance:
                raise nm.PlanningError('raw_surface_mismatch', 'Native surface is on a different raw-model height')
            resolved.append(nm.Point(p.c, p.x, p.y, height))
        mesh.debug_context = {'stage': 'direct_validation', 'plan_budget': 500000, 'expanded_before': 0}
        parts, count = mesh.path(*resolved, 500000)
        return nm.Route(*resolved, tuple(parts), count)


def geometric_gates(route, start, goal, geometry, *, local=False):
    points = [xyz(p) for p in route.points]
    axis = [goal.x-start.x, goal.y-start.y]
    distance = math.hypot(*axis)
    axis = [v / distance for v in axis]
    backward = sum(max(0.0, -sum((b[k]-a[k])*axis[k] for k in (0, 1)))
                   for a, b in zip(points, points[1:]))
    cross_track = max(abs((p[0]-start.x)*axis[1] - (p[1]-start.y)*axis[0]) for p in points)
    limit = distance * 1.35 + 5.0
    raw = geometry.route_gate(points)
    endpoints = points[0][:2] == xyz(start)[:2] and points[-1][:2] == xyz(goal)[:2]
    checks = {'exact_xy_endpoints': endpoints, 'reasonable_length': route.distance <= limit,
              'forward_progress': backward <= 1.0, 'stays_near_bridge': cross_track <= (3.0 if local else 6.0),
              'raw_solid_surface': raw['passed'],
              'all_segments_native': all(s.reliability == 'navmesh' for s in route.segments)}
    return {'passed': all(checks.values()), 'checks': checks, 'length_limit_xy': limit,
            'backward_progress_yards': backward, 'max_cross_track_yards': cross_track,
            'raw_geometry': raw}


def run_case(label, pack, nm, start, goal, guide, geometry, *, direct=False, local=False):
    result = {'case': label, 'start': xyz(start), 'goal': xyz(goal), 'direct_native': direct,
              'guide_mode': 'none' if guide is None else 'original reviewed guide or exact reverse',
              'native_filter': {'include': '0x11', 'exclude': '0x0e', 'offmesh_connections': False}}
    began = time.monotonic()
    try:
        route = native_query(pack, nm, start, goal, height_tolerance=.5533332 if local else None) if direct else pack.plan(start, goal, guide=guide)
        result.update(status='success', expanded=route.expanded, length_xy=route.distance,
                      length_3d=sum(math.dist(xyz(a), xyz(b)) for a,b in zip(route.points,route.points[1:])),
                      points=[xyz(p) for p in route.points], edges=[s.edge_id for s in route.segments],
                      gates=geometric_gates(route, start, goal, geometry, local=local))
    except nm.PlanningError as exc:
        result.update(status=exc.code, message=str(exc), expanded=getattr(exc, 'expanded', None),
                      gates={'passed': False})
    result.update(elapsed_seconds=time.monotonic()-began, native_queries=len(pack.calls),
                  calls=pack.calls, surfaces=pack.surfaces, loaded_assets=pack.reads,
                  omitted_requested_tiles=sorted(k for k in pack.requested if k in pack.all_tiles and k not in pack.tiles),
                  production_diagnostics=pack.last_route_diagnostics)
    return result


def map0_regressions(nm, Pack):
    package = nm.__package__
    bundle = importlib.import_module(package + '.data').DataBundle.load(MAP0_CAPTURE / 'data/bundle.json')
    planner = importlib.import_module(package + '.planner').Planner(bundle)
    points = [nm.Point(0, *p) for p in (
        (-10065.478503779887, -1507.212281364077, 28.680936813354492),
        (-10079.181030588508, -1468.9011349807895, 28.680936813354492),
        (-9486.727746196266, 66.20478324520349, 56.24121856689453),
        (-10550.815788443762, -1196.5663646349744, 27.7370548248291))]
    results = []
    for label, start, goal in [('short', points[0], points[1]), ('short-reverse', points[1], points[0]),
                               ('long', points[2], points[3]), ('long-reverse', points[3], points[2])]:
        pack = Pack(map0=True)
        original = read_json(ROOT / 'route_quality_repro/replay' / ('production-' + label + '.json'))
        record = {'case': 'map0_' + label, 'fixture_is_partial': True,
                  'map0_repair_sha256': MAP0_REPAIR_SHA, 'start': xyz(start), 'goal': xyz(goal)}
        try:
            route = pack.plan(start, goal, guide=planner._plan_coarse(start, goal))
            actual = [xyz(p) for p in route.points]
            same_points = actual == original['points']
            same_count = route.expanded == original['expanded']
            record.update(status='success', length_xy=route.distance,
                          length_3d=sum(math.dist(xyz(a), xyz(b)) for a,b in zip(route.points,route.points[1:])),
                          expanded=route.expanded, points=actual,
                          gates={'passed': same_points and same_count,
                                 'matches_previous_verified_native_points': same_points,
                                 'matches_previous_expansion_count': same_count},
                          baseline_report_sha256=sha((ROOT / 'route_quality_repro/replay' / ('production-' + label + '.json')).read_bytes()))
        except nm.PlanningError as exc:
            record.update(status=exc.code, message=str(exc), gates={'passed': False})
        record.update(native_queries=len(pack.calls), calls=pack.calls, loaded_assets=pack.reads,
                      omitted_requested_tiles=sorted(k for k in pack.requested if k in pack.all_tiles and k not in pack.tiles),
                      production_diagnostics=pack.last_route_diagnostics)
        results.append(record)
        print(json.dumps({k: record.get(k) for k in ('case','status','length_3d','expanded','gates')}, ensure_ascii=False), flush=True)
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tile', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--planner', choices=('v1', 'v2', 'both'), default='both')
    parser.add_argument('--skip-map0', action='store_true', help='Fast candidate comparison; report remains incomplete for installation.')
    options = parser.parse_args()
    checked_asset(LIBRARY, LIBRARY_SHA)
    candidate = checked_asset(options.tile)
    geometry = SolidGeometry()
    diagnostic = read_json(DIAGNOSTIC)
    if diagnostic['start']['c'] != 1 or diagnostic['blocked_edges']:
        raise ValueError('Unexpected captured bridge case')
    options.out.mkdir(parents=True, exist_ok=True)
    summary = {'schema': 1, 'execution_platform': 'Linux native reconstruction',
               'windows_dll_preflight_required': True, 'candidate_path': str(options.tile.resolve()),
               'candidate_sha256': sha(candidate), 'candidate_bytes': len(candidate),
               'original_tile_sha256': ORIGINAL_TILE_SHA, 'native_library_sha256': LIBRARY_SHA,
               'raw_mesh_sha256': MESH_SHA, 'source_diagnostic_sha256': sha(DIAGNOSTIC.read_bytes()),
               'local_samples_from_raw_model': geometry.samples, 'planners': {},
               'map0_regressions_included': not options.skip_map0}
    for version in (('v1', 'v2') if options.planner == 'both' else (options.planner,)):
        nm = load_planner(version)
        Pack = pack_class(nm)
        start, goal = nm.Point(**diagnostic['start']), nm.Point(**diagnostic['goal'])
        cases = []
        for reverse, a, b in ((False, start, goal), (True, goal, start)):
            suffix = 'B_to_A' if reverse else 'A_to_B'
            for guided in (False, True):
                label = ('guided_' if guided else 'native_') + suffix
                record = run_case(label, Pack(options.tile), nm, a, b,
                                  make_guide(nm, diagnostic, reverse) if guided else None,
                                  geometry, direct=not guided)
                cases.append(record)
                print(json.dumps({'planner': version, **{k:record.get(k) for k in ('case','status','length_xy','expanded')},
                                  'passed':record['gates']['passed']}, ensure_ascii=False), flush=True)
        locals_ = [nm.Point(1, *s['xyz']) for s in geometry.samples]
        for i, j in ((0, 1), (1, 2), (0, 2), (1, 0), (2, 1), (2, 0)):
            label = 'local_' + geometry.samples[i]['name'] + '_to_' + geometry.samples[j]['name']
            record = run_case(label, Pack(options.tile), nm, locals_[i], locals_[j], None,
                              geometry, direct=True, local=True)
            cases.append(record)
            print(json.dumps({'planner': version, 'case': label, 'status': record['status'],
                              'length_xy': record.get('length_xy'), 'passed': record['gates']['passed']}), flush=True)
        regressions = [] if options.skip_map0 else map0_regressions(nm, Pack)
        report = {'planner': version, 'source_hashes': {n: sha((PLANNERS[version] / n).read_bytes())
                  for n in ('navmesh.py', 'road_corridor.py')}, 'cases': cases, 'map0_regressions': regressions,
                  'bridge_gates_passed': all(c['gates']['passed'] for c in cases),
                  'all_gates_passed': not options.skip_map0 and all(c['gates']['passed'] for c in cases + regressions)}
        path = options.out / (version + '.json')
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        summary['planners'][version] = {k: v for k, v in report.items() if k not in ('cases', 'map0_regressions')}
        summary['planners'][version]['report'] = str(path.resolve())
    summary['all_gates_passed'] = bool(summary['planners']) and all(p['all_gates_passed'] for p in summary['planners'].values())
    path = options.out / 'summary.json'
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0 if summary['all_gates_passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
