# Kalimdor bridge repair evidence

The standalone Windows installer is included under
kalimdor_bridge_repro/deliverables/apply_kalimdor_bridge_fix.py.
Use the Chinese report beside it for results, installation and rollback.

This archive preserves analysis, generated meshes, candidate source,
reproduction scripts, installer source/tests and measured native results.
It is an analysis checkpoint, not a second installer. Binary executables,
bytecode caches and the 100 MB of reproducible per-cell CSV traces are omitted.

Analysis scripts retain their recorded workspace layout and need the original
input/source bundles. They are not advertised as a self-contained build kit.
The original inputs are unchanged and remain available in these files:

- Original bridge collision/generation capture:
  https://chatgpt.com/library?file_id=libfile_7860200b69208191be4620b989ce39cd&account_id=personal
- Original nine map1 navigation tiles and manifest:
  https://chatgpt.com/library?file_id=libfile_d10b202e30848191b953acd7f7606dbd&account_id=personal
- Original map1 route diagnostic:
  https://chatgpt.com/library?file_id=libfile_20d20a578a588191a80ca39dbb9b695b&account_id=personal
- Previously captured generator source and raw evidence:
  https://chatgpt.com/library?file_id=libfile_fe9a753111f08191ba8828d680b4d1d8&account_id=personal

Old map0 regressions reuse the earlier route_quality_repro and
navigation_repro fixtures. Their three missing peripheral request tiles are
explicitly recorded in candidate_validation reports. The installer does not
omit missing tiles; its Windows validation must succeed before activation.

Only the target map1 tile and two planner modules are included in the repair.
No claim is made that the separate new Westfall case is fixed.
