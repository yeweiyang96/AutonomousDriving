#!/usr/bin/env python3
"""Read explicitly named route JSON files and print an evidence-only audit.

Standard library only. No directory discovery, DLL loading, route search,
network access, production writes or changes to navigation policy occur.
Query counts reconstructed from v1/v2 trace control flow are labelled as such;
the trace is not treated as a complete raw native-call recording.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import sys

MAX_INPUT_BYTES = 16 * 1024 * 1024
SUPPORTED_PROTOCOLS = {'road-corridor-v1', 'road-corridor-v2'}
FORWARD_MODES = {'road', 'road_tolerance', 'local_detour'}
FALLBACK_RADII = (1, 2, 4)


def nonnegative_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def extract_native_debug(message):
    if not isinstance(message, str) or 'NAV_DEBUG ' not in message:
        return None, None
    text = message.split('NAV_DEBUG ', 1)[1]
    try:
        value, _ = json.JSONDecoder().raw_decode(text)
        return (value, None) if isinstance(value, dict) else (None, 'NAV_DEBUG is not an object')
    except ValueError as error:
        return None, str(error)


def counter_dict(values):
    return dict(sorted(Counter('unspecified' if value is None else str(value) for value in values).items()))


def reconstruct_road_queries(trace, *, truncated=False):
    events, cached, warnings = [], [], []
    fresh, seen, current_anchor, iteration = True, {}, None, -1
    for index, row in enumerate(trace):
        if not isinstance(row, dict):
            fresh = True
            warnings.append('Non-object trace row at %d' % index)
            continue
        # v1/v2 retain first 1000 + last 1000 rows when truncating. Never infer
        # a cache hit across that unrecorded middle interval.
        if truncated and len(trace) == 2000 and index == 1000:
            fresh = True
        mode = row.get('mode')
        if mode in FORWARD_MODES:
            if fresh or current_anchor != row.get('from_anchor'):
                if not fresh:
                    warnings.append('Unmarked iteration boundary at trace %d' % index)
                iteration += 1
                seen, fresh, current_anchor = {}, False, row.get('from_anchor')
            target = row.get('target')
            key = (row.get('to_anchor'), target[2]) if isinstance(target, list) and len(target) == 3 else None
            if key is not None and key in seen:
                cached.append({'trace_index': index, 'reuses_trace_index': seen[key],
                               'iteration': iteration, 'mode': mode,
                               'displayed_native_expanded': row.get('native_expanded')})
            else:
                events.append({'trace_index': index, 'iteration': iteration,
                               'kind': 'forward', 'row': row})
                if key is not None:
                    seen[key] = index
                else:
                    warnings.append('Missing cache key at trace %d' % index)
            if row.get('accepted') is True:
                fresh = True
        elif mode == 'native_reconnect':
            events.append({'trace_index': index, 'iteration': iteration,
                           'kind': 'reconnect', 'row': row})
        elif mode == 'rollback_soft_anchor':
            fresh = True
    return events, cached, warnings


def event_statistics(events):
    forward = [e for e in events if e['kind'] == 'forward']
    reconnect = [e for e in events if e['kind'] == 'reconnect']
    known = [e for e in events if nonnegative_number(e['row'].get('native_expanded'))]
    unknown = [e['trace_index'] for e in events if not nonnegative_number(e['row'].get('native_expanded'))]
    excessive = [e for e in forward if e['row'].get('status') == 'excessive_detour']
    return {
        'reconstructed_query_count': len(events),
        'forward_queries': len(forward), 'reconnect_queries': len(reconnect),
        'forward_status_counts': counter_dict(e['row'].get('status', 'unspecified') for e in forward),
        'accepted_forward_queries': sum(e['row'].get('accepted') is True for e in forward),
        'completed_forward_rejected_by_other_quality_checks': sum(
            e['row'].get('status') == 'native_complete' and e['row'].get('accepted') is False for e in forward),
        'accepted_reconnects': sum(e['row'].get('accepted') is True for e in reconnect),
        'known_expansion_sum': sum(e['row']['native_expanded'] for e in known),
        'query_rows_missing_expansion_count': unknown,
        'excessive_detour_native_completions': len(excessive),
        'excessive_detour_expansion_sum': sum(e['row'].get('native_expanded', 0) for e in excessive),
    }


def active_recovery_window(trace, events, cached):
    """Locate the final bounded-rollback episode, rather than all past failures."""
    active, frontier, transition = [], None, None
    for index, row in enumerate(trace):
        if not isinstance(row, dict):
            continue
        if row.get('mode') == 'rollback_soft_anchor':
            if frontier is None:
                frontier = row.get('abandoned_anchor')
            active.append({'trace_index': index, **row})
        elif row.get('mode') in FORWARD_MODES and row.get('accepted') is True:
            target = row.get('to_anchor')
            if type(frontier) is int and type(target) is int and target > frontier:
                active, frontier = [], None
        elif row.get('mode') == 'remaining_native_fallback':
            reference_range = row.get('remaining_reference_range', {})
            if not isinstance(reference_range, dict):
                raise ValueError('Expected an object for remaining_reference_range at trace %d' % index)
            transition = {'trace_index': index, **row}
    if transition is None:
        return None
    lower = transition.get('remaining_reference_range', {}).get('anchor_from')
    indices = [r.get('resume_anchor') for r in active] + [lower]
    indices = [i for i in indices if type(i) is int]
    if not indices:
        return {'transition': transition, 'window_unavailable': 'No recorded anchor range'}
    lower = min(indices)
    end = transition['trace_index']
    possible = [e['trace_index'] for e in events if e['kind'] == 'forward'
                and type(e['row'].get('from_anchor')) is int
                and e['row']['from_anchor'] >= lower and e['trace_index'] < end]
    begin = min(possible) if possible else end
    scoped = [e for e in events if begin <= e['trace_index'] < end]
    return {
        'scope_method': 'Final active rollback episode, beginning at its earliest resumed anchor; a control-flow window, not a physical root-cause proof.',
        'trace_from': begin, 'trace_to_exclusive': end, 'earliest_resume_anchor': lower,
        'active_rollbacks': active, 'transition': transition,
        'query_statistics': event_statistics(scoped),
        'cache_rechecks': sum(begin <= c['trace_index'] < end for c in cached),
    }


def audit_document(document, *, source_name='<provided JSON>', source_sha256=None):
    if not isinstance(document, dict):
        raise ValueError('Expected a JSON object')
    envelope = document
    diagnostic = document if 'road_trace' in document else document.get('diagnostic')
    if not isinstance(diagnostic, dict) or not isinstance(diagnostic.get('road_trace'), list):
        raise ValueError('No route diagnostic road_trace was found')
    trace = diagnostic['road_trace']
    version = diagnostic.get('planner_version')
    supported = version in SUPPORTED_PROTOCOLS
    reported_trace_count = diagnostic.get('road_trace_count', len(trace))
    if type(reported_trace_count) is not int or reported_trace_count < 0:
        raise ValueError('Expected a nonnegative integer for road_trace_count')
    truncated = reported_trace_count > len(trace)
    events, cached, reconstruction_warnings = reconstruct_road_queries(trace, truncated=truncated)
    if reported_trace_count < len(trace):
        reconstruction_warnings.append('Reported road_trace_count is smaller than the rows present')
    statistics = event_statistics(events)
    result = diagnostic.get('result', {})
    if not isinstance(result, dict):
        raise ValueError('Expected a result object in the route diagnostic')
    debug, debug_error = extract_native_debug(result.get('message'))
    transitions = [r for r in trace if isinstance(r, dict) and r.get('mode') == 'remaining_native_fallback']
    quality = [{'trace_index': i, **r} for i, r in enumerate(trace)
               if isinstance(r, dict) and r.get('mode') == 'remaining_native_fallback_quality']
    before_fallback = transitions[-1].get('expanded_before') if transitions else None
    raw_display_sum = sum(r['native_expanded'] for r in trace if isinstance(r, dict)
                          and r.get('mode') in FORWARD_MODES | {'native_reconnect'}
                          and nonnegative_number(r.get('native_expanded')))
    ledger = {
        'reported_road_expansions_before_fallback': before_fallback,
        'known_road_expansions_after_cache_deduplication': statistics['known_expansion_sum'],
        'raw_trace_display_sum_not_a_budget_total': raw_display_sum,
        'cache_displayed_expansions_not_charged_again': sum(
            c['displayed_native_expanded'] for c in cached if nonnegative_number(c['displayed_native_expanded'])),
        'unattributed_road_expansions': (before_fallback - statistics['known_expansion_sum'])
            if nonnegative_number(before_fallback) else None,
    }
    fallback = {
        'transition_count': len(transitions), 'success_quality_decisions': quality,
        'terminal_native_debug': debug, 'debug_parse_error': debug_error,
        'reconstructed_query_count': None, 'count_inference': None,
        'total_expansions_from_terminal_native_ledger': None,
    }
    if debug and debug.get('source') == 'native.ad_path' and debug.get('stage') == 'fallback_path':
        radius = debug.get('radius')
        if supported and type(radius) is int and radius in FALLBACK_RADII:
            fallback['reconstructed_query_count'] = FALLBACK_RADII.index(radius) + 1
            fallback['count_inference'] = 'Known v1/v2 radius order; prior radii, if any, required no_route before this terminal query.'
        if nonnegative_number(debug.get('expanded_before')) and nonnegative_number(debug.get('call_expanded')):
            fallback['total_expansions_from_terminal_native_ledger'] = debug['expanded_before'] + debug['call_expanded']
            fallback['earlier_fallback_expansions_before_terminal_query'] = (
                debug['expanded_before'] - before_fallback) if nonnegative_number(before_fallback) else None
    elif (len(quality) == 1 and supported and type(quality[0].get('radius')) is int
          and quality[0]['radius'] in FALLBACK_RADII):
        fallback['reconstructed_query_count'] = FALLBACK_RADII.index(quality[0]['radius']) + 1
        fallback['count_inference'] = 'Known v2 radius order ending with the recorded successful fallback quality decision.'
        fallback['total_expansions_from_terminal_native_ledger'] = quality[0].get('expanded_total')
    elif supported and not transitions and result.get('status') == 'success' and events:
        fallback['reconstructed_query_count'] = 0
        fallback['count_inference'] = 'Successful road-following trace without a fallback transition.'
    total_inferred = (len(events) + fallback['reconstructed_query_count']) if (
        supported and diagnostic.get('complete') is not False and not truncated
        and fallback['reconstructed_query_count'] is not None and not reconstruction_warnings) else None

    long_candidates = []
    for e in events:
        r = e['row']
        if r.get('status') != 'excessive_detour':
            continue
        reference, length = r.get('reference_length_xy'), r.get('route_length_xy')
        long_candidates.append({
            'trace_index': e['trace_index'], 'iteration': e['iteration'],
            **{k: r.get(k) for k in ('from_anchor', 'to_anchor', 'target', 'mode', 'native_expanded',
                                    'route_length_xy', 'reference_length_xy', 'length_limit_xy')},
            'route_to_reference_ratio': length/reference if nonnegative_number(length) and nonnegative_number(reference) and reference > 0 else None,
            'ordered_distance_recorded': 'ordered_distance_xy' in r,
            'backtrack_metric_recorded': 'backtrack_xy' in r,
            'proves': 'The native query completed to this intermediate target; this does not prove full A/B completion or road-quality acceptance.',
        })
    window = active_recovery_window(trace, events, cached)
    interpretation_status = ('provisional_unsupported_protocol' if not supported else
                             'partial_or_provisional_trace' if truncated or diagnostic.get('complete') is False or reconstruction_warnings else
                             'known_protocol_controlflow_inference')
    statistics['count_interpretation_status'] = interpretation_status
    if window and 'query_statistics' in window:
        window['query_statistics']['count_interpretation_status'] = interpretation_status
    fallback['count_interpretation_status'] = interpretation_status
    scoped = window.get('query_statistics') if window else statistics
    observations = []
    if scoped:
        if scoped['excessive_detour_native_completions']:
            observations.append('completed_local_candidates_rejected_by_road_length_preference')
        if scoped['forward_status_counts'].get('budget', 0):
            observations.append('local_native_queries_reported_budget_without_a_completed_candidate')
        if scoped['forward_status_counts'].get('no_route', 0):
            observations.append('local_native_queries_reported_no_route')
    if debug and debug.get('native_reason'):
        observations.append('terminal_' + str(debug['native_reason']))
    budget = diagnostic.get('max_expansions')
    accounted = fallback['total_expansions_from_terminal_native_ledger']
    resources = {
        'global_expansion_budget': budget,
        'expansions_accounted_at_terminal_event': accounted,
        'global_budget_not_exhausted_at_terminal_event': accounted < budget if nonnegative_number(accounted) and nonnegative_number(budget) else None,
        'terminal_call_passed_budget': debug.get('passed_budget') if debug else None,
        'loaded_tiles': debug.get('loaded_tiles') if debug else None,
        'loaded_bytes': debug.get('loaded_bytes') if debug else None,
        'max_bytes': debug.get('max_bytes') if debug else None,
        'reported_tile_memory_not_exhausted': (debug['loaded_bytes'] < debug['max_bytes'])
            if debug and nonnegative_number(debug.get('loaded_bytes')) and nonnegative_number(debug.get('max_bytes')) else None,
        'result_expanded_field': result.get('expanded'),
    }
    limitations = [
        'Counts reconstructed from v1/v2 control flow are not a raw native-call recording or independent execution.',
        'Road metadata cannot prove a bridge, water obstacle, tile defect, floor connectivity, or the correctness of a particular detour.',
        'excessive_detour proves a completed local native result; in these planners length is tested before deviation/backtracking metrics.',
        'A local budget failure is incomplete search, not proof of no route. Matching terminal error codes do not establish matching physical causes.',
        'Candidate XYZ/corridor geometry is not generally retained by local excessive_detour trace records.',
    ]
    if not supported:
        limitations.append('Unrecognized planner version: v1/v2 cache and retry interpretations are provisional; no total query estimate is asserted.')
    if truncated or diagnostic.get('complete') is False:
        limitations.append('The diagnostic is incomplete or truncated; observed rows are not the full planning history.')
    if statistics['query_rows_missing_expansion_count']:
        limitations.append('Some native reconnect rows omit expansion counts; the aggregate remainder is known only if a later budget checkpoint records it.')
    if resources['result_expanded_field'] != accounted and accounted is not None:
        limitations.append('result.expanded differs from the full terminal ledger. v1 may retain only the final call count; use expanded_before + call_expanded when available.')
    observed_calls = envelope.get('calls') if envelope is not diagnostic else None
    supplied_call_log = None
    if isinstance(observed_calls, list):
        expanded = [c.get('expanded') for c in observed_calls if isinstance(c, dict)]
        supplied_call_log = {
            'query_count': len(observed_calls),
            'sum_expansions_if_all_recorded': sum(expanded) if all(nonnegative_number(x) for x in expanded) else None,
            'matches_reconstructed_total_count': len(observed_calls) == total_inferred if total_inferred is not None else None,
            'provenance': 'Native-call records explicitly supplied in this input envelope; not produced by this audit.',
        }
    return {
        'schema': 1, 'source': source_name, 'source_sha256': source_sha256,
        'planner_version': version, 'supported_controlflow_protocol': supported,
        'navigation_identity': diagnostic.get('navigation_identity'),
        'recorded_native_library_sha256': diagnostic.get('native_library_sha256'),
        'start': diagnostic.get('start'), 'goal': diagnostic.get('goal'),
        'blocked_edges': diagnostic.get('blocked_edges'),
        'trace_rows_present': len(trace), 'trace_rows_reported': reported_trace_count,
        'diagnostic_complete_flag': diagnostic.get('complete'),
        'mode_counts': counter_dict(r.get('mode', 'unspecified') for r in trace if isinstance(r, dict)),
        'road_query_statistics': statistics,
        'query_reconstruction': {
            'basis': 'Reconstructed from the documented v1/v2 attempt_cache, native_reconnect and radius-retry control flow.',
            'interpretation_status': interpretation_status,
            'query_definition': 'Path queries (Mesh.path / native.ad_path); surface queries and tile loads are not counted.',
            'raw_native_call_log_supplied': supplied_call_log is not None,
            'inferred_total_queries_including_fallback': total_inferred,
            'new_forward_trace_indices': [e['trace_index'] for e in events if e['kind'] == 'forward'],
            'native_reconnect_trace_indices': [e['trace_index'] for e in events if e['kind'] == 'reconnect'],
            'cache_rechecks': cached, 'warnings': reconstruction_warnings,
        },
        'expansion_ledger': ledger, 'fallback': fallback, 'resource_observations': resources,
        'completed_candidates_rejected_for_length': long_candidates,
        'final_recovery_window': window,
        'classification': {
            'terminal_error_code': result.get('code'), 'terminal_native_reason': debug.get('native_reason') if debug else None,
            'observed_signature_in_final_window': observations,
            'local_quality_rejections_are_distinct_from_successful_fallback_quality_rejection': True,
            'successful_fallback_quality_rejection_recorded': any(q.get('accepted') is False for q in quality),
            'physical_root_cause': 'undetermined_from_route_log_alone',
        },
        'supplied_native_call_log_crosscheck': supplied_call_log,
        'confidence_limits': limitations,
    }


def audit_route_file(path):
    path = Path(path)
    if path.stat().st_size > MAX_INPUT_BYTES:
        raise ValueError('Input exceeds 16 MiB audit limit')
    with path.open('rb') as stream:
        raw = stream.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise ValueError('Input grew beyond 16 MiB audit limit')
    def reject_nonfinite(value):
        raise ValueError('Non-finite JSON number: ' + value)
    document = json.loads(raw.decode('utf-8-sig'), parse_constant=reject_nonfinite)
    return audit_document(document, source_name=str(path.resolve()),
                          source_sha256=hashlib.sha256(raw).hexdigest())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('json_paths', nargs='+', type=Path, help='One or more explicit route diagnostic JSON paths.')
    args = parser.parse_args(argv)
    reports, failed = [], False
    for path in args.json_paths:
        try:
            reports.append(audit_route_file(path))
        except (OSError, ValueError, TypeError, KeyError) as error:
            failed = True
            reports.append({'source': str(path), 'input_error': type(error).__name__ + ': ' + str(error)})
    json.dump({'schema': 1, 'read_only_audit': True, 'reports': reports}, sys.stdout,
              ensure_ascii=False, indent=2, allow_nan=False)
    sys.stdout.write('\n')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
