# 统一导航诊断与游泳设计交付包

请先阅读 navigation_system_design.md。

- generation_strategy.md：公共生成候选、批量验收与发布。
- planner_system_findings.md：新长路线与 Westfall 的控制流比较、分层规划。
- swimming_design.md / .json：WALK + SWIM_SURFACE 数据、接口和执行设计。
- audit_route_logs.py：标准库只读工具，接受明确指定的一个或多个 last-plan JSON 路径，JSON 报告写到标准输出。
- audit_validation.json：两份真实日志与输入稳健性核验记录。
- batch_probe_contract.json：未来生成/拓扑 probe 接口设计，尚未实现。
- evidence/：支持报告的固定来源。evidence-index.json 将原路径映射到包内位置。
- integrity.json：每个交付成员的字节数与 SHA-256，不包含其自身。

本包不是生产安装包。设计未启用游泳，也没有完成全图重建或修复最新长路线。
源码、patch 和旧实验记录作为证据收录；无需运行个别桥安装器。
完整 raw 地形、全部生产瓦片与 DLL 没有重复收录，故本包不等于完整原生重放环境。
部分历史报告中的 sandbox 链接指向固定工作快照；离线阅读请通过 evidence-index.json 找到已收录文件。未收录的大产物保留原 hash 与范围说明。

审计示例（Python 3）：

    python audit_route_logs.py "evidence/upload/last-plan(1).json"

处理本次证据时无需重新运行，此包已附结构化分析。
