# 导航网格生成：统一修复、批量审计和整包发布

日期：2026-10-29。范围：现有地图 0 / 1、同一客户端 1.60.1.70658、当前地面步行代理。本文是基于已执行实验的系统设计；未修改原始输入、生产生成器、DLL、活动规划源码或活动清单，也没有启动全图重建。

## 1. 应从两个坐标补丁，转成一个可验证的生成版本

建议把已验证的 `higher-span-area` 栅格合并修复与显式 `Monotone` 分区定义成同一候选生成 profile，接入统一的 mmaps 构建流程，先批量验证、再按完整清单发布。今后按原始依赖与 profile 的哈希决定哪些瓦片需要重建，不在运行时按桥坐标写特例。

这已有两处独立实物几何的支持，足以提出通用候选；还不足以认定该组合对全部地形、洞穴、楼层和岸线都已验证。西部荒野第三处目前只证明导航图的局部水域边界阻断了步行查询，尚未证明它是同一生成根因。三者必须分别保留证据等级。[E1–E5]

| 案例 | 基线可重复性 | 已证实问题 | 组合候选结果 | 目前边界 |
|---|---|---|---|---|
| 地图 0 / 50 / 34 | `.pmesh`、`.dmesh`、`.mmtile` 与原工具逐字节一致 | 下方三角覆盖上方 area；B 端 ground span 最终变成 water polygon | 原过滤条件下 A→B 三维约 41.07174 码，19 次展开；反向约 41.07165 码，25 次展开 | B 端精确到内部 `removeVertex` 的调用归因当时仍是推断，不能追溯性说成已逐调用证明 |
| 地图 1 / 37 / 38 | 三项产物逐字节一致；solid/liquid 前缀分别核验 | 两端 bridge underside 使顶部 area 丢失；同 region 混入 ground/water，contour 使用一个 area | 原过滤条件下双向水平约 49.62213 码、三维约 49.69502 码，14 / 12 次展开 | 这是实际源几何支持的两类故障；没有把所有 water 改成 ground |
| 地图 0 / 52 / 30 | 原失败路线严格复现：46/46 瓦片、0 缺失；v1/v2 原生调用相同 | 在桥附近同高表面上出现 area 9 / flags 4 边界；允许的高、低层分别是 5 / 9 polygon 孤岛 | 没有生成候选；局部步行图不通，忽略类型时通过 4 个 water polygon | 原始地形/模型未在现有资料内，不能证明该 water 面应是桥面；全加载范围仍有一条三维 6982.67 码的有效大绕路，不是“全图绝对断连”，也未证明它是最短路 |

地图 0 / 50 / 34 的原瓦片 SHA 为 `616d2cf2905a2868ee83f3a12aa60540d04b73b2186d895033084dfc3e95fd79`，修复为 `74dd28d4d559518bca84b678ac3fb3ccd5ba294c8ab65bebcede927acc46df1c`。地图 1 / 37 / 38 原 SHA 为 `bf81052e0ebbc9e5bbd58e2ae269181b14c0e59e9a2f9874d5ba6707e292a825`，修复为 `d8497ef8ac2cb510a2b950af4e24360d746cbe7f71699773c2ad3bcbd824f7ce`。[E1–E4]

## 2. 可推广的规律，以及不可直接推广的结论

### 2.1 同一类 span 合并缺陷，可以在生成器公共层修复

两次逐三角追踪都显示：已有较高可走顶面与新加入的低处不可走三角重叠时，合并后的 `smax` 仍取较高顶面，area 却保留了低处三角的 0。随后正常的代理半径侵蚀把一格的空隙扩大成数格。提高寻路预算、改变道路锚点或降低侵蚀半径均不能恢复正确的几何语义。[E1–E3]

已测试的局部修复位于公共 `dep/recastnavigation/Recast/Source/RecastRasterization.cpp::addSpan`：在修改 span 上下界之前，若新旧顶面差超过 `flagMergeThr`，且已有 span 的顶面更高，则继承已有 span 的 area；顶面差在阈值内时保留原来的 `rcMax` 合并规则。它根据上表面归属处理所有位置，不包含坐标和模型名。[E1、E6]

推广时仍需补齐多 span 组合、顶差恰好等于阈值、斜面、低净空、高障碍覆盖低地面、不同液体类型及输入三角排列的性质测试。已有 7 项小规模语义检查只覆盖其列明的情形，不能写成任意排列都满足交换律。尤其不要改成“area 数字越大永远优先”；类别数字不是通用的安全优先级。

### 2.2 地面与液体必须在 region、contour、polygon 之间保留语义边界

地图 1 的精确基线中，subtile `(17,17)` 的 region 5 在记录 ROI 内含 4574 个 ground span 与 1143 个 water span，随后一个 contour 的 area 为 9。源代码中的 layer 合并没有按 areaType 隔离，而 contour 按 region 划边并继承起始 span 的类别。这为“桥顶高度仍在，但被当作水”提供了独立于 span 覆盖问题的证据。[E3]

两个真实案例中，单独修 span 或单独换分区都不够；组合才恢复了直接桥路线。因而近期统一候选应固定为 `higher-span-area + Monotone`。它保持原代理半径、身高、爬升、坡度、cell 大小、液体几何和 offmesh 策略。[E1、E4]

另一条工程路线是精确修复 Layers 的 area 保持，并证明 contour 重建及边界顶点处理不再混类。该路线可能减少分区变化的范围，但尚未有与组合候选同等的实物回归证据，应作为独立候选比较，不能现在当成更小且已验证的替代方案。

把 Monotone 设为统一候选不意味着所有多层场景都已安全。应增加螺旋楼梯、隧道、重叠楼层、悬挑、狭窄通道、城门、岸线和跨瓦片边界的测试集合；出现失败时保留为构建失败，不静默切回另一算法。[E7]

### 2.3 哪些现象只能用于筛查

- **长绕路**说明现有查询的质量异常或场景本身需要绕行。用端点直线距离作分母只能形成告警；墙、山和合法单向通道都可能使比值很大。不能因此生成穿墙捷径。
- **小组件**可能是错误碎片，也可能是合法屋顶、孤立平台或尚未加载邻接瓦片的边界。只有在完整声明的加载范围与过滤条件内，才能断言两个 surface 不可达。
- **同高 ground/water 边界**是分类核查目标。它不能单独证明水面标签错误，必须比较原始 solid/liquid 流、净空、坡度、代理半径以及各生成阶段。
- **`node_pool_exhausted`**是本次查询的资源终止原因，不等于数据内存耗尽，也不等于目标完全断网。西部荒野案例已经直接说明：两端在同一大组件，仍可因局部断路而把有限节点池耗完。[E5]

## 3. 修复应进入哪个统一构建入口

公共修改应进入固定源码树的 Recast 库和共享 `src/common/mmaps_common/Generator/TileBuilder.cpp`，由 `src/tools/mmaps_generator` 的统一入口调用。修复版工具在新构建目录生成；不要覆盖历史工具二进制，否则旧版本再现链会消失。

统一 profile 至少固定以下内容：

| 类别 | 候选要求 |
|---|---|
| 代码 | 基础 revision、工作树 diff SHA、Recast patch SHA、共享 TileBuilder SHA、最终工具二进制 SHA |
| 分区 | requested=`monotone`；每个 subtile 的 effective partition 都记录；不允许未声明 Layers 回退 |
| 代理 | `cs=ch=0.2666666f`、height 6、radius 2、climb 2、坡度 50 / 50；记录源码表达式和实际 float 值，避免只保存近似小数 |
| 网格 | 80 格 subtile、25×25、border 5、region/edge/detail 参数全部固定；全瓦片原点与对齐一致 |
| 类别 | ground / steep / road / water / magma/slime 的 area→flags 映射有版本；液体仍被保留在几何流里 |
| 通行 | 当前地面 profile include `0x11`、exclude `0x0e`、offmesh 禁止；“输出液体几何”和“允许角色游泳”是两个独立设置 |
| 输入 | 客户端 build key、提取工具 SHA、原始地图和 VMAP 依赖清单、引用 VMO、road sidecars、DB2 元数据与 liquid 类型 |

现有源码有三个必须明确控制的行为：[E7–E8]

1. **显式 Monotone 仍可能失败后回退 Layers。** `TileBuilder.cpp::TileBuilder::buildMoveMapTile` 的条件为 `!regionOk && method != MmapPartitionMethod::Layers`，随后调用 `rcBuildLayerRegions`。候选发布要求每个 subtile 的实际算法满足 profile；未声明回退必须阻止发布。可以保存失败产物供诊断，但不能标成成功 Monotone 构建。
2. **一些生成阶段失败后 `continue`。** 同一函数对 compact heightfield、erosion、median、regions、contours 等阶段存在失败日志后继续下一 subtile 的分支。单个工具进程退出 0 不足以证明完整瓦片。应记录全部预期 subtile 的终态，区分“证明原输入为空”和“计算失败或被跳过”。后者不能通过发布门禁。
3. **已有 mmtile 的版本和修改时间可能导致跳过重建。** `MapBuilder.cpp::MapTileBuilder::shouldSkipTile` 先检查已有文件的 magic、Detour/MMAP version，再比较 road sidecar mtime；普通非 debug 模式下会落到 `TileBuilder::shouldSkipTile` 的 `true`。此外 mmtile 的 `last_write_time` 失败会直接返回 `true`。debug 模式正常落到基类时返回 `false`，不能笼统说 debug 基线也总被缓存跳过。新 profile 必须写全新的输出目录；增量复用用完整依赖摘要作键，不能仅靠文件存在、版本号或 mtime。

推荐的依赖键为：`SHA256(规范化profile + 工具与源码摘要 + 此tile全部输入摘要 + 邻接源条带摘要 + metadata摘要)`。共享 WMO、road sidecar 或元数据改变时，要沿依赖索引重新安排所有受影响瓦片。改变栅格/分区算法时，不能让旧算法瓦片悄悄借用新 profile 名称。

debug `.obj/.mesh` 不保存原始 solid/liquid split 或完整类别。批量流程应直接从原始输入产生显式 geometry snapshot，记录各流的顶点、三角数与 hash；不能把另一瓦片的液体前缀数量复用，也不能以最终 `.mmtile` 反推出已丢失桥面。原始 source 快照一次按声明范围组织，后续所有异常都引用同一数据集，不再让用户为每个路线手工挑文件。[E1、E3]

## 4. 批量审计分三层，逐层解释异常

```mermaid
flowchart TD
    A[固定输入与生成 profile] --> B[批量生成到候选目录]
    B --> C[完整性和语义不变量]
    C --> D[网格拓扑与路线审计]
    D --> E[真实运行时验收]
    E --> F[完整清单切换]
    C --> G[隔离失败记录]
    D --> G
    E --> G
```

### 第一层：无条件的构建与数据门禁

完整目标 tile inventory、唯一 key、地图头、tile header、bounds、代理参数、bytes/SHA、输入前后稳定性、所有 subtile 终态、实际分区方法、有效类别集合、offmesh 数量和溢出/截断状态必须可检查。跨 tile 的边界连接要以加载后的实际 Detour links 核验，不能只比较两条轮廓看起来接近。

在约定一个 region/contour 只代表一个 area 的流水线中，非 border region 混入多个实际 area 应触发构建语义门禁；不要要求 border 哨兵满足同一规则。与原始 solid/liquid 对应的抽样验证应在正确高度层进行，并排除简化边界的合理数值容差。仅按全瓦片 ground/water 面积比例通过或失败，会漏掉面积很小却切断桥路的条带。

### 第二层：自动生成检查任务，而非按投诉坐标补丁

任务来源是固定 manifest 和道路数据：所有已审核道路在曲率、边界、跨水区、跨高程和跨 tile 位置生成一批带版本的抽样任务；多层几何、area 边界和小组件另外生成几何审计任务。均保存采样规则版本和随机种子或确定性顺序。

每条任务要记录原始 XY、所有实际 surface 候选、当前选择的 layer、ref/area/flags、各候选在当前 movement profile 下的可达性；不会把未知 Z 强行移到最近一层。需要时从真实 collision 几何提取支撑高度，不能把手填桥中点用作证据。

自动报告至少包含：

- 原生失败原因、node pool 容量、展开次数、请求/加载/缺失 tile 集合和数据内存；预算失败不归类为“不连通”。
- 反向一致性、水平长度与三维长度分别统计、最大偏离道路距离、沿道路进度的最大折返；道路是引导意图，最终仍需碰撞网格证明可走。
- 地面过滤前后的局部拓扑差异，以及被排除的具体类别；忽略 flags 产生的路径只作为诊断见证，绝不交给执行器。
- 多层候选的组件大小和 reachability，标明加载范围与是否触及范围边界；边界开放的组件不自动命名为孤岛。
- 相对基线新增的断路、异常高程跳变、类别漂移、跨 tile 接缝断裂、性能与大小变化。

筛查告警不直接修改瓦片。证明明确违反 profile / 源几何语义的才归类为生成错误；合法地形绕路可记录解释性例外，例外绑定数据和算法版本，不成为“永远放行”的坐标白名单。

### 第三层：原生路径和实运行时验收

用生产相同过滤器、同一 DLL ABI 和完整清单进行 direct / guided、A→B / B→A 检查。必须保留每条任务完整请求的索引；按本地存在文件过滤 tiles 会制造伪结论。几何 BFS 与生产 A* 分开记录：BFS 能证明某个图范围内的 reachability，不能证明有限 A* 一定找到路线，也不能把最少 polygon 的路径称作几何最短路。

Linux 固定源码重放用于定位和回归；Windows 当前 DLL 的预加载、surface 查询及真实路径验收仍是发布门禁。两者数值容差与差异范围要提前定义，不能用一套较容易通过的运行时替代另一套。

## 5. 统一审计入口的生成与拓扑接口

本次保留同目录 `generation_case_catalog.json` 和 `batch_probe_contract.json`，作为统一审计入口未来的生成/拓扑插件输入，不再增加用户需要单独运行的脚本。catalog 固定现有来源文件的 bytes/SHA，列出两处已证实根因、组合候选及第三处尚未有源几何的异常；它没有执行新的 native 查询、生成器或全图扫描。

统一入口的报告应区分 `evidence_integrity`、`attention_required` 和 `release_eligible`。缺失必需输入时状态为 `incomplete`；启发式异常为 `needs_review`；通过已声明的全部发布门禁之后才允许 release。无告警不能当作全图质量合格。筛查阈值及适用结构在任务 manifest 中保存，不能散落成每座桥的专用参数。

建议 probe 协议明确请求的资产全集、movement profile、surface 候选、组件边界、可达性、每次原生调用和原始几何支持状态。它是接口约定，不代表全图 probe 已实现。现有 `Native` 路径接口和 topology probe 的加载、surface、BFS、`findStraightPath` 算法可以复用，但硬编码端点与地图索引应从协议请求读取。已有失败日志审计模块负责规划日志分类；这里的插件负责生成产物和拓扑证据，汇总到同一案例 ID 下。

## 6. 候选生成 profile 的最低批量验收集

1. **两处已证明缺陷作为永久回归。** 原 baseline 三项 byte exact；修复后双向直接桥路线；真实 solid 支撑；保持 water 几何和过滤器；不添加 offmesh。
2. **按结构分层的样本集。** 至少覆盖普通平地、坡道、低净空、螺旋楼梯、洞穴、多个重叠楼层、岸线、窄桥、桥下水、熔岩/污泥、跨 tile 接缝、road sidecar；数量由数据 inventory 产生并报告，不能宣称三座桥代表全地图。
3. **所有审核道路的批量局部检查和长路线回归。** 本次 Westfall 原失败路线永久进入 known-failure 集；在没有源证据前保留待解释状态，不能用调整 flags 的方式让它变绿。
4. **资源与确定性。** 在固定编译环境对 golden 输入要求完全一致；跨平台先验证 ABI、header 和几何误差门限。记录每 tile polygon/vertex/detail 数、峰值内存、生成时间和生产查询 p50/p95/p99；资源上限须在运行前声明。
5. **整包集合与兼容性。** 新包 tile 集合应与声明发布范围精确相符；每个条目都能加载；区域边界和修复/未修复邻接瓦片一起测试；profile 混用必须显式声明并经过接缝与兼容性验收。

Monotone 会改变网格形状与编号。两个例子的修复瓦片分别从 822736→888768 字节、1008288→1269700 字节增加，不能假定全图内存不变。原 poly ID 绑定的禁行边、路径缓存与缓存组件 ID 必须按实际导航内容版本重新验证；不要把旧 ref 无条件套到新网格。[E1、E4]

## 7. 版本、整包原子切换和回滚

建议采用不可变目录：`data/navigation/releases/<dataset-digest>/`，其中包含完整 manifest、地图头、瓦片、profile、工具/输入 provenance、审计结果及与 DLL/规划版本的兼容约束。当前 loader 未必支持 release pointer；兼容迁移可以先让顶层 `manifest.json` 原子替换，所有资产路径指向不可变目录。已打开的查询上下文固定旧 manifest 快照，不能在一条查询中途混读新旧瓦片。

发布顺序是：先完整构建候选目录，核验所有 hash 与门禁，再创建候选查询上下文并完成 Windows 原生验收，最后只切换一个已校验的 manifest/pointer。文件切换前后要检查当前版本仍是预期旧版本，并用同卷临时文件加 `os.replace`；这提供单文件切换的原子性，不等于任意平台上所有写入天然具备断电持久性。保存精确旧 manifest、旧 release digest、报告与收据。

若还要同时更新 DLL/规划代码，优先把兼容的一整组运行资源封装为一个版本，并在重启或排空旧查询后加载。多个独立 `replace` 不是一个事务；如暂时沿用旧布局，必须像已交付安装器一样记录每次尝试和已写内容、只在当前内容仍等于本次写入时回退，报告部分失败，拒绝覆盖用户后来改动。[E9]

回滚仅切回已验证旧 digest；如果当前 pointer 已不是本次版本，则停止自动回滚。旧 release 在没有引用、回滚保留期完成后再清理。回滚包含与版本绑定的派生缓存和禁行边适用性记录，不通过修改历史文件伪装为“恢复”。

provenance 应同时保存：实际源码 revision / diff 摘要、构建时刻、编译器与依赖环境、工具实际 SHA、完整 profile、实际分区记录、输入依赖 hashes、输出 hashes、验证程序版本与平台。历史工具 banner revision 与记录 revision 有差异时，以实际源码快照、二进制和可重现输出建立证据链，不能只打印一个 Git 名称就声称构建一致。[E3、E10]

## 8. 与游泳模式的边界

可以设计独立的 `walk+swim` movement profile，但应建立在正确的 solid/liquid 分类之上；把所有 `NAV_WATER` 加入现有步行 filter，既不能恢复缺失桥面，也会把误标的桥面和真实水面混在一起。水面高度、真实水深、入水/上岸连接、岸边坡度、可游液体类型、呼吸/角色能力和执行器模式切换应各自验证。导航数据可以同时保留 ground 和 liquid，查询按能力选择，状态切换由明确的边控制；这不要求为每条桥路线再写坐标特例。

当前审计模块只识别可疑边界，不实现游泳，也不把忽略 flags 的诊断路径当作游泳可执行路径。用户选择游泳策略后，应作为另一个带独立验收集的系统功能推进。

## 证据索引

- **E1**：[地图 0 精确重放与两类缺陷](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/recast_replay/deliverables/REPRODUCE.md)、[原瓦片校准](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/recast_replay/baseline-full/converter-calibration.json)。
- **E2**：[地图 0 逐三角追踪](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/recast_replay/raster-trace.json)、[B 端区域证据](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/recast_replay/B-boundary-evidence.json)。
- **E3**：[地图 1 原始几何与根因报告](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/source_analysis/README.md)、[阶段证据](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/source_analysis/stage-evidence.json)。
- **E4**：[地图 1 四组生成对照](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/generation_replay/replay-comparison.json)、[候选原生验收](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/candidate_validation/selected-full/summary.json)。
- **E5**：[Westfall 严格原路线复现](sandbox:/workspace/scratch/20239ebfbca8/westfall_route_repro/replay/replay-summary.json)、[完整网格诊断](sandbox:/workspace/scratch/20239ebfbca8/westfall_route_repro/mesh_analysis/diagnosis-summary.json)。
- **E6**：[已验证的公共栅格补丁](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/recast_replay/deliverables/recast_keep_upper_surface.patch)。
- **E7**：[捕获的共享 TileBuilder](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/case_4066c49b/wsl/source-recorded-revision/src/common/mmaps_common/Generator/TileBuilder.cpp)。
- **E8**：[捕获的 MapBuilder](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/case_4066c49b/wsl/source-recorded-revision/src/tools/mmaps_generator/MapBuilder.cpp)、[CLI 分区入口](sandbox:/workspace/scratch/20239ebfbca8/generation_repro/case_4066c49b/wsl/source-recorded-revision/src/tools/mmaps_generator/PathGenerator.cpp)。
- **E9**：[已交付组合安装器](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/deliverables/apply_kalimdor_bridge_fix.py)。
- **E10**：[捕获的来源记录](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/case_7860200b/original-work/provenance.json)、[本地重放编译记录](sandbox:/workspace/scratch/20239ebfbca8/kalimdor_bridge_repro/generation_replay/build-provenance.json)。
