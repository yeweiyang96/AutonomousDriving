# 0000_50_34：生成缺陷、源码修复与离线复现

本说明记录已执行的离线诊断。固定源码、原始输入、线上清单、客户端 DLL 均未改动；测试改动仅存在于分析目录的副本。

## 校准与结果

使用用户提供的 float32 `.mesh`、完整液体标记和固定 Recast 源码，重放全部 625 个子瓦片，输出与原工具逐字节一致：

| 文件 | 大小 | SHA-256 |
|---|---:|---|
| pmesh | 170933 | `e0dc1650e466ca493797bb0d678b3e8221bd882f7926ab9ce2b3620dd056bd74` |
| dmesh | 400460 | `f8b62919327a835bfb6beb0001c51a13f2fd96386e74332cccd0fc1562abca80` |

转换回 Detour 瓦片也已校准到原始 SHA-256 `616d2cf2905a2868ee83f3a12aa60540d04b73b2186d895033084dfc3e95fd79`。

| 仅改变的内容 | 使用原导航查询代码的结果 |
|---|---|
| 原始基线 | 桥两端断开；扩大到 49 瓦片时耗尽 65535 节点池 |
| 只修复跨度合并 | A→桥中点成功，7 次展开；桥中点→B 仍无路线 |
| 只使用 Monotone 分区 | 桥中点→B 成功；A→B 绕行约 151.09 码 |
| 跨度修复 + Monotone | A→B 沿桥成功，19 次展开，约 41.07174 码；反向 25 次展开，约 41.07165 码 |

组合候选为 `higher-span-area-monotone/reconverted.mmtile`，888768 字节：

`74dd28d4d559518bca84b678ac3fb3ccd5ba294c8ab65bebcede927acc46df1c`

原查询仍采用 include `0x11`、exclude `0x0e`，禁止 off-mesh；候选含 0 条 off-mesh 连接。未开放水面通行。

## 两处问题与修复范围

**A 端的行走标记在栅格化时被桥底覆盖。** 在栅格 `(379,243)`，地面三角形 56023 生成 `[51,53,11]`；桥顶三角形 71759 合成 `[51,54,11]`；随后朝下的桥底三角形 71761（area 0）将它合成 `[50,54,0]`。最高表面的高度仍为 54，行走标记却丢失。数组表示 `[smin,smax,area]`；三角形编号为完整 `.mesh` 中从 0 开始的编号。

固定 `RecastRasterization.cpp::addSpan` 在顶面差超过合并阈值时，扩大新跨度高度却保留较低新表面的 area。随附 `recast_keep_upper_surface.patch` 仅增加两行：此时若已有跨度更高，就继承已有跨度的 area；阈值内仍执行原来的 `rcMax`。7 项原生检查通过，涵盖桥顶/底面两种顺序、高障碍/低地面两种顺序和近高度合并。这里没有声称任意多个三角形的全部排列都已验证。

**B 端的 ground 标记在轮廓→多边形阶段丢失。** 原 Layers 基线中，子瓦片 `(5,2)` 的 `gx=468..479,gz=207` 均为 ground area 11、region 6。原始轮廓和简化轮廓都覆盖这些格子，直到 west=-1472 的子瓦片边界；最终覆盖这里的却是 area 9 的多边形 517/519。

`B-boundary-evidence.json` 保存了 12 个位置、两种轮廓、多边形 area、顶点高度范围和边界标记。Layer 合并可形成混合 ground/water 的 region；固定源码的边界顶点移除又会重新三角化混合区域。它们提供了与观察一致的代码机制。尚未逐调用记录 `removeVertex` 前后状态，故精确到这个内部调用的归因仍属推断。单独改为 Monotone 已恢复中点→B；本次无需继续改变简化精度或行走尺寸。

所有候选保持 cs=ch=`0.2666666f`、tileSize=80、25×25 子瓦片、border=5、height=6、climb=2、radius=2、坡度=50/50、minRegionArea=144、mergeRegionArea=400、maxSimplificationError=1.8、maxEdgeLen=81、detailSampleDist=cs×16、detailSampleMaxError=ch。

实际 Detour height=`1.599999547`，radius=climb=`0.533333182335`。保留全瓦片高程原点 `14.280941009521484` 和原网格对齐，没有新增道路覆盖、碰撞几何或 off-mesh。

## 重放命令

以下在本诊断工作区的 Linux 环境执行，需要 `g++` 和 Python 标准库；不需要完整 TrinityCore 构建。只编译分析目录中的文件与只读固定 Recast 源码。

```bash
cd /workspace/scratch/20239ebfbca8
python3 - <<'PY'
from pathlib import Path
import subprocess
analysis = Path('generation_repro/recast_replay')
recast = Path('generation_repro/case_4066c49b/wsl/source-recorded-revision/dep/recastnavigation/Recast')
for variant in ('original', 'higher-span-area'):
    sources = sorted((recast / 'Source').glob('*.cpp'))
    if variant != 'original':
        sources = [analysis / 'patches' / variant / p.name
                   if p.name == 'RecastRasterization.cpp' else p for p in sources]
    subprocess.run(['g++', '-std=c++17', '-O3', '-DNDEBUG',
                    '-I', str(recast / 'Include'), str(analysis / 'replay.cpp'),
                    *map(str, sources), '-o', str(analysis / ('replay_' + variant))], check=True)
PY
```

基线重放；输出目录必须不存在：

```bash
generation_repro/recast_replay/replay_original \
  generation_repro/navmesh-tile-debug-20261029T005354Z-5a105709/meshes/map0000_50_34.mesh \
  2514 4320 generation_repro/recast_replay/liquid_areas.bin \
  generation_repro/recast_replay/reproduce-baseline
```

修复重放；仅选择修补后的 rasterizer 和 Monotone 分区：

```bash
generation_repro/recast_replay/replay_higher-span-area \
  generation_repro/navmesh-tile-debug-20261029T005354Z-5a105709/meshes/map0000_50_34.mesh \
  2514 4320 generation_repro/recast_replay/liquid_areas.bin \
  generation_repro/recast_replay/reproduce-repair monotone
```

转换为同版本 Detour 瓦片：

```bash
generation_repro/recast_replay/mesh_to_tile \
  generation_repro/recast_replay/reproduce-repair/replayed.pmesh \
  generation_repro/recast_replay/reproduce-repair/replayed.dmesh \
  generation_repro/navmesh-tile-debug-20261029T005354Z-5a105709/mmaps/0000.mmap \
  generation_repro/recast_replay/reproduce-repair/summary.json \
  generation_repro/recast_replay/reproduce-repair/reconverted.mmtile
```

转换器去除调试 pmesh 的 5 格边框偏移，使用 summary 中的实际参数，不写生产目录。固定生成器日后集成此补丁时，还需要 `--partition monotone` 才对应本次组合验证。

## 证据文件

- `baseline-full/calibration.json`：pmesh/dmesh 精确校准。
- `geometry.json`、`liquid_areas.bin`：液体前缀 2514 顶点、4320 三角形，全部 area 9，逐字节对应原输入。
- `raster-trace.json`：11 个目标格子的逐三角形跨度变化，最终状态与基线逐格相同。
- `baseline-exact/01-*.csv` 至 `09-*.csv`：逐阶段跨度；`baseline-contours/10-contours.csv`：原始/简化轮廓。
- `B-boundary-evidence.json`：B 端标记丢失的最小可核查数据。
- `higher-span-area-span-probe.json`：7 项合并语义检查；两个对照版本也保留。
- `higher-span-area-monotone/native-query.json`：原查询代码与原过滤条件下的双向直接桥路线。

验证范围是这个实际桥段和目标瓦片。原生查询在 Linux 的固定源码构建上完成；Windows 客户端实际读取新瓦片应由后续安装流程再验证。没有据此把其他地图的分区方式一并更改。
